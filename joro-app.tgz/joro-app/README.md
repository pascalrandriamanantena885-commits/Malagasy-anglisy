# JORO Chess (Android)

App Android (Kotlin + Compose) mampiasa ny moteur UCI **JORO** (`joro.tgz` → `joro.cpp`).

- Milalao vs moteur · Live (Stockfish vs moteur) · SPRT · Matrice · SPSA · Calibrage (UCI_Elo)
- Moteur: import (ELF / .zip / .tgz), fafana, update version (GitHub Releases)
- Build: `.github/workflows/build.yml` → compile joro.tgz amin'ny NDK, SVG→PNG, APK

## Fampiasana
1. Apetaho amin'ny GitHub repo, push `main` → Actions → artifact `JORO-x.y.z` (APK).
2. Ho an'ny update ao anaty app: `git tag v1.0.0 && git push --tags` → Release misy APK.
3. Build local: `bash scripts/svg2png.sh` + apetraho `libjoro.so` ao `app/src/main/jniLibs/<abi>/`.

Fanamarihana: `targetSdk 28` no ilaina mba hahafahan'ny app mampandeha ny moteur nalaina avy any ivelany (Android 10+ no manemotra izany raha targetSdk ≥ 29).
APK sonia amin'ny `keystore/joro.jks` (mitovy foana, mba hahafahan'ny update mijanona).

## Stockfish integré
Ny workflow dia manangona sy mamorona Stockfish `sf_17.1` (official-stockfish/Stockfish, GPLv3) amin'ny NDK ho `libstockfish.so`
(arm64-v8a + armeabi-v7a) ao anaty APK. Tsy mila mampiditra binaire intsony: miseho ao amin'ny lisitry ny moteur ho "Stockfish (integré)".
Source: https://github.com/official-stockfish/Stockfish (tag sf_17.1).

## Pipeline fanatsarana
SPSA → profil vaovao · SPRT (profil vs base) · Apply (default ho an'ny JORO integré) · Calibrage (Elo vs Stockfish) · Update.
Ny profil default ao anaty APK dia avy amin'ny `app/src/main/assets/default_profile.txt` (Name=value isaky ny andalana).

## Import / export moteur
- Import: binaire ELF, `.zip` / `.tgz` / `.tar` misy ELF, na source `.cpp` (na archive misy source).
- Source → "Compile cloud": alefa any amin'ny repo (`engines_src/<id>/`), `compile-engine.yml` no mamorona ny binaire ho an'ny ABI telo ary mamoaka Release `engine-<id>`; ny app no mampidina ny mifanaraka amin'ny finday. Mila repo PUBLIC + token GitHub (Contents + Actions write).
- Export: ny moteur rehetra (anisan'ny integré) azo avoaka ho `.zip` na `.tgz`.
- Milalao/Live: afaka misafidy profil JORO (default, base, spsa-N...) isaky ny lafiny.

## Time control · livre d'ouvertures · famerenana asa
- Time control: `movetime`, `Base+Inc` (horloge marina, resy amin'ny fotoana), `nodes`, `depth` — iombonana amin'ny SPRT/Matrice/SPSA/Calibrage/Live.
- Livre: import `.epd`, `.pgn` (SAN) na lisitry FEN → ouverture mitovy ho an'ny lalao roa (paire). Raha tsy misy livre: 4 ply kisendrasendra.
- Checkpoint: SPRT/Matrice/SPSA/Calibrage dia voatahiry isaky ny lalao/iteration; rehefa nijanona ny app dia miseho ny "Tohizo" ao amin'ny tab Fitsapana.

## Fanatsarana vaovao
- Milalao: horloge (Base+Inc), undo, promotion safidy, FEN/PGN import, PGN copy, lisitry hetsika (SAN) azo tsindrina (jereo ny toerana taloha).
- Tantara: ny fitsapana vita rehetra (daty, TC, moteur, valiny) azo jerena, zaraina (share) na fafana.
- SPSA: paires maro isaky ny iteration + graphique curve θ isaky ny paramètre.
- Notification rehefa vita ny fitsapana (SPRT H1/H0, SPSA...).
- CI: job `engine-test` (UCI, perft, go depth/nodes/movetime/wtime, mat en 1) alohan'ny APK.

## Analyse lalao (game review)
Aorian'ny lalao (Milalao na Live) dia misy bokotra **📊 Review**; Stockfish integré (MultiPV 2) no mandinika ny toerana rehetra.
- Sokajy: Brilliant `!!`, Great `!`, Best `★`, Excellent `✔`, Good `✓`, Inaccuracy `?!`, Miss `✗`, Mistake `?`, Blunder `??`.
- Fiandohana: fahaverezan'ny sandan'ny fandresena (win%) raha ampitahaina amin'ny hetsika tsara indrindra; Brilliant = sorona sombin-javatra (SEE) mbola tsara; Great = hetsika tokana (≥15% lavitra noho ny faharoa); Miss = tsy nanararaotra ny fahadisoan'ny mpifanandrina.
- Accuracy isaky ny sisiny + Game rating (fanombanana Elo avy amin'ny ACPL — tsy marina tanteraka), courbe d'évaluation, lisitry ny hetsika misy loko, "Copier PGN annoté".
- Fisehoana (toa ny chess.com): card "Game Review" (Accuracy + Game Rating isaky ny sisiny + isan'ny sokajy misy icône boribory), eval bar, badge eo amin'ny efitra niafara ny hetsika, anamanana maitso ho an'ny hetsika tsara kokoa (azo vonoina), courbe azo tsindrina.
- Lalao voatahiry: lalao rehetra vita (Milalao + Live, hatramin'ny 60) dia voatahiry ho azy (`filesDir/games/*.json`) miaraka amin'ny review raha efa vita; lisitra ao amin'ny tab **Review** (Jereo review / PGN / Fafao). Tsy very rehefa mihidy ny app.
- Book: `assets/openings.tsv` (eco <TAB> anarana <TAB> hetsika SAN). Ny hetsika anatin'ny ouverture hatrany am-piandohana dia sokajy **Book 📖** (accuracy 100%), ary aseho ny anaran'ny ouverture. Azo ampitomboina ny tabilao (andalana tsy mety dia lavina; ny unit test no manamarina).
- Bokotra **⇅ Vadiho** ao amin'ny review (ho azy raha Mainty no nilalao).
- Unit test: `ReviewTest.kt` (classification, accuracy, rating, book, ary `Analysis.build` amin'ny evals voafantina).
- **Retry** (🎯 ao amin'ny review): mifantina ireo hadisoana (Inaccuracy/Mistake/Miss/Blunder), asehoy ny toerana alohan'ny hetsika, ary tsindrio ny hetsika tsara kokoa; misy "💡 Asehoy ny valiny", sivana Fotsy/Mainty/Roa.
- **PV**: ny andalana tsara indrindra (SAN, hatramin'ny 8 plies) dia aseho isaky ny hetsika ary voatahiry miaraka amin'ny review.
- **Forced**: toerana manana hetsika ara-dalàna tokana dia sokajy "Forced →" ary tsy ampidirina amin'ny Accuracy/ACPL.
- **Calibrage Game Rating**: tab Review > "Manomboka calibrage" (Stockfish UCI_Elo 1400…3000 samy milalao, dinihina amin'ny ms mitovy amin'ny fanadihadiana, ACPL -> Elo, interpolation). Voatahiry ao amin'ny SharedPreferences `ratingcalib`; "Default" no averina amin'ny formula voalohany.

## Firafitry ny repo (GitHub)
Ao amin'ny repo dia ireto ihany:
- `.github/workflows/build.yml`
- `joro-app.tgz`  (ny tetikasa manontolo, tsy misy `.github`)

Ny action (`build.yml`) no manaisotra ny `joro-app.tgz` ao amin'ny `proj/`, avy eo manao ny build rehetra ao anatiny
(moteur JORO, Stockfish NDK, test, APK). Raha hanova kaody: manaova tgz vaovao (`tar -czf joro-app.tgz joro-app`
tsy misy `.github`) ary soloy ilay taloha. Mba hanamora ny anarana dia tsara ny `joro-app.tgz` (tsy misy toerana foana),
fa hitan'ny action koa ny `joro app.tgz`. Ny `compile-engine.yml` (import moteur avy amin'ny app) dia mijanona ho rakitra
hafa ao amin'ny `.github/workflows/`; mampiasa `engines_src/` ao amin'ny fototry ny repo izy, fa tsy ao anaty tgz.
