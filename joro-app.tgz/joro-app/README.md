# Blind Chess (Android)

App Android (Kotlin + Compose) mampiasa ny moteur UCI **Blind** (`blind.tgz` → `blind.cpp`).

- Milalao vs moteur · Live (Stockfish vs moteur) · SPRT · Matrice · Calibrage (UCI_Elo)
- Moteur: import (ELF / .zip / .tgz), fafana, update version (GitHub Releases)
- Build: `.github/workflows/build.yml` → compile blind.tgz amin'ny NDK, SVG→PNG, APK

## Fampiasana
1. Apetaho amin'ny GitHub repo, push `main` → Actions → artifact `Blind-x.y.z` (APK).
2. Ho an'ny update ao anaty app: `git tag v1.0.0 && git push --tags` → Release misy APK.
3. Build local: `bash scripts/svg2png.sh` + apetraho `libblind.so` ao `app/src/main/jniLibs/<abi>/`.

Fanamarihana: `targetSdk 28` no ilaina mba hahafahan'ny app mampandeha ny moteur nalaina avy any ivelany (Android 10+ no manemotra izany raha targetSdk ≥ 29).
APK sonia amin'ny `keystore/joro.jks` (mitovy foana, mba hahafahan'ny update mijanona).

## Stockfish integré
Ny workflow dia manangona sy mamorona Stockfish `sf_17.1` (official-stockfish/Stockfish, GPLv3) amin'ny NDK ho `libstockfish.so`
(arm64-v8a + armeabi-v7a) ao anaty APK. Tsy mila mampiditra binaire intsony: miseho ao amin'ny lisitry ny moteur ho "Stockfish (integré)".
Source: https://github.com/official-stockfish/Stockfish (tag sf_17.1).

## Pipeline fanatsarana
Training → profil isaky ny opening · SPRT (ao amin'ny Training: provisoire vs taloha) · Update moteur · Calibrage (Elo vs Stockfish) · Release. (Nesorina ny SPSA: ny Training no nanolo azy.)
Ny profil default ao anaty APK dia avy amin'ny `app/src/main/assets/default_profile.txt` (Name=value isaky ny andalana).

## Import / export moteur
- Import: binaire ELF, `.zip` / `.tgz` / `.tar` misy ELF, na source `.cpp` (na archive misy source).
- Source → "Compile cloud": alefa any amin'ny repo (`engines_src/<id>/`), `compile-engine.yml` no mamorona ny binaire ho an'ny ABI telo ary mamoaka Release `engine-<id>`; ny app no mampidina ny mifanaraka amin'ny finday. Mila repo PUBLIC + token GitHub (Contents + Actions write).
- Export: ny moteur rehetra (anisan'ny integré) azo avoaka ho `.zip` na `.tgz`.
- Milalao/Live: afaka misafidy profil Blind (default, base, release) isaky ny lafiny.

## Time control · livre d'ouvertures · famerenana asa
- Time control: `movetime`, `Base+Inc` (horloge marina, resy amin'ny fotoana), `nodes`, `depth` — iombonana amin'ny SPRT/Matrice/Calibrage/Live.
- Livre: import `.epd`, `.pgn` (SAN) na lisitry FEN → ouverture mitovy ho an'ny lalao roa (paire). Raha tsy misy livre: 4 ply kisendrasendra.
- Checkpoint: SPRT/Matrice/Calibrage dia voatahiry isaky ny lalao; rehefa nijanona ny app dia miseho ny "Tohizo" ao amin'ny tab Fitsapana.

## Fanatsarana vaovao
- Milalao: horloge (Base+Inc), undo, promotion safidy, FEN/PGN import, PGN copy, lisitry hetsika (SAN) azo tsindrina (jereo ny toerana taloha).
- Tantara: ny fitsapana vita rehetra (daty, TC, moteur, valiny) azo jerena, zaraina (share) na fafana.
- Notification rehefa vita ny fitsapana (SPRT H1/H0, Calibrage...).
- CI: job `engine-test` (UCI, perft, go depth/nodes/movetime/wtime, mat en 1) alohan'ny APK.

## Analyse lalao (game review)
Aorian'ny lalao (Milalao na Live) dia misy bokotra **📊 Review**; Stockfish integré (MultiPV 2) no mandinika ny toerana rehetra.
- Sokajy: Brilliant `!!`, Great `!`, Best `★`, Excellent `✔`, Good `✓`, Inaccuracy `?!`, Miss `✗`, Mistake `?`, Blunder `??`.
- Fiandohana: fahaverezan'ny sandan'ny fandresena (win%) raha ampitahaina amin'ny hetsika tsara indrindra; Brilliant = sorona sombin-javatra (SEE) mbola tsara; Great = hetsika tokana (≥15% lavitra noho ny faharoa); Miss = tsy nanararaotra ny fahadisoan'ny mpifanandrina.
- Accuracy isaky ny sisiny + Game rating (fanombanana Elo avy amin'ny ACPL — tsy marina tanteraka), courbe d'évaluation, lisitry ny hetsika misy loko, "Copier PGN annoté".
- Fisehoana (toa ny chess.com): card "Game Review" (Accuracy + Game Rating isaky ny sisiny + isan'ny sokajy misy icône boribory), eval bar, badge eo amin'ny efitra niafara ny hetsika, anamanana maitso ho an'ny hetsika tsara kokoa (azo vonoina), courbe azo tsindrina.
- Lalao voatahiry: lalao rehetra vita (Milalao + Live, hatramin'ny 60) dia voatahiry ho azy (`filesDir/games/*.json`) miaraka amin'ny review raha efa vita; lisitra ao amin'ny tab **Review** (Jereo review / PGN / Fafao). Tsy very rehefa mihidy ny app.
- Book: `assets/openings.tsv` (eco <TAB> anarana <TAB> hetsika SAN). Ny hetsika anatin'ny ouverture hatrany am-piandohana dia sokajy **Book 📖** (accuracy 100%), ary aseho ny anaran'ny ouverture. Azo ampitomboina ny tabilao (andalana tsy mety dia lavina; ny unit test no manamarina).
- Bokotra **⇅ Vadiho** ao amin'ny review (ho azy raha Mainty no nilalao).
- Unit test: `ReviewTest.kt` (classification, accuracy, rating, book, ary `Analysis.build` amin'ny evals voafantina).
- **Retry** (🎯 ao amin'ny review): mifantina ireo hadisoana (Inaccuracy/Mistake/Miss/Blunder), asehoy ny toerana alohan'ny hetsika, ary tsindrio ny hetsika tsara kokoa; misy "💡 Asehoy ny valiny", sivana Fotsy/Mainty/Roa.
- **PV**: ny andalana tsara indrindra (SAN, hatramin'ny 8 plies) dia aseho isaky ny hetsika ary voatahiry miaraka amin'ny review.
- **Forced**: toerana manana hetsika ara-dalàna tokana dia sokajy "Forced →" ary tsy ampidirina amin'ny Accuracy/ACPL.
- **Calibrage Game Rating**: tab Review > "Manomboka calibrage" (Stockfish UCI_Elo 1400…3000 samy milalao, dinihina amin'ny ms mitovy amin'ny fanadihadiana, ACPL -> Elo, interpolation). Voatahiry ao amin'ny SharedPreferences `ratingcalib`; "Default" no averina amin'ny formula voalohany.

## Firafitry ny repo (GitHub)
Ao amin'ny repo dia ireto ihany:
- `.github/workflows/build.yml`
- `joro-app.tgz`  (ny tetikasa manontolo, tsy misy `.github`)

Ny action (`build.yml`) no manaisotra ny `joro-app.tgz` ao amin'ny `proj/`, avy eo manao ny build rehetra ao anatiny
(moteur Blind, Stockfish NDK, test, APK). Raha hanova kaody: manaova tgz vaovao (`tar -czf joro-app.tgz joro-app`
tsy misy `.github`) ary soloy ilay taloha. Mba hanamora ny anarana dia tsara ny `joro-app.tgz` (tsy misy toerana foana),
fa hitan'ny action koa ny `joro app.tgz`. Ny `compile-engine.yml` (import moteur avy amin'ny app) dia mijanona ho rakitra
hafa ao amin'ny `.github/workflows/`; mampiasa `engines_src/` ao amin'ny fototry ny repo izy, fa tsy ao anaty tgz.

## Moteur v0.6: lanja azo tune-na (ho an'ny tab Training)
- Lanja rehetra (king safety, castling, development, rook, pion, null move, LMR, RFP...) dia UCI option (`setoption name <Anarana> value <int>`), default = lanja taloha. Lisitra feno: baiko `params` (`param NAME value default min max group scale`).
- `evaltrace` (position ankehitriny): `group <anarana> <cp>` (Material+PST, Positional, KingSafety, Attack, Endgame, Opening, Ghost, OpeningPotential) ary `feat <lanja> <net> <cp> <active>`; net = feature fotsy − mainty, cp = net*lanja/scale (fotsy POV). `active 0` = lanja opening tsy mihetsika (Opening=false / tsy opening position).
- `searchstats` (cumulative, averina amin'ny `ucinewgame` na `searchstats reset`): null_try/null_cut, rfp_cut, tt_cut, lmr_try/lmr_research, beta_cut/first_cut, nodes_q.
- Fanamarinana: `bench 8` = 1052366 nodes (Blind 1.2) (tsy miova rehefa default), `scripts/uci_test.sh`.

### Profil isaky ny opening (moteur v0.7)
- `oprof add <id> [side w|b|both] [fen <FEN>] [moves m1 m2 ...] set <Lanja> <value> ...` : mamaritra opening (position farany) sy ny lanja overrides. `oprof clear | remove <id> | list | active`.
- Ny moteur mandrefy ny **key an'ny position** (tsy ao anatiny ny ep) amin'ny dingana rehetra amin'ny `position ... moves ...`; mandeha na manomboka amin'ny FEN, na amin'ny move, na transposition. Ny position **lalina indrindra** no mandresy (ohatra `e4` ankapobeny + `e4 c5` manokana). Rehefa nifanaraka dia mijanona ny profil mandritra ny lalao; foanana ny TT rehefa miova.
- `setoption` mitoetra ho lanja base; ny override ihany no mibaiko raha mihetsika ny profil. `evaltrace` aseho ao ny `profile <id|none>`.
- Fampiasana ao amin'ny SPRT opening: moteur A = `oprof add` + FEN opening; moteur B = tsy misy oprof (base). Samy manomboka amin'ny FEN mitovy.
- `side w|b`: profil mihetsika raha ny moteur no mitondra ny sisiny voalaza (stm amin'ny position farany = ny moteur rehefa `go`); `both` (default) = roa.

## Tab Training (fampiofanana opening)
1. **Fanombohana:** SAN (`e4`, `e4 c5`) na FEN, anarana, sisiny ampiofanina. Ny `Training` dia mamorona lalao misy **Undo**.
2. **Isaky ny hetsika** safidio: ✋ Manuel (tsindrio ny board), ⚙ Moteur ▶ (Blind, ms), 🐟 SF ▶ (Stockfish, Elo voafetra). Hetsika iray isaky ny tsindrio (tsy continu), ho an'ny sisiny roa.
3. **Statistique** (avy amin'ny `evaltrace`): vondrona + lanja voasokajy araka ny |cp| (net, cp, moy), ★ = lanja vaovao; search stats (null move, LMR, RFP, TT).
4. **Fianarana:** rehefa nandresy ny sisiny ampiofanina (na "✔ Fandresena"), `🎓 Alaina ny lanja` dia mandrefy ny toerana rehetra amin'io fandresena farany io ihany. Salan'ny feature (POV mpandresy) > 0 → ampitomboina ny lanja, < 0 → ahena. Azo on/off sy ovaina (+/−) isaky ny lanja. Lanja search tsy tafiditra (SPRT no mitsara).
5. **Apply (provisoire)** → profil `<opening>_<w|b>` (`OProfiles`), mbola tsy update moteur.
6. **SPRT opening ihany:** moteur A = profil provisoire, B = taloha; lalao manomboka amin'ny position fototra + defense rehetra ao amin'ny `openings.tsv` mandalo amin'io position io (`OpeningBook.continuations`, `playGame(prefix=...)`).
7. **✔ Update moteur** (lasa lanja nekena, ampiasain'ny Blind `@default` rehetra) na **✖ Delete experience** (foanana ny provisoire).
- Ny profil dia mihetsika amin'ny sisiny ampiofanina ihany (`oprof ... side`), fa tsy amin'ny sisiny hafa.
- Fanamarihana: tsy voakajy tamin'ity tontolo ity ny code Kotlin (tsy misy compiler); ny moteur C++ sy ny lojika fianarana (Python mirror) ihany no nodinihina. Mba hamarinina amin'ny `./gradlew testDebugUnitTest assembleDebug`.

## Moteur default: Blind 1.3
- `blind.tgz` → `blind/blind.cpp` = **Blind 1.0** (Race/ETA, Clean Move, Opening2 castle structure, Storm, SameSidePen, Opening Guard, Book + BookCheck) **+ sosona Training** (`params`, `evaltrace`, `searchstats`, `oprof`, lanja 43 azo `setoption`). `bench 8` = 1052366 nodes, mitovy tanteraka amin'ny Blind 1.0 tsy misy ny sosona Training.
- `evaltrace` dia manana vondrona vaovao: `CastleStruct`, `Storm`, `Race` (miampy `Opening`, `Ghost`...). Ny lanja int an'ny moteur 1.0 (`RaceW/Cap/Alert/Margin`, `Opening2Cap`, `StormCap`, `SameSidePen`, `BookMargin`...) dia ao amin'ny `params` ary azo ovaina amin'ny `oprof ... set`, fa tsy misy "feature" linear ho an'ny fianarana ho azy (ny vondrona ihany no aseho).
- Ny Training (moteur sy SPRT) dia mampiasa `Opening=true;Book=false` mba tsy hanilika ny search ny book anatiny.
- Ny moteur 1.0 dia miadana kokoa (~1.5M nps vs ~3.6M amin'ny 0.5, noho ny Race/ETA sy ny castle terms).

## Ghost view, Race view, fanapahan-kevitra ary tanjona (moteur 1.2 + Training)
**Moteur (baiko vaovao, tsy mampiova ny search raha tsy alefa; `bench 8` = 1052366):**
- `ghostview [w|b] [king <case>] [heat]`: Ghost an'ny sisiny mpanafika: zone, case voasaron'ny ghost (tsy misy defense) vs tena izy, voasakana, malalaka, **future** (pattern pièce), ETA, **defense manakana** (`def`, vidin'ny fanalana 1..3, `by` = mpanafika azy) ary pion shield. `king <case>` = what-if (afindra ny king mpanohitra), `heat` = isa ghost raha eo amin'ny case rehetra ny king (`heat <case> <score> <tempo> <voadona>`).
- `raceview`: ETA sy **drafitra ataka voasokajy** (pièce 2, fohy indrindra aloha; plan 1 = ETA tena ampiasain'ny moteur) isaky ny sisiny, defense, ary `verdict` (care/letgo/none).
- `decision care|letgo|take|auto [w|b]`: **CARE** = mitandrina ny ataka mpanohitra; **LET IT GO** = tsy miraharaha, mitohy ny ataka; **LET IT TAKE** = avela haka ny pièce ahy: compensation material hatramin'ny `TakeCap` (300) raha misy ataka azo atao (ETA < 40). Voafafa amin'ny `ucinewgame`.
- `target <case>|off`: tanjona = defense hofafana. Bonus `TargetBonus` (150) rehefa nihena ny isan'io karazana pièce io, sombin'ny bonus raha voadona (hitarika ny search; tsy porofo). `evaltrace` dia manana vondrona `Take` ary `Target`.
- Test: `bash scripts/uci_test.sh <joro>` ary `python3 scripts/view_test.py <joro>` (fifandraisana amin'ny `ghostThreat`/`attackEta` tena izy, what-if, heatmap, decision, target).

**Tab Training:**
- `👻 Ghost` / `🏁 Race` (eo ambanin'ny bokotra Moteur/SF) manokatra **sandbox**: Manuel / ⚙ Moteur ▶ / 🐟 SF ▶ / **Undo** dia mandeha ao, ary **✔ Apply ao amin'ny lalao** (mitazona ny hetsika) na **↩ Annuler** (miverina amin'ny toerana nisokafan'ny view).
- Ghost: board misy loko (manga zone, maitso voasaron'ny tena izy, volomparasy ghost ihany, mavo voasakana, mena malalaka, peratra mavo = future); `Hanafina ny defense` = board ghost (afindra ny king: tsindrio azy, avy eo ny case); `Heatmap`; lisitry ny defense manakana miaraka amin'ny **🎯** hanendrena tanjona.
- Race: ETA roa, verdict, drafitra ataka voasokajy (tsindrio hanamarika eo amin'ny board), defense mpanohitra (🎯).
- **CARE / LET IT GO / LET IT TAKE / AUTO** ary ny **tanjona** dia alefa amin'ny moteur alohan'ny `go` isaky ny hetsika ataony ho an'ny sisiny ampiofanina (ny sisiny hafa: auto). Ny tanjona dia aseho "VOAFAFA ✔" rehefa nihena ny pièce, miaraka amin'ny ETA taloha → ankehitriny.

## Piece Power (moteur 1.3 + Training ⚡ Power)
Herin'ny pièce tsirairay (N B R Q) = **0..100%**: **liberty 40%** (case azo andehanana *azo antoka*: tsy voadon'ny pion/pièce kely sy tsy voaro ny mpanohitra) + **potential 20%** (case hisokatra raha mihetsika/miala ny pion ahy mpanakana; `open` = hisokatra amin'ny hetsika pion, `lock` = mbola mikatona) + **safety/escape 20%** (raha voadona: mbola afaka mandositra ve) + **adidy 20%** (defense ny zone king ahy, attack ny zone king mpanohitra, pièce arovana/voadona, andalana mankany amin'ny king). **King** = escape (case azo ialana).
- Tag: `weak` (<33%), `strong` (≥66%), `trapped`, `hanging`, `selfblock` (pièce ahy manakana ny pion mpanakana: ohatra Bd3 + d2), `locked`, `passive`, `cramped`.
- Moteur: `powerview` (isaky ny pièce: isa, `libsq`/`xrsq`/`dutysq`, tag; voasokajy araka ny power). Option `PowerOn` (0 default), `PowerW` (30), `PowerCap` (150): term eval = `PowerW × Σ v(pc) × (power − 50) / 100` (v: N 1, B 1, R 1.5, Q 2), fotsy − mainty. **Tsy mihetsika raha PowerOn=0** (`bench 8` = 1052366); atao SPRT aloha (azo atao per-opening amin'ny profil: `PowerOn=1`) vao ampiasaina. `evaltrace`: vondrona `Power` (na `PowerPotential` raha tsy mihetsika) + feature `PowerW` (azo ianarana).
- Ghost: ny `def` tsirairay dia misy `pw` (power an'ilay defense); ny defense malemy + fanalana mora no tanjona mora indrindra (`🎯 Tanjona mora indrindra`).
- Race: `gfuture` (future ghost an'ny sisiny roa), `first` (iza no tonga aloha sy elanelana), `suggest` (care / letgo / take ho an'ny sisiny roa; ★ eo amin'ny bokotra fanapahan-kevitra + `Ekeo`).
- Training ⚡ Power: tabilao (**mainty = ankavia, fotsy = ankavanana**), voasokajy araka ny power; tsindrio pièce iray: maitso = lalana azo antoka, manga = hisokatra raha mihetsika pion, mavo = adidy. Peratra mena = malemy, maitso = mahery. Ny moteur Training dia mampiasa `PowerOn=1` (statistique sy fianarana); ny SPRT dia mampiasa ny default, ka ny profil (misy `PowerOn=1` raha misy lanja Power nofidina) no andramana.
- Test: `python3 scripts/power_test.py <joro>` (ohatra e4 → Bf1/Qd1 mitombo, Bd3 → Bc1 `selfblock`, rook + file misokatra, king escape, symmetry mirroir, eval, race).

### Pin ao amin'ny Power (v0.8)
- Pièce (N/B/R/Q) voafatotra amin'ny king ahy (absolute pin) dia misy tag `pinned` (**PIN** ao amin'ny UI). Tsy afaka mihetsika afa-tsy ao amin'ny tsipika fatorana; raha tsy misy hetsika mihitsy (ohatra: Kisoa voafatotra, na Fanta voafatotra amin'ny file) dia **power 0%**.
- Test: `scripts/power_test.py` (Pin: ...).

## Theme (v0.9)
- Manaraka ny mode an'ny finday (light/dark) miaraka amin'ny loko contrast avo (`ui/Theme.kt`): fototra fotsy + soratra mainty (light), fototra maizina + soratra fotsy (dark).
- Police lehibe kokoa: soratra kely indrindra 13sp, soratra mahazatra 14–16sp, lohateny matevina. Ny loko sokajy review (Best, Good, Inaccuracy...) dia ovaina ho manjombona/mazava araka ny mode (`rd()`).

## Profil Training: Release + Rollback (v0.10)
- **Release**: ao amin'ny Training (na Fitsapana > Pipeline) dia misy bokotra **📋 Copier profil nekena (release)** (rehetra) ary **📋 Copier** isaky ny profil. Andalana `oprof add <id> side <w|b|both> fen <FEN> set <Lanja> <value> ... # name=<anarana>`.
  Apetaho ao amin'ny `app/src/main/assets/default_oprofiles.txt` → commit → `git tag vX.Y.Z`. Rehefa mivoaka ny app dia ampidirina ny profil ao amin'ny assets raha tsy mbola ao amin'ny finday (mitovy id) ary tsy nofafan'ny mpampiasa; ny profil efa ao amin'ny finday no tsy ovaina.
- **Rollback**: isaky ny "✔ Update moteur" dia voatahiry ny version taloha (hatramin'ny 10): daty, isan'ny lanja, valin'ny SPRT nanaiky ny vaovao. Ao amin'ny card an'ny profil: **↩ Rollback** → asehoy ny fiovana (`A 5→3, B -→9`) → **Avereno ity version ity**. Ny version ankehitriny dia voatahiry koa ka azo averina indray; foana ny valin'ny SPRT taloha (tsy mifanaraka intsony amin'ny version vaovao).
- Test: `OpTextTest.kt` (export/import andalana, fiovana).

## Pin tune-na, Power ho an'ny pion sy tactics, SPRT parallèle (v0.11)
**Moteur (UCI option, group `power`; default = 0 = tsy miova ny fihetsika taloha; `bench 8` = 1052366; mihetsika rehefa `PowerOn=1` ihany):**
- `PinPenalty` (0..100): power % esorina amin'ny pièce/pion voafatotra amin'ny king fa mbola afaka mihetsika ao amin'ny tsipika.
- `PinStuck` (0..50): power % an'ny pièce/pion voafatotra ary tsy afaka mihetsika mihitsy (taloha: 0% mivantana ao anaty kaody).
- `RelPinPenalty` (0..100): relative pin amin'ny **Queen** (B/R mpanafika → pièce ahy → Queen ahy aoriana). Tag `relpin`.
- `SkewerPenalty` (0..100): pièce lehibe (Q/R) alohan'ny pièce kely; ny slider mpanafika dia kely sandany noho ny pièce voadona ary tsy azon'ny pièce iray alaina maimaim-poana. Raha king no aloha (skewer amin'ny check) dia ny pièce aoriana no voatsindry. Tag `skewer`.
- `DiscBonus` (0..60): discovered attack. Pièce ahy (aloha) manakana ny slider ahy mankany amin'ny tanjona mpanohitra (king 1.0, Queen 0.9, Rook 0.6, minor tsy voaro 0.4) ary afaka mivoaka ny tsipika → `bonus = DiscBonus × lanja` ho an'ny pièce aloha, tapany ho an'ny slider. Tag `disc`.
- `PowerPawn` (0..200, scale 100): sandan'ny pion ao amin'ny Power (100 = mitovy amin'ny Knight). Pion: liberty 40% (hetsika azo antoka, double push 1/4) + potential 20% (rank, passed, voaro pion) + safety 20% + adidy 20% (miaro pièce, ataka zone king, escudo king, afovoany). Ireo Pin/RelPin/Skewer/Disc dia mihatra amin'ny pion koa.
- `powerview [pawns]`: aseho ny pion (`pawns` na PowerPawn > 0); `side ... avg` dia N/B/R/Q ihany. Tag vaovao: `relpin`, `skewer`, `disc`.
- `evaltrace`: feature `PinPenalty`, `PinStuck`, `RelPinPenalty`, `SkewerPenalty`, `DiscBonus`, `PowerPawn` (cp = net × lanja / scale, voasoratra na dia 0 aza ny lanja, ka ianarana ao amin'ny Training; tsy mihetsika raha tsy `PowerOn=1`). Ny pion dia voakajy foana rehefa evaltrace (na PowerPawn=0).
- Test: `python3 scripts/power_test.py <joro>` (misy fitsapana tag, ny fiovan'ny power mizana araka ny lanja, symmetry mirroir, linearity feature ↔ eval).

**Training / SPRT:**
- **SPRT parallèle**: `Lalao miaraka` (default 2; voafetra 1..cores/2) ao amin'ny Training sy Fitsapana > SPRT. Worker tsirairay = moteur A + B manokana; laharana lalao zaraina (paire), valiny raisina araka ny fahavitany; rehefa H1/H0 dia foanana ny lalao mbola mandeha (`match/ParSprt.kt`, test `ParSprtTest.kt`). Checkpoint mitohy amin'ny isa vita.
- **SPRT ho azy** aorian'ny "Apply (provisoire)" (checkbox, default misy): mampiasa Elo0/Elo1/max/TC/miaraka ao amin'ny Training. Raha mbola misy asa mandeha dia tsy atomboka (hafatra) fa azo alefa amin'ny ▶ SPRT.
- **Fiarovana**: ny "✔ Update moteur" dia tsy azo tsindrina (ary `OProfiles.accept` mamerina false) raha tsy `sprtOk == true` (H1) ho an'ny provisoire ankehitriny. Raha niova ny provisoire teo am-pandehanan'ny SPRT (Apply vaovao) dia tsy voatahiry ny valin'ny SPRT taloha.
- Fianarana: ny lanja manomboka amin'ny 0 (PinPenalty...) dia mampiasa dingana `0.25 × max(4, hi/5)` fa tsy 1 fotsiny.
- Fanamarihana: tsy voakajy tamin'ity tontolo ity ny Kotlin (tsy misy kotlinc/gradle); ny moteur C++ sy ny tests Python ihany no nalefa. Mba hamarinina: `./gradlew testDebugUnitTest assembleDebug`.

### Trap mouse (v0.11b)
- `TrapMouse` (0..100): pièce N/B/R/Q tsy manana square azo antoka intsony (`smob == 0`) fa misy square azo andehanana (`mob > 0`) nosakanan'ny mpanohitra: "mouse". Tsy raisina ny pièce voasakan'ny pion ahy fotsiny (Ra1 any am-piandohana) na ny voafatotra tsy afa-mihetsika (`PinStuck`). Tag `mouse`.
- `TrapCapture` (0..100): fanampiny rehefa mouse ary voadona/tsy voaro koa (trap by capture, `trapped`): sakano aloha ny square ialana, avy eo alaina.
- `TrapNear` (0..100): square azo antoka 1 sisa, ary misy square hafa nosakanan'ny mpanohitra (tag `trapnear`).
- Default 0, mihetsika rehefa `PowerOn=1` ihany; feature `TrapNear/TrapMouse/TrapCapture` ao amin'ny `evaltrace` (ianarana ao amin'ny Training, SPRT amin'ny profil). Tsy mila fanovana Kotlin (lisitry ny params sy tag dia dynamic).

## Anti = desactivation future + Sacrifice (v0.12)
Foto-kevitra: ny hetsika dia mitsinjo ny ho avy ("block it first", "remove it early", "place it first"). Ny **Race (ETA)**, ny **fanatanterahana future** ary ny **fanalana defense** no mifehy ireo lanja rehetra: tsy misy lanja mandeha irery. Group `anti` / `sacrifice` (default 0 = tsy miova ny fihetsika, `bench 8` = 1052366; mihetsika raha misy lanja > 0 na evaltrace; group `Anti` ao amin'ny evaltrace).

**Gate (Race)** — isaky ny lanja dia atao × gate 0..1:
- `deny` (manakana ny future mpanohitra, ETA = moves ilainy): ny ETA ataka ahy dia mialoha kokoa amin'ny `RaceMargin` → **LET IT GO** (gate = `AntiLetGo`%, default 0); mialoha kely → 0.3 / 0.6; tsy mialoha na tsy manana ataka → **CARE** (1.0). Lavitra loatra (> `AntiHorizon` moves) → mihena.
- `own` (future ahy: promotion, ataka, fanalana defense): ny ataka mpanohitra haingana kokoa noho izaho → mihena (0.6 / 0.3 / `AntiLetGo`).
- `decision care|letgo|take` dia mibaiko ny gate ho an'ny sisiny voafidy (care = 1, letgo/take = 0).

**Anti (miaro ny ho avy mpanohitra)** — lanja (cp isaky ny unit) × unit (gate ao anatiny, linear):
- `AntiCastle`: right castling very (na voadona ny lalana) ary tsy mbola nikasty ny king mpanohitra (king safety).
- `AntiDevelop`: lalan'ny N/B mpanohitra mbola any an-trano voasakan'ny ahy (power: `mob − smob`; tsy raisina ny voasakan'ny azy ihany).
- `AntiSqueeze`: trap first: ahena ny lalan-kalehan'ny pièce mpanohitra (Queen sns) alohan'ny hisamborana azy (`smob` kely, voadon'ny ahy).
- `AntiPromote`: pion passed mpanohitra: blockade + fanaraha-maso ny lalana + king ao anaty "square".
- `AntiSupport`: ny king mpanohitra tsy afaka manampy ny pion passed (king-ko akaiky kokoa ny case promotion).
- `AntiDefender`: esorina aloha ny defense mety hanakana ny promotion ahy aoriana (pièce mpanohitra manara-maso ny lalan'ny pion passed ahy).
- `AntiDraw`: sisiny mpanafika (ETA) + pion misakana (locked) + `halfmove` mitombo → ahena ny eval raha mbola mikatona.

**Sacrifice (fanomezana material ho an'ny ho avy)** — compensation raha hijanona ny material (deficit) ary misy future azo atao (Race):
- `SacOpen`: pion sac manokatra diagonale/file mankany amin'ny zone king (deficit ≤ 2 pion × lalana misokatra × urgency × gate).
- `SacMate`: piece sac (hatramin'ny Queen) mba hanala defense ho an'ny checkmate (committed ≥ 2 mpanafika, ETA kely).
- `SacUnlock`: sac manala blockage mba tsy ho draw (`need` mifototra amin'ny pion locked sy `halfmove`).
- Search (`SacDefExt`, `SacOpenExt`, 0/1): sacrifice mamono defense miaro ny zone king, na pion very izay manokatra slider mankany amin'ny zone → lalinina +1 (ao anatin'ny attack context).
- Hafa: `AntiHorizon` (12), `AntiLetGo` (0), `AntiCap` (120 cp).
- Fitsapana: `antiview` (isa isaky ny lanja, ETA), `python3 scripts/power_test.py <joro>` (castle/promote/defender/sac, decision override, mirroir, linearity feature ↔ eval).
- Fetra: ny gate dia mampiasa ny ETA ataka (`attackEta`); raha tsy misy ETA ataka (< 2 mpanafika) dia tsy misy compensation sacrifice. Ny "future" hafa tsy voafaritra dia azo ampiana amin'ny `antiCompute`.

## UI vaovao (v1.0 Blind)
- **Anarana**: ny moteur dia **Blind** (`blind.tgz` → `blind/blind.cpp`, `libblind.so`, UCI `id name Blind 1.3`). Ny `applicationId`/package (`mg.joro.chess`) dia tsy novaina mba hahafahan'ny update mijanona. `EngineStore` mbola mekena `libjoro.so` raha tsy mbola nohavaozina ny workflow build.
- **Theme mahaleo tena**: Maizina / Mazava voafidy ao amin'ny app (top bar ☀/☾ na Réglages), tsy manaraka ny light/dark an'ny finday (`ui/UiPrefs.kt`, `ui/Theme.kt`).
- **Organisation**: top bar + menu ☰ (drawer; tout le temps hita amin'ny efijery ≥ 840dp), bara ambany misy faritra 5 (Lalao · Review · Training · Fitsapana · Moteur) ary tab kely ao anatin'ny faritra (Vs Blind/Live, Moteur/Update/Réglages, Pipeline/SPRT/Matrice/Calibrage/Tantara).
- **Components** (`ui/Components.kt`): `Panel` (azo atsipy), `HoverCard` (hover/press), `SegTabs`, `TwoPane` (board + fanaraha-maso mifanila amin'ny efijery lehibe), `PagedItems` (pagination + lisitra/grid).
- **Pagination**: lalao voatahiry, tantara, moteur, profil, hetsika, lanja Training... Pejy 4/6/10/20 sy lisitra/grid azo ovaina ao amin'ny Réglages.
- Fanamarihana: tsy voakajy tamin'ity tontolo ity ny Kotlin (tsy misy Android SDK/network). Mba hamarinina: `./gradlew testDebugUnitTest assembleDebug`.
