#!/usr/bin/env bash
# Mamadika ny SVG (assets_src/pieces) ho PNG ao amin'ny res/drawable-nodpi (zoom 0.5, mitovy ny refy amin'ny sombin-javatra rehetra)
# Mila: librsvg2-bin  (sudo apt install librsvg2-bin)
set -euo pipefail
out=app/src/main/res/drawable-nodpi
mkdir -p "$out"
for f in assets_src/pieces/*_svg_withShadow.svg; do
  b=$(basename "$f" _svg_withShadow.svg)
  rsvg-convert -z 0.5 "$f" -o "$out/$b.png"
done
ls "$out"
