import math, subprocess, sys

BIN = sys.argv[1] if len(sys.argv) > 1 else "./joro"
FENS = [
    "r1b2rk1/pp1nqppp/2p1pn2/3p4/2PP4/2NBPN1Q/PP3PPP/R1B2RK1 w - - 0 10",
    "r1bq1rk1/pppn1ppp/4p3/3pP3/1b1P1N1Q/2N5/PPP2PPP/R1B2RK1 w - - 0 10",
    "r2q1rk1/pp1bppbp/2np1np1/8/2BNP3/2N1B3/PPP1QPPP/R4RK1 w - - 0 10",
    "r4rk1/pp3ppp/2n1b3/q2pP3/3Q4/2P2N2/P4PPP/R1B2RK1 w - - 0 15",
    "r1b2rk1/ppp2ppp/2n2n2/3pp3/1b2P2q/2NP1N2/PPPBBPPP/R2Q1RK1 b - - 0 8",
    "2r3k1/5ppp/p3p3/1p6/3P4/1B2Q1P1/P4P1P/6K1 w - - 0 1",
    "6k1/pp3ppp/8/3q4/8/1Q3N2/PP3PPP/4R1K1 w - - 0 1",
    "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1",
    "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 5",
    "r1bq1rk1/ppp2ppp/2n5/3pP3/1b1Pn3/2N2N2/PP2BPPP/R1BQ1RK1 w - - 0 9",
]
fails = 0


def run(cmds):
    return subprocess.run([BIN], input="\n".join(cmds) + "\nquit\n", capture_output=True, text=True).stdout.splitlines()


def check(name, cond, extra=""):
    global fails
    if not cond:
        fails += 1
    print(("ok   " if cond else "FAIL ") + name, extra)


def kv(line):
    t = line.split()
    return {t[i]: t[i + 1] for i in range(0, len(t) - 1, 1)}


def lst(s):
    return [] if s == "-" else s.split(",")


def getline(out, prefix):
    r = [l for l in out if l.startswith(prefix + " ") or l == prefix]
    return r[0] if r else None


# ---------------------------------------------------------------- ghostview: consistency with ghostThreat
bad = 0
n = 0
for fen in FENS:
    for side in ("w", "b"):
        o = run([f"position fen {fen}", f"ghostview {side}"])
        h = kv(getline(o, "ghostview"))
        p = kv(getline(o, "parts"))
        cv = kv(getline(o, "cover"))
        score = int(h["score"])
        total = int(p["rcov12"]) + int(p["cost6"]) + int(p["check"])
        pv = float(p["pattern"])
        lo, hi = math.floor(total + pv - 0.051), math.floor(total + pv + 0.051)
        ok1 = lo <= score <= hi
        zone = lst(getline(o, "zone").split()[1]); gcov = lst(getline(o, "gcov").split()[1])
        blocked = lst(getline(o, "blocked").split()[1]); free = lst(getline(o, "free").split()[1])
        ok2 = len(gcov) == int(cv["ghost"]) and len(blocked) == int(cv["blocked"]) and len(free) == int(cv["free"])
        ok3 = len(gcov) + len(blocked) + len(free) == len(zone)
        n += 1
        if not (ok1 and ok2 and ok3):
            bad += 1
            print("   BAD", fen[:30], side, score, total, pv, ok1, ok2, ok3)
check("ghostview consistent with ghostThreat (score parts, zone partition)", bad == 0, f"{n} cases")

# what-if: king on its real square == default; moving king changes the numbers; occupied squares rejected
fen = FENS[0]
base = run([f"position fen {fen}", "ghostview w"])
real = kv(getline(base, "ghostview"))["real_king"]
same = run([f"position fen {fen}", f"ghostview w king {real}"])
check("what-if king on real square == default", kv(getline(same, "ghostview"))["score"] == kv(getline(base, "ghostview"))["score"])
moved = run([f"position fen {fen}", "ghostview w king h8"])
mh = kv(getline(moved, "ghostview"))
check("what-if king moved (h8) reported", mh["king"] == "h8" and mh["real_king"] == real, f"score {mh['score']} vs {kv(getline(base, 'ghostview'))['score']}")
occ = run([f"position fen {fen}", "ghostview w king e7"])
check("what-if on occupied square rejected", any("error" in l for l in occ))

# heatmap: entry for the real king square equals the default score; every entry has score/tempo/attacked
hm = run([f"position fen {fen}", "ghostview w heat"])
heat = {l.split()[1]: l.split()[2:] for l in hm if l.startswith("heat ")}
check("heatmap has real king entry == default score", real in heat and heat[real][0] == kv(getline(hm, "ghostview"))["score"], f"{len(heat)} squares")
check("heatmap excludes squares occupied by attacker's own pieces", "a1" not in heat and "g1" not in heat)

# ---------------------------------------------------------------- raceview: rank 1 == engine ETA (also == existing `race` command)
bad = 0
n = 0
for fen in FENS:
    o = run([f"position fen {fen}", "raceview", "race"])
    for side, name in (("w", "White"), ("b", "Black")):
        hl = [l for l in o if l.startswith(f"raceview side {side} ")][0]
        h = kv(hl)
        eta = int(h["eta"])
        refl = [l for l in o if l.startswith(f"{name} attack: eta ")][0].split()
        ref = int(refl[3])
        idx = o.index(hl)
        plans = []
        for l in o[idx + 1:]:
            if l.startswith("raceview") or l.startswith("race "):
                break
            if l.startswith("plan "):
                plans.append(int(l.split()[3]))
        n += 1
        ok = eta == ref and (not plans or plans[0] == eta or eta >= 40) and plans == sorted(plans)
        if not ok:
            bad += 1
            print("   BAD", fen[:30], side, eta, ref, plans[:3])
check("raceview: plan #1 == attackEta == `race` command, plans sorted", bad == 0, f"{n} cases")
o = run([f"position fen {FENS[6]}", "raceview"])
vs = [l for l in o if l.startswith("verdict")]
# verdict <c> = ahoana no fijerin'ny sisiny c ny ataka MPANOHITRA: fotsy manafika (ETA 9), mainty tsy manafika
check("raceview verdicts (white: no black attack -> none; black faces white's attack -> care/letgo)", len(vs) == 2 and vs[0].split()[-1] == "none" and vs[1].split()[-1] in ("care", "letgo"), " | ".join(vs))

# ---------------------------------------------------------------- decision
F = FENS[0]
base = ["setoption name Opening value true", "setoption name GhostAlert value 0", "setoption name RaceAlert value 0", f"position fen {F}"]


def trace(extra):
    o = run(base + extra + ["evaltrace"])
    g = {l.split()[1]: float(l.split()[2]) for l in o if l.startswith("group ")}
    h = [l for l in o if l.startswith("evaltrace")][0].split()
    return int(h[4]), g, h


e0, g0, h0 = trace([])
e1, g1, _ = trace(["decision auto"])
check("decision auto == baseline (eval and header)", e0 == e1 and h0[-1] == "auto", f"{e0}")
e2, g2, h2 = trace(["decision care w"])
check("decision care w changes Ghost (white counts black's attack)", g2["Ghost"] != g0["Ghost"] and h2[-1] == "care", f"{g0['Ghost']} -> {g2['Ghost']}")
e3, g3, _ = trace(["decision letgo b"])
check("decision letgo b ignores white's threat (Ghost shrinks)", abs(g3["Ghost"]) < abs(g0["Ghost"]), f"{g0['Ghost']} -> {g3['Ghost']}")
e4, g4, _ = trace(["decision take b"])
check("decision take b gives Take compensation to the side behind in material", g4["Take"] < 0 and g4["Take"] >= -300, f"Take {g4['Take']}")
e5, g5, _ = trace(["decision take w"])
check("decision take w: no compensation when not behind", g5["Take"] == 0)
e6, g6, h6 = trace(["decision take b", "ucinewgame", f"position fen {F}"])
check("ucinewgame resets decision", h6[-1] == "auto" and g6["Take"] == 0)
check("groups still sum to eval with decision/target", True)
o = run(base + ["decision take b", "evaltrace"])
gs = {l.split()[1]: float(l.split()[2]) for l in o if l.startswith("group ") and l.split()[1] not in ("OpeningPotential", "PowerPotential")}
ev = int([l for l in o if l.startswith("evaltrace")][0].split()[4])
check("group sum == eval under decision take", abs(sum(gs.values()) - ev) <= 1, f"{sum(gs.values())} vs {ev}")

# ---------------------------------------------------------------- target: eliminate a defender
T = "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 5"
setup = ["setoption name Opening value false", f"position fen {T}", "target f6"]
o = run(setup)
check("target f6 accepted (knight)", any(l.startswith("target ok f6 N cnt 2") for l in o), [l for l in o if l.startswith("target")])
o = run(["position startpos", "target e4"])
check("target on empty square rejected", any(l.startswith("target error") for l in o))


def tgt(moves):
    cmds = setup + [f"position fen {T} moves {moves}" if moves else f"position fen {T}", "evaltrace"]
    o = run(cmds)
    return {l.split()[1]: float(l.split()[2]) for l in o if l.startswith("group ")}


check("target: 0 at start", tgt("")["Target"] == 0)
pressure = tgt("c1g5 a7a6")
check("target: partial bonus when the defender is attacked", 0 < pressure["Target"] < 150, f"{pressure['Target']}")
done = tgt("c1g5 a7a6 g5f6 d8f6")
check("target: full bonus (150) once the defender is eliminated", done["Target"] == 150, f"{done['Target']}")
o = run(setup + ["target off", f"position fen {T} moves c1g5 a7a6 g5f6 d8f6", "evaltrace"])
gg = {l.split()[1]: float(l.split()[2]) for l in o if l.startswith("group ")}
check("target off -> no bonus", gg["Target"] == 0)

# ---------------------------------------------------------------- search under decision/target (no crash, legal move)
for extra in (["decision take b"], ["decision letgo w"], ["decision care w"], ["target f6"]):
    o = run(["setoption name Opening value true", f"position fen {T}"] + extra + ["go depth 6"])
    bm = [l for l in o if l.startswith("bestmove")]
    check("go depth 6 with " + " ".join(extra), len(bm) == 1 and bm[0].split()[1] not in ("(none)", "0000"), bm[0] if bm else "none")

print("failures:", fails)
sys.exit(1 if fails else 0)
