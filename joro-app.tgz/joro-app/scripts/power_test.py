import subprocess, sys

BIN = sys.argv[1] if len(sys.argv) > 1 else "./blind"
fails = 0


# Blind 1.5: ny lanja power/anti/sacrifice dia tsy 0 intsony (default vaovao). Ny test taloha dia mihevitra fa 0 izy ireo,
# ka ampidirina aloha ny setoption 0 ("legacy"); ny setoption ao amin'ny test no mandresy (aorian'izany). run_raw = default marina.
LEGACY = {"PowerOn": 0, "PinPenalty": 0, "PinStuck": 0, "RelPinPenalty": 0, "SkewerPenalty": 0, "DiscBonus": 0, "PowerPawn": 0, "TrapNear": 0, "TrapMouse": 0, "TrapCapture": 0, "AntiCastle": 0, "AntiDevelop": 0, "AntiSqueeze": 0, "AntiPromote": 0, "AntiSupport": 0, "AntiDefender": 0, "AntiDraw": 0, "AntiLetGo": 0, "SacOpen": 0, "SacMate": 0, "SacUnlock": 0, "SacDefExt": 0, "SacOpenExt": 0}


def run_raw(cmds):
    return subprocess.run([BIN], input="\n".join(cmds) + "\nquit\n", capture_output=True, text=True).stdout.splitlines()


def run(cmds):
    return run_raw([f"setoption name {k} value {v}" for k, v in LEGACY.items()] + list(cmds))


def check(name, cond, extra=""):
    global fails
    if not cond:
        fails += 1
    print(("ok   " if cond else "FAIL ") + name, extra)


def pieces(fen, moves=""):
    pos = f"position fen {fen}" + (f" moves {moves}" if moves else "")
    o = run([pos, "powerview"])
    res = {}
    for l in o:
        if l.startswith("piece "):
            t = l.split()
            d = {t[i]: t[i + 1] for i in range(4, len(t) - 1, 2)}
            d["power"] = int(t[5])
            res[(t[1], t[2], t[3])] = d
    sides = {l.split()[1]: int(l.split()[3]) for l in o if l.startswith("side ")}
    return res, sides, o


def mirror(fen):
    parts = fen.split()
    rows = parts[0].split("/")[::-1]
    sw = lambda s: s.swapcase()
    board = "/".join("".join(sw(ch) if ch.isalpha() else ch for ch in r) for r in rows)
    stm = "b" if parts[1] == "w" else "w"
    cast = "".join(sorted((sw(c) for c in parts[2]), key=lambda c: "KQkq".index(c))) if parts[2] != "-" else "-"
    ep = "-" if parts[3] == "-" else parts[3][0] + str(9 - int(parts[3][1]))
    return " ".join([board, stm, cast or "-", ep] + parts[4:])


ST = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

# ---------------------------------------------------------------- Oh1: e4 opens diagonals -> Bishop and Queen get stronger
p0, s0, _ = pieces(ST)
p1, s1, _ = pieces(ST, "e2e4")
check("Oh1: after e4 the f1 bishop gets stronger", p1[("w", "B", "f1")]["power"] > p0[("w", "B", "f1")]["power"] + 15,
      f"{p0[('w', 'B', 'f1')]['power']} -> {p1[('w', 'B', 'f1')]['power']}")
check("Oh1: after e4 the queen gets stronger", p1[("w", "Q", "d1")]["power"] > p0[("w", "Q", "d1")]["power"] + 8,
      f"{p0[('w', 'Q', 'd1')]['power']} -> {p1[('w', 'Q', 'd1')]['power']}")
check("Oh1: white average power rises, black unchanged", s1["w"] > s0["w"] and s1["b"] == s0["b"], f"{s0} -> {s1}")
check("start position symmetric", s0["w"] == s0["b"])

# ---------------------------------------------------------------- Oh2: Bd3 blocks d2 -> the c1 bishop is stuck (weakness)
p2, s2, _ = pieces(ST, "e2e4 e7e5 f1d3")
p3, s3, _ = pieces(ST, "e2e4 e7e5 d2d4 e5d4")
c1 = p2[("w", "B", "c1")]
check("Oh2: Bd3 -> c1 bishop tagged selfblock + weak", "selfblock" in c1["tags"] and "weak" in c1["tags"], c1["tags"])
check("Oh2: c1 bishop much stronger when d4 is played", p3[("w", "B", "c1")]["power"] > c1["power"] + 15, f"{c1['power']} vs {p3[('w', 'B', 'c1')]['power']}")
check("Oh2: Bd3 itself is not selfblocked", "selfblock" not in p2[("w", "B", "d3")]["tags"])

# ---------------------------------------------------------------- Oh3: a rook behind its own pawns (g/h) -> locked; stronger once the file opens (pawn sacrificed)
A = "6rk/6pp/8/8/8/8/PPP2PPP/R2Q2K1 b - - 0 1"     # black rook g8 behind g7 pawn
B = "6rk/7p/8/8/8/8/PPP2PPP/R2Q2K1 b - - 0 1"       # g pawn gone (sacrificed): the file is open
pa, _, _ = pieces(A)
pb, _, _ = pieces(B)
ra, rb = pa[("b", "R", "g8")], pb[("b", "R", "g8")]
check("Oh3: rook behind its g pawn has locked potential", int(ra["lock"]) > 0 or int(ra["open"]) > 0, f"open {ra['open']} lock {ra['lock']}")
check("Oh3: rook power rises when the g file opens", rb["power"] > ra["power"] + 10, f"{ra['power']} -> {rb['power']}")
check("Oh3: open g file gives attack duty toward the king", int(rb["duty"]) > int(ra["duty"]), f"duty {ra['duty']} -> {rb['duty']}")

# ---------------------------------------------------------------- Oh4: king escape squares: blocked escape -> weaker king
K1 = "6k1/5ppp/8/8/8/8/5PPP/6K1 w - - 0 1"          # black king g8: f8, h8 free
K2 = "6k1/5ppp/8/8/8/B7/5PPP/6K1 b - - 0 1"         # bishop a3 covers f8 -> one escape less
k1, _, _ = pieces(K1)
k2, _, _ = pieces(K2)
check("Oh4: king escape squares drop when f8 is covered", int(k2[("b", "K", "g8")]["smob"]) < int(k1[("b", "K", "g8")]["smob"]),
      f"{k1[('b', 'K', 'g8')]['smob']} -> {k2[('b', 'K', 'g8')]['smob']}")
check("Oh4: king power lower when escapes drop", k2[("b", "K", "g8")]["power"] < k1[("b", "K", "g8")]["power"],
      f"{k1[('b', 'K', 'g8')]['power']} -> {k2[('b', 'K', 'g8')]['power']}")

# ---------------------------------------------------------------- trapped / hanging
T = "4k3/8/8/8/8/p7/P7/B3K3 w - - 0 1"      # bishop a1 boxed in by pawn a2 / b2... attacked? simple sanity of ranges
pt, _, _ = pieces(T)
check("power values within 0..100", all(0 <= d["power"] <= 100 and 0 <= int(d["lib"]) <= 100 and 0 <= int(d["pot"]) <= 100 and 0 <= int(d["duty"]) <= 100 for d in pt.values()))
TR = "r3k3/8/8/8/8/8/p7/R3K3 w - - 0 1"
H = "4k3/8/8/3p4/4N3/8/8/4K3 w - - 0 1"      # white knight attacked by pawn d5?? (d5 pawn attacks c4/e4) -> knight attacked by lower piece
ph, _, _ = pieces(H)
kn = ph[("w", "N", "e4")]
check("knight attacked by a pawn has reduced safety unless it can escape", int(kn["safe"]) < 100 or int(kn["smob"]) > 0, f"safe {kn['safe']} smob {kn['smob']}")
TRAP = "4k2N/5p2/6p1/4b3/8/8/8/4K3 w - - 0 1"   # Nh8: f7 (defended by king) and g6 (defended by f7) are bad, bishop e5 attacks h8
ptr, _, _ = pieces(TRAP)
nn = ptr[("w", "N", "h8")]
check("trapped knight: attacked, no safe square -> trapped/hanging, safe 0", "trapped" in nn["tags"] and int(nn["safe"]) == 0, f"smob {nn['smob']} tags {nn['tags']} safe {nn['safe']}")

# ---------------------------------------------------------------- mirror symmetry (colors/ranks flipped): same power, opposite eval term
FENS = [
    "r1b2rk1/pp1nqppp/2p1pn2/3p4/2PP4/2NBPN1Q/PP3PPP/R1B2RK1 w - - 0 10",
    "r1bq1rk1/pppn1ppp/4p3/3pP3/1b1P1N1Q/2N5/PPP2PPP/R1B2RK1 w - - 0 10",
    "r4rk1/pp3ppp/2n1b3/q2pP3/3Q4/2P2N2/P4PPP/R1B2RK1 b - - 0 15",
    "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1",
    "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 5",
    "2r3k1/5ppp/p3p3/1p6/3P4/1B2Q1P1/P4P1P/6K1 w - - 0 1",
    "6k1/pp3ppp/8/3q4/8/1Q3N2/PP3PPP/4R1K1 w - - 0 1",
    "r2q1rk1/pp1bppbp/2np1np1/8/2BNP3/2N1B3/PPP1QPPP/R4RK1 w - - 0 10",
]
bad = 0
for f in FENS:
    m = mirror(f)
    a, sa, _ = pieces(f)
    b, sb, _ = pieces(m)
    wa = sorted(d["power"] for (c, pt_, sq), d in a.items() if c == "w")
    bb = sorted(d["power"] for (c, pt_, sq), d in b.items() if c == "b")
    ba = sorted(d["power"] for (c, pt_, sq), d in a.items() if c == "b")
    wb = sorted(d["power"] for (c, pt_, sq), d in b.items() if c == "w")
    if wa != bb or ba != wb:
        bad += 1
        print("   BAD mirror", f[:30], wa, bb)
check("power is color-symmetric (mirror positions give the same values)", bad == 0, f"{len(FENS)} positions")

bad = 0
for f in FENS:
    m = mirror(f)
    vals = []
    for fen in (f, m):
        o = run(["setoption name PowerOn value 1", f"position fen {fen}", "evaltrace"])
        g = {l.split()[1]: float(l.split()[2]) for l in o if l.startswith("group ")}
        vals.append(g["Power"])
    if abs(vals[0] + vals[1]) > 1e-9:
        bad += 1
        print("   BAD eval mirror", f[:30], vals)
check("Power eval term is antisymmetric under mirroring", bad == 0)

# ---------------------------------------------------------------- eval integration: off by default, on = group + feature
F = FENS[0]
off = run([f"position fen {F}", "evaltrace"])
on = run(["setoption name PowerOn value 1", f"position fen {F}", "evaltrace"])
goff = {l.split()[1]: float(l.split()[2]) for l in off if l.startswith("group ")}
gon = {l.split()[1]: float(l.split()[2]) for l in on if l.startswith("group ")}
check("PowerOn=0: no Power in eval but PowerPotential shown", goff["Power"] == 0 and goff["PowerPotential"] != 0, f"pot {goff['PowerPotential']}")
foff = [l for l in off if l.startswith("feat PowerW ")]
fon = [l for l in on if l.startswith("feat PowerW ")]
check("PowerW feature inactive when off, active when on", foff and foff[0].split()[-1] == "0" and fon and fon[0].split()[-1] == "1", f"{foff} {fon}")
check("PowerOn=1: Power group == potential and changes eval", gon["Power"] == goff["PowerPotential"] and gon["PowerPotential"] == 0)
evoff = int([l for l in off if l.startswith("evaltrace")][0].split()[4])
evon = int([l for l in on if l.startswith("evaltrace")][0].split()[4])
check("eval differs by exactly the Power term", abs((evon - evoff) - gon["Power"]) <= 1, f"{evoff} -> {evon} (Power {gon['Power']})")
gs = {k: v for k, v in gon.items() if k not in ("OpeningPotential", "PowerPotential")}
check("group sum == eval with Power on", abs(sum(gs.values()) - evon) <= 1, f"{sum(gs.values())} vs {evon}")
o = run(["setoption name PowerOn value 1", "setoption name PowerW value 0", f"position fen {F}", "evaltrace"])
g0 = {l.split()[1]: float(l.split()[2]) for l in o if l.startswith("group ")}
check("PowerW=0 -> term 0", g0["Power"] == 0)
o = run(["setoption name PowerOn value 1", "setoption name PowerW value 200", "setoption name PowerCap value 5", f"position fen {F}", "evaltrace"])
gc = {l.split()[1]: float(l.split()[2]) for l in o if l.startswith("group ")}
check("PowerCap clamps the term", abs(gc["Power"]) <= 5)
o = run(["setoption name PowerOn value 1", f"position fen {F}", "go depth 7"])
check("go depth 7 with PowerOn", any(l.startswith("bestmove") and l.split()[1] not in ("(none)", "0000") for l in o))

# ---------------------------------------------------------------- powerview: lists + ranking, defenders carry power, race integration
o = run([f"position fen {F}", "powerview"])
pcs = [l for l in o if l.startswith("piece w ")]
pw = [int(l.split()[5]) for l in pcs]
check("powerview sorted by power desc per side", pw == sorted(pw, reverse=True), pw)
check("powerview has libsq/xrsq/dutysq lists", all(" libsq " in l and " xrsq " in l and " dutysq " in l for l in pcs))
o = run([f"position fen {F}", "ghostview w"])
check("defenders carry power (pw)", any(l.startswith("def ") and " pw " in l for l in o), [l for l in o if l.startswith("def ")][:1])
o = run([f"position fen {F}", "raceview"])
check("raceview has gfuture/first/suggest", sum(l.startswith("gfuture ") for l in o) == 2 and sum(l.startswith("first ") for l in o) == 1 and sum(l.startswith("suggest ") for l in o) == 2,
      [l for l in o if l.startswith(("first", "suggest"))])
fw = [l for l in o if l.startswith("first ")][0].split()
etas = [int(l.split()[4]) for l in o if l.startswith("raceview side")]
adj = [etas[0] - 0.5, etas[1]]        # F: white to move
exp = "w" if adj[0] < adj[1] else "b"
check("raceview 'first' agrees with the ETA race", fw[1] == exp, f"{fw} etas {etas}")
# quiet position without attackers -> no suggestion
o = run(["position startpos", "raceview"])
check("start position: suggest none/letgo consistent", all(l.split()[2] in ("none", "letgo", "care", "take") for l in o if l.startswith("suggest ")))

# ---------------------------------------------------------------- Pin: pièce voafatotra amin'ny king
PN = "4r2k/8/8/8/8/8/4N3/4K3 w - - 0 1"      # Ne2 voafatotra amin'ny Re8 -> tsy afa-mihetsika
PR = "4r2k/8/8/8/8/8/4R3/4K3 w - - 0 1"      # Re2 voafatotra fa afaka mihetsika ao amin'ny file
pn, _, _ = pieces(PN)
pr, _, _ = pieces(PR)
check("Pin: knight pinned -> power 0 + tag pinned", pn[("w", "N", "e2")]["power"] == 0 and "pinned" in pn[("w", "N", "e2")]["tags"], pn[("w", "N", "e2")]["tags"])
check("Pin: rook pinned but can slide on file -> tag pinned, power > 0 but lower than free", "pinned" in pr[("w", "R", "e2")]["tags"] and 0 < pr[("w", "R", "e2")]["power"] < 60, pr[("w", "R", "e2")]["power"])


# ---------------------------------------------------------------- v0.11: PinPenalty / PinStuck / RelPinPenalty / SkewerPenalty / DiscBonus / PowerPawn
def popts(fen, opts, pawns=False):
    cmds = [f"setoption name {k} value {v}" for k, v in opts.items()] + [f"position fen {fen}", "powerview pawns" if pawns else "powerview"]
    res = {}
    for l in run(cmds):
        if l.startswith("piece "):
            t = l.split()
            d = {t[i]: t[i + 1] for i in range(4, len(t) - 1, 2)}
            d["power"] = int(t[5])
            res[(t[1], t[2], t[3])] = d
    return res


def ev(fen, opts):
    cmds = [f"setoption name {k} value {v}" for k, v in opts.items()] + [f"position fen {fen}", "evaltrace"]
    o = run(cmds)
    e = int([l for l in o if l.startswith("evaltrace")][0].split()[4])
    feats = {l.split()[1]: (float(l.split()[2]), float(l.split()[3]), l.split()[4]) for l in o if l.startswith("feat ")}
    return e, feats


ON = {"PowerOn": 1, "PowerCap": 400}
# PinPenalty: rook pinned but can slide -> power drops by exactly PinPenalty; PinStuck: knight pinned without moves -> PinStuck %
r0 = popts(PR, ON)[("w", "R", "e2")]["power"]
r1 = popts(PR, {**ON, "PinPenalty": 20})[("w", "R", "e2")]["power"]
check("PinPenalty=20 lowers a movable pinned rook by 20", r0 - r1 == 20, f"{r0} -> {r1}")
check("PinPenalty default 0 = old behaviour (knight pinned = 0)", popts(PN, ON)[("w", "N", "e2")]["power"] == 0)
check("PinStuck=25 -> stuck pinned knight has power 25", popts(PN, {**ON, "PinStuck": 25})[("w", "N", "e2")]["power"] == 25)
check("PinPenalty does not touch a free (unpinned) piece", popts(PN, {**ON, "PinPenalty": 50})[("b", "R", "e8")]["power"] == popts(PN, ON)[("b", "R", "e8")]["power"])

# relative pin (Bb4 - Nc3 - Qe1)
RP = "4k3/8/8/8/1b6/2N5/8/4QK2 w - - 0 1"
a = popts(RP, ON); b = popts(RP, {**ON, "RelPinPenalty": 30})
check("relative pin to the queen is tagged relpin", "relpin" in a[("w", "N", "c3")]["tags"], a[("w", "N", "c3")]["tags"])
check("RelPinPenalty=30 lowers the pinned knight by 30", a[("w", "N", "c3")]["power"] - b[("w", "N", "c3")]["power"] == 30, f"{a[('w','N','c3')]['power']} -> {b[('w','N','c3')]['power']}")
check("RelPinPenalty leaves the queen alone", a[("w", "Q", "e1")]["power"] == b[("w", "Q", "e1")]["power"])
# a pin to a king is NOT a relative pin; a pawn pinned to a rook is not either
check("absolute pin is not tagged relpin", "relpin" not in pn[("w", "N", "e2")]["tags"])

# skewer: Ra8 (defended by Kb7) attacks Qa4 with Ra1 behind
SK = "r7/1k6/8/8/Q7/8/8/R3K3 w - - 0 1"
a = popts(SK, ON); b = popts(SK, {**ON, "SkewerPenalty": 40})
check("skewer tag on the front queen", "skewer" in a[("w", "Q", "a4")]["tags"], a[("w", "Q", "a4")]["tags"])
check("SkewerPenalty=40 lowers the skewered queen by 40", a[("w", "Q", "a4")]["power"] - b[("w", "Q", "a4")]["power"] == 40, f"{a[('w','Q','a4')]['power']} -> {b[('w','Q','a4')]['power']}")
# undefended slider that the queen can simply capture is not a skewer
SK2 = "r7/4k3/8/8/Q7/8/8/R3K3 w - - 0 1"
check("no skewer when the queen just takes the undefended rook", "skewer" not in popts(SK2, ON)[("w", "Q", "a4")]["tags"])

# discovered attack: Re1, Ne4, black king e8
DC = "4k3/8/8/8/4N3/8/8/4RK2 w - - 0 1"
a = popts(DC, ON); b = popts(DC, {**ON, "DiscBonus": 10})
check("discovered-check potential tagged disc on the knight and the rook", "disc" in a[("w", "N", "e4")]["tags"] and "disc" in a[("w", "R", "e1")]["tags"])
check("DiscBonus=10 raises the front piece by 10", b[("w", "N", "e4")]["power"] - a[("w", "N", "e4")]["power"] == 10, f"{a[('w','N','e4')]['power']} -> {b[('w','N','e4')]['power']}")
check("DiscBonus gives the back slider half", b[("w", "R", "e1")]["power"] - a[("w", "R", "e1")]["power"] == 5, f"{a[('w','R','e1')]['power']} -> {b[('w','R','e1')]['power']}")
DC2 = "4k3/8/8/8/4N3/8/8/3R1K2 w - - 0 1"   # rook not on the e file -> no discovery
check("no disc when the slider does not look at the target", "disc" not in popts(DC2, ON)[("w", "N", "e4")]["tags"])

# pawns
ST0 = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
pw = popts(ST0, {}, pawns=True)
check("powerview pawns lists the 16 pawns", sum(1 for k in pw if k[1] == "P") == 16)
check("without 'pawns' / PowerPawn=0 no pawn lines", not any(k[1] == "P" for k in popts(ST0, {})))
check("PowerPawn>0 shows pawns by itself", sum(1 for k in popts(ST0, {"PowerPawn": 100}) if k[1] == "P") == 16)
pp = popts("4k3/8/8/8/1b6/8/3P4/4K3 w - - 0 1", ON, pawns=True)[("w", "P", "d2")]
check("pawn pinned to the king with no move -> power 0 (PinStuck)", pp["power"] == 0 and "pinned" in pp["tags"], pp["tags"])
pf = popts("4k3/8/8/8/8/8/3P4/4K3 w - - 0 1", ON, pawns=True)[("w", "P", "d2")]["power"]
pp2 = popts("4k3/8/8/8/8/3p4/3P4/4K3 w - - 0 1", ON, pawns=True)[("w", "P", "d2")]["power"]
check("blocked pawn is weaker than a free pawn", pp2 < pf, f"{pp2} < {pf}")
pas = popts("7k/8/8/P7/8/8/8/4K3 w - - 0 1", ON, pawns=True)[("w", "P", "a5")]["power"]
npas = popts("7k/1p6/8/P7/8/8/8/4K3 w - - 0 1", ON, pawns=True)[("w", "P", "a5")]["power"]
home = popts("7k/8/8/8/8/8/P7/4K3 w - - 0 1", ON, pawns=True)[("w", "P", "a2")]["power"]
check("passed pawn is stronger than the same pawn with an enemy pawn in front on the b file", pas > npas, f"{pas} > {npas}")
check("advanced passed pawn is stronger than the same pawn at home", pas > home, f"{pas} > {home}")

# PowerPawn changes the eval only when PowerOn=1; defaults leave eval unchanged
G = "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3"
e0, _ = ev(G, {}); e1, _ = ev(G, {"PinPenalty": 30, "RelPinPenalty": 30, "SkewerPenalty": 30, "DiscBonus": 30, "PowerPawn": 100})
check("new params do nothing while PowerOn=0", e0 == e1, f"{e0} {e1}")
check("new options listed in params", all(any(l.startswith(f"param {n} ") for l in run(["params"])) for n in ("PinPenalty", "PinStuck", "RelPinPenalty", "SkewerPenalty", "DiscBonus", "PowerPawn", "TrapNear", "TrapMouse", "TrapCapture")))

# trap mouse: Nh8 in the corner, escape squares f7/g6 covered by Kg7
TM = "7N/6k1/8/8/8/8/8/K6R w - - 0 1"      # mouse, defended by Rh1 (not attacked-hanging)
TC = "7N/6k1/8/8/8/8/8/K7 w - - 0 1"       # mouse + attacked and undefended: trap by capture
TN = "7k/8/8/8/8/3p4/8/N3K3 w - - 0 1"     # Na1: c2 covered by pawn d3, b3 free -> nearly trapped
a = popts(TM, ON); b = popts(TM, {**ON, "TrapMouse": 30, "TrapCapture": 40, "TrapNear": 50})
check("trap mouse tag (no safe square, not hanging)", "mouse" in a[("w", "N", "h8")]["tags"] and "trapped" not in a[("w", "N", "h8")]["tags"], a[("w", "N", "h8")]["tags"])
check("TrapMouse=30 lowers the mouse by 30 (Capture/Near do not apply)", a[("w", "N", "h8")]["power"] - b[("w", "N", "h8")]["power"] == 30 or b[("w", "N", "h8")]["power"] == 0, f"{a[('w','N','h8')]['power']} -> {b[('w','N','h8')]['power']}")
a = popts(TC, ON); b = popts(TC, {**ON, "TrapMouse": 5, "TrapCapture": 10})
check("trap by capture: tagged mouse+trapped", "mouse" in a[("w", "N", "h8")]["tags"] and "trapped" in a[("w", "N", "h8")]["tags"], a[("w", "N", "h8")]["tags"])
check("TrapMouse+TrapCapture add up (5+10)", a[("w", "N", "h8")]["power"] - b[("w", "N", "h8")]["power"] == 15 or b[("w", "N", "h8")]["power"] == 0, f"{a[('w','N','h8')]['power']} -> {b[('w','N','h8')]['power']}")
a = popts(TN, ON); b = popts(TN, {**ON, "TrapNear": 12, "TrapMouse": 50})
check("nearly trapped knight (one safe square left)", "trapnear" in a[("w", "N", "a1")]["tags"], a[("w", "N", "a1")]["tags"])
check("TrapNear=12 lowers it by 12 (TrapMouse does not apply)", a[("w", "N", "a1")]["power"] - b[("w", "N", "a1")]["power"] == 12, f"{a[('w','N','a1')]['power']} -> {b[('w','N','a1')]['power']}")
ps = popts(ST0, {**ON, "TrapNear": 50, "TrapMouse": 50, "TrapCapture": 50})
check("start position: pieces blocked by own pawns are NOT traps", not any("mouse" in v["tags"] or "trapnear" in v["tags"] for k, v in ps.items() if k[1] != "K"))
check("trap params do nothing while PowerOn=0", ev(G, {})[0] == ev(G, {"TrapNear": 30, "TrapMouse": 30, "TrapCapture": 30})[0])

# symmetry: mirror positions give the same eval with every new term on
ALL = {"PowerOn": 1, "PowerCap": 400, "PinPenalty": 15, "PinStuck": 10, "RelPinPenalty": 20, "SkewerPenalty": 20, "DiscBonus": 15, "PowerPawn": 100, "TrapNear": 10, "TrapMouse": 15, "TrapCapture": 20}
FENS = [RP, SK, DC, PR, TM, TC, TN, "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
        "rnbqkb1r/pppp1ppp/5n2/4p3/1b2P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 4 4"]
okm = True
for f in FENS:
    ea, _ = ev(f, ALL); eb, _ = ev(mirror(f), ALL)
    if ea != -eb and ea != eb:
        okm = False
    # eval_white must flip sign
    wa = int([l for l in run([f"setoption name {k} value {v}" for k, v in ALL.items()] + [f"position fen {f}", "evaltrace"]) if l.startswith("evaltrace")][0].split()[4])
    wb = int([l for l in run([f"setoption name {k} value {v}" for k, v in ALL.items()] + [f"position fen {mirror(f)}", "evaltrace"]) if l.startswith("evaltrace")][0].split()[4])
    if wa != -wb:
        okm = False
        print("   asymmetry", f, wa, wb)
check("all new Power terms are colour-symmetric (eval_white flips sign on mirror)", okm)

# features: cp = net*lanja/scale must predict the eval change (linearity) -> Training can learn them
def feat_pred(fen, name, val):
    base = {**ON}
    e0, f0 = ev(fen, base)
    e1, f1 = ev(fen, {**base, name: val})
    net_cp = f0.get(name)
    return e0, e1, net_cp
for fen, name, val in ((TM, "TrapMouse", 20), (TC, "TrapCapture", 20), (TN, "TrapNear", 20), (PR + "", "PinPenalty", 20), (RP, "RelPinPenalty", 20), (SK, "SkewerPenalty", 20), (DC, "DiscBonus", 20)):
    # Black pieces need to matter too; add black king / use positions as they are
    e0, e1, f = feat_pred(fen, name, val)
    ok = f is not None and f[2] == "1" and abs((e1 - e0) - f[0] * val) <= 2
    check(f"feature {name}: net*value predicts the eval change", ok, f"d_eval {e1 - e0} net {None if f is None else f[0]} * {val}")
e0, f0 = ev(G, ON); e1, _ = ev(G, {**ON, "PowerPawn": 100}); 
_, f2 = ev(G, ON)
check("PowerPawn feature recorded in evaltrace even while PowerPawn=0", "PowerPawn" in f2 and f2["PowerPawn"][2] == "1", str(f2.get("PowerPawn")))
check("PowerPawn feature predicts eval change (scale 100)", abs((e1 - e0) - f2["PowerPawn"][0] * 100 / 100.0) <= 2, f"d_eval {e1 - e0} net {f2['PowerPawn'][0]}")
o = run(["setoption name PowerOn value 1", "setoption name PowerPawn value 100", "position startpos moves e2e4", "go depth 6"])
check("go depth 6 with every new term on", any(l.startswith("bestmove") for l in o))


# ---------------------------------------------------------------- v0.12: ANTI (desactivation future) + SACRIFICE, gated by Race / decision
def aview(fen, pre=()):
    o = run([*pre, f"position fen {fen}", "antiview"])
    l = [x for x in o if x.startswith("antiview")][0].split()
    d = {l[i]: float(l[i + 1]) for i in range(6, len(l) - 1, 2)}
    d["eta_w"] = float(l[3]); d["eta_b"] = float(l[5])
    return d

CA = "r3k2r/pppqbppp/2n2n2/3pp3/3PP3/2N2N2/PPPQBPPP/R3K2R w KQ - 0 1"          # black lost both castling rights, king e8
CA_M = mirror(CA)
a = aview(CA); m = aview(CA_M)
check("anti-castle: white denies black's castling (rights lost) = +1", abs(a["castle"] - 1.0) < 1e-6, a["castle"])
check("anti-castle mirrors with the opposite sign", abs(m["castle"] + 1.0) < 1e-6, m["castle"])
check("decision letgo w switches white's anti-castle off (gate 0)", abs(aview(CA, ["decision letgo w"])["castle"]) < 1e-6)
check("decision care w keeps it on", abs(aview(CA, ["decision care w"])["castle"] - 1.0) < 1e-6)
check("decision letgo b does not change white's denial", abs(aview(CA, ["decision letgo b"])["castle"] - 1.0) < 1e-6)
check("start position: nothing to deny", all(abs(v) < 1e-9 for k, v in aview(ST0).items() if not k.startswith("eta")))

# promote / support: black king d8 blockades the d6 pawn; far black king does not
near = aview("3k4/8/3P4/8/8/8/8/K7 b - - 0 1"); far = aview("7k/8/3P4/8/8/8/8/K7 w - - 0 1")
check("anti-promote: blockading king denies (negative for white's pawn)", near["promote"] < -0.5, near["promote"])
check("anti-promote: far king denies nothing", abs(far["promote"]) < 1e-6, far["promote"])
check("anti-support: closer defending king denies support", far["support"] < 0 and near["support"] < 0, f"{far['support']} {near['support']}")
check("anti-promote mirror symmetric", abs(aview(mirror("3k4/8/3P4/8/8/8/8/K7 b - - 0 1"))["promote"] + near["promote"]) < 1e-9)
# anti-defender: black rook controls the d6 pawn's path -> white wants it removed (negative)
df = aview("r6k/8/3P4/8/8/8/8/K7 w - - 0 1"); nd = aview("7k/8/3P4/8/8/8/8/K7 w - - 0 1")
check("anti-defender: rook controlling the promotion path counts against the pawn owner", df["defender"] < -0.1 and abs(nd["defender"]) < 1e-9, f"{df['defender']} {nd['defender']}")
check("decision letgo w also silences anti-defender (own future)", abs(aview("r6k/8/3P4/8/8/8/8/K7 w - - 0 1", ["decision letgo w"])["defender"]) < 1e-9)

# sacrifice compensation: white is down material but his attack is faster -> compensation; a side not behind gets none
SM = "r2q1rk1/ppp2ppp/8/6NQ/8/8/5PPP/4R1K1 w - - 0 1"
sm = aview(SM)
check("sacrifice: material deficit + faster attack gives SacOpen/SacMate units to white", sm["sacopen"] > 0 and sm["sacmate"] > 0, f"{sm['sacopen']} {sm['sacmate']}")
check("sacrifice: not behind in material -> no units", aview("6k1/5pp1/6p1/7Q/8/8/5PPP/4R1K1 w - - 0 1")["sacmate"] == 0)
check("sacrifice mirror flips sign", abs(aview(mirror(SM))["sacmate"] + sm["sacmate"]) < 1e-9)
check("decision letgo w (no care) silences white's sacrifice credit", aview(SM, ["decision letgo w"])["sacmate"] == 0)
un = aview("r2q1rk1/ppp2ppp/2np4/4p3/3PP3/2P5/PP3PPP/R2Q1RK1 w - - 60 20")
check("anti-draw/unlock: locked centre + deficit + long halfmove clock gives SacUnlock units", un["sacunlock"] > 0, un["sacunlock"])
un0 = aview("r2q1rk1/ppp2ppp/2np4/4p3/3PP3/2P5/PP3PPP/R2Q1RK1 w - - 0 20")
check("the unlock need grows with the halfmove clock", un["sacunlock"] > un0["sacunlock"], f"{un['sacunlock']} > {un0['sacunlock']}")

# eval: nothing changes while every weight is 0; weights change the eval; group Anti in evaltrace
GA = {"AntiCastle": 20, "AntiDevelop": 20, "AntiSqueeze": 20, "AntiPromote": 40, "AntiSupport": 20, "AntiDefender": 20, "AntiDraw": 20, "SacOpen": 20, "SacMate": 20, "SacUnlock": 20}
check("anti weights 0 -> eval unchanged vs engine default", ev(CA, {})[0] == ev(CA, {"AntiHorizon": 12, "AntiLetGo": 0})[0])
check("AntiCastle=30 changes the eval by about 30 (white denies)", abs((ev(CA, {"AntiCastle": 30})[0] - ev(CA, {})[0]) - 30) <= 1, f"{ev(CA, {'AntiCastle': 30})[0] - ev(CA, {})[0]}")
check("AntiCap clamps the total", abs(ev(CA, {"AntiCastle": 60, "AntiCap": 10})[0] - ev(CA, {})[0]) == 10)
o = run([f"position fen {CA}", "evaltrace"])
check("evaltrace has group Anti", any(l.startswith("group Anti ") for l in o))
for fen, name, val in ((CA, "AntiCastle", 20), ("3k4/8/3P4/8/8/8/8/K7 b - - 0 1", "AntiPromote", 40), ("3k4/8/3P4/8/8/8/8/K7 b - - 0 1", "AntiSupport", 30),
                       ("r6k/8/3P4/8/8/8/8/K7 w - - 0 1", "AntiDefender", 30), (SM, "SacOpen", 20), (SM, "SacMate", 20),
                       ("r2q1rk1/ppp2ppp/2np4/4p3/3PP3/2P5/PP3PPP/R2Q1RK1 w - - 60 20", "SacUnlock", 20)):
    e0, f0 = ev(fen, {"AntiCap": 400})
    e1, _ = ev(fen, {"AntiCap": 400, name: val})
    ok = name in f0 and f0[name][2] == "1" and abs((e1 - e0) - f0[name][0] * val) <= 2
    check(f"feature {name}: net*value predicts the eval change", ok, f"d_eval {e1 - e0} net {f0.get(name)}")
okm = True
AA = {**GA, "AntiCap": 400}
for f in (CA, SM, "3k4/8/3P4/8/8/8/8/K7 b - - 0 1", "r6k/8/3P4/8/8/8/8/K7 w - - 0 1", "r2q1rk1/ppp2ppp/2np4/4p3/3PP3/2P5/PP3PPP/R2Q1RK1 w - - 60 20", *FENS):
    wa = ev(f, AA)[0]; wb = ev(mirror(f), AA)[0]
    if wa != -wb:
        okm = False; print("   asymmetry", f, wa, wb)
check("all Anti/Sacrifice terms are colour-symmetric", okm)
o = run([*(f"setoption name {k} value {v}" for k, v in {**AA, "SacDefExt": 1, "SacOpenExt": 1}.items()), "position startpos", "go depth 7"])
check("go depth 7 with every Anti/Sac weight and extension on", any(l.startswith("bestmove") for l in o))
o = run(["setoption name SacDefExt value 1", "setoption name SacOpenExt value 1", f"position fen {SM}", "go depth 8"])
check("search with sacrifice extensions finds a move in an attacking position", any(l.startswith("bestmove") for l in o))

# ---- default vaovao (Blind 1.5): tsy 0 ireo lanja, ary mandeha ny moteur
pm = {}
for l in run_raw(["params"]):
    t = l.split()
    if t and t[0] == "param": pm[t[1]] = int(t[2])
check("every formerly-0 weight now has a non-zero default", all(pm.get(k, 0) != 0 for k in LEGACY), [k for k in LEGACY if pm.get(k, 0) == 0])
o = run_raw(["position startpos", "go depth 6"])
check("go depth 6 with the new defaults", any(l.startswith("bestmove") and l.split()[1] not in ("(none)", "0000") for l in o))

print("failures:", fails)
sys.exit(1 if fails else 0)
