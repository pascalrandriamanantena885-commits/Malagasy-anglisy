#!/usr/bin/env bash
# Test UCI + perft + go (depth/nodes/movetime/wtime) ho an'ny binaire JORO (Linux x86_64)
# Fampiasana: bash scripts/uci_test.sh ./joro_linux
# Fanamarihana: ny moteur JORO (joro.cpp) dia tsy misy baiko Training (params/evaltrace/oprof/searchstats/powerview).
set -u   # tsy ampiasaina pipefail: grep -q dia manapaka ny echo (SIGPIPE) rehefa lehibe ny output
BIN="${1:?usage: uci_test.sh <joro-binary>}"
fails=0
fail() { echo "FAIL: $*"; fails=$((fails+1)); }
ok()   { echo "ok:   $*"; }
run()  { printf '%b' "$1" | timeout 120 "$BIN" 2>&1; }

out=$(run 'uci\nisready\nquit\n')
echo "$out" | grep -q '^uciok'   && ok "uciok"   || fail "uciok tsy hita"
echo "$out" | grep -q '^readyok' && ok "readyok" || fail "readyok tsy hita"
echo "$out" | grep -q '^id name JORO' && ok "id name JORO" || fail "id name tsy JORO: $(echo "$out" | grep '^id name')"
for o in Hash Opening OpenCap Ghost GhostW GhostCap GhostAlert GuideLMR GuideExt GuideAlert Race RaceW RaceCap RaceAlert RaceMargin Clean Opening2 Opening2Cap Storm StormCap SameSidePen BookCheck BookMargin Book OpeningGuard BookRandom BookPlies; do
  echo "$out" | grep -q "option name $o " && ok "option $o" || fail "option $o tsy hita"
done

perft() { # fen depth expected
  local r; r=$(run "position fen $1\nperft $2\nquit\n")
  echo "$r" | grep -q "perft $2 = $3 " && ok "perft $2 = $3" || fail "perft $2 (attendu $3): $(echo "$r" | tail -2 | tr '\n' ' ')"
}
perft "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" 4 197281
perft "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1" 3 97862
perft "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1" 4 43238
perft "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1" 3 9467
perft "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8" 3 62379

for g in "depth 5" "nodes 20000" "movetime 200" "wtime 5000 btime 5000 winc 100 binc 100"; do
  r=$(run "uci\nisready\nposition startpos moves e2e4 e7e5\ngo $g\nquit\n")
  echo "$r" | grep -Eq '^bestmove [a-h][1-8][a-h][1-8]' && ok "go $g" || fail "go $g: $(echo "$r" | tail -2 | tr '\n' ' ')"
done

# bench (fanamarinana ny fihetsika: nodes tsy miova)
r=$(run 'bench 8\nquit\n')
echo "$r" | grep -q 'bench depth 8: nodes 1058484 ' && ok "bench nodes 1058484" || fail "bench nodes: $(echo "$r" | tail -1)"

# mat en 1 (Qh5xf7#)
r=$(run "position fen r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4\ngo depth 4\nquit\n")
echo "$r" | grep -q '^bestmove h5f7' && ok "mat en 1" || fail "mat en 1: $(echo "$r" | grep bestmove)"

[ "$fails" -eq 0 ] && { echo "---- 0 fahadisoana"; exit 0; } || { echo "---- $fails fahadisoana"; exit 1; }
