#!/usr/bin/env bash
# Test UCI + perft + go (depth/nodes/movetime/wtime) ho an'ny binaire JORO (Linux x86_64)
# Fampiasana: bash scripts/uci_test.sh ./joro_linux
set -u   # tsy ampiasaina pipefail: grep -q dia manapaka ny echo (SIGPIPE) rehefa lehibe ny output
BIN="${1:?usage: uci_test.sh <joro-binary>}"
fails=0
fail() { echo "FAIL: $*"; fails=$((fails+1)); }
ok()   { echo "ok:   $*"; }
run()  { printf '%b' "$1" | timeout 120 "$BIN" 2>&1; }

out=$(run 'uci\nisready\nquit\n')
echo "$out" | grep -q '^uciok'   && ok "uciok"   || fail "uciok tsy hita"
echo "$out" | grep -q '^readyok' && ok "readyok" || fail "readyok tsy hita"
for o in Hash GhostW GhostCap OpenCap GhostAlert GuideAlert PinPenalty PinStuck RelPinPenalty SkewerPenalty DiscBonus PowerPawn TrapNear TrapMouse TrapCapture AntiCastle AntiDevelop AntiSqueeze AntiPromote AntiSupport AntiDefender AntiDraw SacOpen SacMate SacUnlock AntiHorizon AntiLetGo AntiCap SacDefExt SacOpenExt; do
  echo "$out" | grep -q "option name $o " && ok "option $o" || fail "option $o tsy hita"
done

perft() { # fen depth expected
  local r; r=$(run "position fen $1\nperft $2\nquit\n")
  echo "$r" | grep -q "perft $2 = $3 " && ok "perft $2 = $3" || fail "perft $2 (attendu $3): $(echo "$r" | tail -2 | tr '\n' ' ')"
}
perft "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" 4 197281
perft "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1" 3 97862
perft "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1" 4 43238
perft "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1" 3 9467
perft "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8" 3 62379

for g in "depth 5" "nodes 20000" "movetime 200" "wtime 5000 btime 5000 winc 100 binc 100"; do
  r=$(run "uci\nisready\nposition startpos moves e2e4 e7e5\ngo $g\nquit\n")
  echo "$r" | grep -Eq '^bestmove [a-h][1-8][a-h][1-8]' && ok "go $g" || fail "go $g: $(echo "$r" | tail -2 | tr '\n' ' ')"
done

# mat en 1 : Ra8#
r=$(run "uci\nposition fen 6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1\ngo depth 4\nquit\n")
echo "$r" | grep -q '^bestmove a1a8' && ok "mat en 1" || fail "mat en 1: $(echo "$r" | tail -1)"

# setoption + positions terminales (tsy tokony hisy crash)
r=$(run "uci\nsetoption name GhostW value 40\nisready\nposition startpos\ngo depth 4\nquit\n")
echo "$r" | grep -q '^bestmove' && ok "setoption GhostW" || fail "setoption GhostW"
r=$(run "uci\nposition fen 7k/5Q2/6K1/8/8/8/8/8 b - - 0 1\ngo depth 3\nquit\n")
echo "$r" | grep -q '^bestmove' && ok "position pat" || fail "position pat (crash?)"

# ---- Training: lanja azo tune-na, params, evaltrace, searchstats
out=$(run 'uci\nquit\n')
for o in KsShield BishopPair OpCastled NullBase LmrMoves1 RfpMargin; do
  echo "$out" | grep -q "option name $o " && ok "option $o" || fail "option $o tsy hita"
done
r=$(run 'setoption name KsShield value 999\nparams\nquit\n')
echo "$r" | grep -q '^param KsShield 40 8 0 40 king 1' && ok "setoption clamp (KsShield=40)" || fail "setoption clamp"
r=$(run 'setoption name Opening value true\nposition fen rnbqkbnr/pppp1ppp/8/8/4Pp2/5N2/PPPP2PP/RNBQKB1R b KQkq - 1 3\nevaltrace\nquit\n')
echo "$r" | grep -q '^evaltrace ' && echo "$r" | grep -q '^feat OpDevelop ' && echo "$r" | grep -q '^end' && ok "evaltrace" || fail "evaltrace: $(echo "$r" | tail -3 | tr '\n' ' ')"
r=$(run 'ucinewgame\nposition startpos moves e2e4 e7e5\ngo depth 8\nsearchstats\nquit\n')
echo "$r" | grep -q '^stats .*null_try' && ok "searchstats" || fail "searchstats"
# default = mitovy amin'ny lanja taloha: bench nodes tsy miova
r=$(run 'bench 8\nquit\n')
echo "$r" | grep -q 'bench depth 8: nodes 1052366 ' && ok "bench nodes 1052366 (default tsy niova)" || fail "bench nodes: $(echo "$r" | tail -1)"

# ---- Profil isaky ny opening (oprof)
r=$(run 'oprof add sic moves e2e4 c7c5 set KsShield 30\nposition fen rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2 moves g1f3\noprof active\nparams\nposition startpos moves d2d4\noprof active\nparams\nquit\n')
echo "$r" | grep -q '^oprof_active sic' && echo "$r" | grep -q '^param KsShield 30 ' && ok "oprof: mihetsika (FEN + moves)" || fail "oprof tsy mihetsika"
echo "$r" | grep -q '^oprof_active none' && echo "$r" | grep -q '^param KsShield 8 ' && ok "oprof: miverina base" || fail "oprof tsy niverina base"

# oprof side: profil ho an'ny sisiny iray ihany (ny sisiny hihetsika amin'ny position farany)
r=$(run 'oprof add w4 side w fen rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1 set KsShield 30\nposition startpos moves e2e4\noprof active\nposition startpos moves e2e4 e7e5\noprof active\nquit\n')
[ "$(echo "$r" | grep '^oprof_active' | tr '\n' ' ')" = "oprof_active none oprof_active w4 " ] && ok "oprof side w" || fail "oprof side w: $(echo "$r" | grep '^oprof_active' | tr '\n' ' ')"

# ---- Ghost / Race view, decision, target (Training)
r=$(run 'position fen r1b2rk1/pp1nqppp/2p1pn2/3p4/2PP4/2NBPN1Q/PP3PPP/R1B2RK1 w - - 0 10\nghostview w heat\nraceview\nquit\n')
echo "$r" | grep -q '^ghostview side w ' && echo "$r" | grep -q '^future ' && echo "$r" | grep -q '^def ' && echo "$r" | grep -q '^heat ' && ok "ghostview" || fail "ghostview"
echo "$r" | grep -q '^raceview side w ' && echo "$r" | grep -q '^plan 1 ' && echo "$r" | grep -q '^verdict b ' && ok "raceview" || fail "raceview"
r=$(run 'setoption name GhostAlert value 0\nsetoption name RaceAlert value 0\nposition fen r1b2rk1/pp1nqppp/2p1pn2/3p4/2PP4/2NBPN1Q/PP3PPP/R1B2RK1 w - - 0 10\ndecision take b\nevaltrace\nquit\n')
echo "$r" | grep -q '^group Take -' && echo "$r" | grep -q 'decision take$' && ok "decision take" || fail "decision take"
r=$(run 'position fen r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 5\ntarget f6\ntarget off\ntarget d5\nquit\n')
echo "$r" | grep -q '^target ok f6 N cnt 2' && echo "$r" | grep -q '^target off' && echo "$r" | grep -q '^target error' && ok "target" || fail "target"

# ---- Piece Power (powerview, PowerOn, race: gfuture/first/suggest)
r=$(run 'position startpos moves e2e4\npowerview\nquit\n')
echo "$r" | grep -q '^powerview stm b on 0' && echo "$r" | grep -q '^side w avg ' && echo "$r" | grep -q '^piece w B f1 power ' && echo "$r" | grep -q ' libsq ' && ok "powerview" || fail "powerview"
r=$(run 'setoption name PowerOn value 1\nposition fen r1b2rk1/pp1nqppp/2p1pn2/3p4/2PP4/2NBPN1Q/PP3PPP/R1B2RK1 w - - 0 10\nevaltrace\nquit\n')
echo "$r" | grep -q '^feat PowerW .* 1$' && echo "$r" | grep -q '^group Power ' && ok "PowerOn eval term + feature" || fail "PowerOn eval term"
r=$(run 'position fen r1b2rk1/pp1nqppp/2p1pn2/3p4/2PP4/2NBPN1Q/PP3PPP/R1B2RK1 w - - 0 10\nraceview\nquit\n')
echo "$r" | grep -q '^gfuture w ' && echo "$r" | grep -q '^first ' && echo "$r" | grep -q '^suggest b ' && ok "raceview gfuture/first/suggest" || fail "raceview integration"

echo "---- $fails fahadisoana"
exit $fails
