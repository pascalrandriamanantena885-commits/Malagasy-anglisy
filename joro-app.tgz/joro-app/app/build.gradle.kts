plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "mg.joro.chess"
    compileSdk = 34

    defaultConfig {
        applicationId = "mg.joro.chess"
        minSdk = 24
        // targetSdk 28 : ilaina mba ho azon'ny app mampandeha (exec) ny moteur nalaina avy any ivelany (Stockfish...)
        targetSdk = 28
        versionCode = (project.findProperty("versionCode") as String?)?.toInt() ?: 1
        versionName = (project.findProperty("versionName") as String?) ?: "0.1.0"
        buildConfigField("String", "GITHUB_REPO", "\"${project.findProperty("githubRepo") ?: "OWNER/joro-app"}\"")
    }

    signingConfigs {
        create("joro") {
            storeFile = rootProject.file("keystore/joro.jks")
            storePassword = "joro123"
            keyAlias = "joro"
            keyPassword = "joro123"
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("joro")
            isMinifyEnabled = false
        }
        debug { signingConfig = signingConfigs.getByName("joro") }
    }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    // libjoro.so dia executable : tsy maintsy alaina ao amin'ny nativeLibraryDir
    packaging { jniLibs { useLegacyPackaging = true } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    testImplementation("junit:junit:4.13.2")
}
