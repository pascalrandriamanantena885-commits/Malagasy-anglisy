package mg.joro.chess.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import mg.joro.chess.R

// =====================================================================================
// Fampiasa UI iombonana: ScreenColumn, TwoPane, HoverCard, Panel, SegTabs, PagedItems...
// =====================================================================================

/** Pejy mahazatra: scroll mitsangana, padding, sady tsy mihoatra ny 820dp amin'ny efijery lehibe (afovoany) */
@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.widthIn(max = 820.dp).fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

/** Efijery lehibe (>= 840dp): tontolo roa mifanila (board ankavia, fanaraha-maso ankavanana). Finday: tontolo iray mifanesy. */
@Composable
fun TwoPane(left: @Composable ColumnScope.() -> Unit, right: @Composable ColumnScope.() -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (maxWidth >= 840.dp) {
            Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Column(
                    Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp), content = left
                )
                Column(
                    Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp), content = right
                )
            }
        } else {
            ScreenColumn {
                left()
                right()
            }
        }
    }
}

/** Card misy hover (mouse / stylus / ChromeOS) sy fanindriana: mihetsika kely, miova ny sisiny sy ny fototra */
@Composable
fun HoverCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    spacing: Dp = 6.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    val pressed by src.collectIsPressedAsState()
    val cs = MaterialTheme.colorScheme
    val lift = hovered || pressed
    val border by animateColorAsState(if (lift) cs.primary.copy(alpha = 0.6f) else cs.outlineVariant, label = "cardBorder")
    val bg by animateColorAsState(if (lift) cs.surfaceContainerHigh else cs.surfaceContainer, label = "cardBg")
    val scale by animateFloatAsState(if (hovered) 1.012f else 1f, label = "cardScale")
    Surface(
        modifier = modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale }.hoverable(src),
        shape = MaterialTheme.shapes.medium,
        color = bg,
        contentColor = cs.onSurface,
        border = BorderStroke(1.dp, border),
        shadowElevation = if (hovered) 4.dp else 0.dp
    ) {
        val inner = if (onClick != null)
            Modifier.clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)
        else Modifier
        Column(inner.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(spacing), content = content)
    }
}

/** Panel misy lohateny (azo atsipy/vohaina): fampifandraisana zavatra mifandray */
@Composable
fun Panel(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    glyph: String? = null,
    collapsible: Boolean = true,
    startOpen: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    var open by rememberSaveable(title) { mutableStateOf(startOpen) }
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    val headBg by animateColorAsState(if (collapsible && hovered) cs.surfaceContainerHigh else Color.Transparent, label = "panelHead")
    val shown = open || !collapsible
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = cs.surfaceContainerLow,
        contentColor = cs.onSurface,
        border = BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Column(Modifier.fillMaxWidth()) {
            val headMod = if (collapsible)
                Modifier.hoverable(src).clickable(interactionSource = src, indication = LocalIndication.current) { open = !open }
            else Modifier
            Row(
                headMod.fillMaxWidth().background(headBg).padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (glyph != null) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                        Text(glyph, color = cs.onPrimaryContainer, fontSize = 16.sp)
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                    if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = cs.onSurfaceVariant, maxLines = 2)
                }
                if (collapsible) Text(if (shown) "▾" else "▸", color = cs.onSurfaceVariant, fontSize = 16.sp)
            }
            AnimatedVisibility(visible = shown) {
                Column(
                    Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    content = content
                )
            }
        }
    }
}

/** Safidy mifanesy (segmented): toy ny tab kely ao anaty pejy */
@Composable
fun SegTabs(items: List<String>, selected: Int, modifier: Modifier = Modifier, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier.clip(RoundedCornerShape(16.dp)).background(cs.surfaceContainerHigh).padding(4.dp)
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, t ->
            val sel = i == selected
            val src = remember { MutableInteractionSource() }
            val hov by src.collectIsHoveredAsState()
            val bg by animateColorAsState(
                if (sel) cs.primary else if (hov) cs.surfaceVariant else Color.Transparent, label = "seg"
            )
            Box(
                Modifier.clip(RoundedCornerShape(12.dp)).background(bg).hoverable(src)
                    .clickable(interactionSource = src, indication = LocalIndication.current) { onSelect(i) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(t, color = if (sel) cs.onPrimary else cs.onSurfaceVariant, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
    }
}

/** Soratra kely (fanazavana) */
@Composable
fun Caption(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Voaray kely misy loko (statut) */
@Composable
fun Pill(text: String, modifier: Modifier = Modifier, bg: Color = MaterialTheme.colorScheme.primaryContainer, fg: Color = MaterialTheme.colorScheme.onPrimaryContainer) {
    Box(modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Logo kely: sary ofisialy an'ny moteur Blind */
@Composable
fun BrandMark(size: Dp = 32.dp) {
    Image(
        painter = painterResource(R.drawable.blind_logo),
        contentDescription = "JORO",
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(RoundedCornerShape(size * 0.3f))
    )
}

/** Toerana foana (tsy misy zavatra) */
@Composable
fun EmptyState(text: String, glyph: String = "∅") {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).background(cs.surfaceContainerLow).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(glyph, fontSize = 28.sp, color = cs.outline)
        Text(text, fontSize = 14.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

// ---------- Pagination + lisitra / grid ----------

/**
 * Lisitra lava: zaraina ho pejy (pageSize) miaraka amin'ny bara pejy, ary azo asehoana ho lisitra na grid (UiPrefs.grid).
 * itemContent(item, compact): compact = true rehefa grid maromaro tsanganana (mba hamoronana card fohy kokoa).
 * focusIndex: raha omena dia mifindra ho azy amin'ny pejy misy io indice io (ohatra ny hetsika ankehitriny).
 */
@Composable
fun <T> PagedItems(
    items: List<T>,
    modifier: Modifier = Modifier,
    pageSize: Int = UiPrefs.pageSize,
    showToggle: Boolean = true,
    gridMinWidth: Dp = 150.dp,
    spacing: Dp = 10.dp,
    focusIndex: Int? = null,
    emptyText: String? = null,
    itemContent: @Composable (item: T, compact: Boolean) -> Unit
) {
    val size = pageSize.coerceAtLeast(1)
    val pages = maxOf(1, (items.size + size - 1) / size)
    var page by rememberSaveable { mutableStateOf(0) }
    LaunchedEffect(focusIndex) {
        if (focusIndex != null && focusIndex >= 0) page = focusIndex / size
    }
    if (items.isEmpty()) {
        if (emptyText != null) EmptyState(emptyText)
        return
    }
    val cur = page.coerceIn(0, pages - 1)
    val slice = items.subList(cur * size, minOf(items.size, (cur + 1) * size))
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (showToggle) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Caption("${items.size} rehetra · pejy ${cur + 1}/$pages")
                SegTabs(listOf("☰ Lisitra", "▦ Grid"), if (UiPrefs.grid) 1 else 0) { UiPrefs.updateGrid(it == 1) }
            }
        }
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val cols = if (showToggle && UiPrefs.grid) (maxWidth / gridMinWidth).toInt().coerceIn(1, 4) else 1
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(spacing)) {
                slice.chunked(cols).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(spacing)) {
                        row.forEach { item ->
                            Box(Modifier.weight(1f)) { itemContent(item, cols > 1) }
                        }
                        repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        if (pages > 1) PageBar(cur, pages) { page = it }
    }
}

/** Bara pejy: ◀ 1 … 4 [5] 6 … 12 ▶ */
@Composable
fun PageBar(page: Int, pages: Int, onPage: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val nums = remember(page, pages) { pageWindow(page, pages) }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PageBtn("◀", false, page > 0) { onPage(page - 1) }
        nums.forEach { n ->
            if (n < 0) Text("…", color = cs.onSurfaceVariant)
            else PageBtn("${n + 1}", n == page, true) { onPage(n) }
        }
        PageBtn("▶", false, page < pages - 1) { onPage(page + 1) }
    }
}

/** Lisitry ny pejy aseho; -1 = "…" */
internal fun pageWindow(cur: Int, pages: Int): List<Int> {
    if (pages <= 7) return (0 until pages).toList()
    val s = listOf(0, pages - 1, cur - 1, cur, cur + 1).filter { it in 0 until pages }.distinct().sorted()
    val out = ArrayList<Int>()
    s.forEachIndexed { i, v ->
        if (i > 0 && v - s[i - 1] > 1) out.add(-1)
        out.add(v)
    }
    return out
}

@Composable
private fun PageBtn(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val hov by src.collectIsHoveredAsState()
    val bg = if (selected) cs.primary else if (hov && enabled) cs.surfaceVariant else cs.surfaceContainerHigh
    val fg = if (selected) cs.onPrimary else cs.onSurface
    Box(
        Modifier.defaultMinSize(minWidth = 40.dp, minHeight = 40.dp).clip(RoundedCornerShape(12.dp)).background(bg).hoverable(src)
            .clickable(enabled = enabled, interactionSource = src, indication = LocalIndication.current, onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (enabled) fg else fg.copy(alpha = 0.35f), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}
