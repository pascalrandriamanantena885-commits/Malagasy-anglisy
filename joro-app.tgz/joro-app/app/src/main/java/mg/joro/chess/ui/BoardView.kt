package mg.joro.chess.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.sqrt
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import mg.joro.chess.R
import mg.joro.chess.chess.Board
import mg.joro.chess.match.Host

private val PIECE_RES = mapOf(
    1 to R.drawable.w_pawn, 2 to R.drawable.w_knight, 3 to R.drawable.w_bishop,
    4 to R.drawable.w_rook, 5 to R.drawable.w_queen, 6 to R.drawable.w_king,
    9 to R.drawable.b_pawn, 10 to R.drawable.b_knight, 11 to R.drawable.b_bishop,
    12 to R.drawable.b_rook, 13 to R.drawable.b_queen, 14 to R.drawable.b_king
)

// Loko nalaina tamin'ny board_squares.zip : [light, dark]
private val THEMES = listOf(
    listOf(Color(0xFF595959), Color(0xFF363636)),   // gray
    listOf(Color(0xFF7C4C3E), Color(0xFF512A2A))    // brown
)

@Composable
fun BoardView(
    b: Board, flipped: Boolean, sel: Int, targets: Set<Int>, last: String?, onTap: (Int) -> Unit,
    badge: Pair<String, Long>? = null, arrow: String? = null, modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val bmps: Map<Int, ImageBitmap> = remember {
        PIECE_RES.mapValues {
            val o = BitmapFactory.Options().apply { inScaled = false }
            BitmapFactory.decodeResource(ctx.resources, it.value, o).asImageBitmap()
        }
    }
    val tap by rememberUpdatedState(onTap)
    val th = THEMES[Host.boardTheme.value]
    val lastFrom = if (last != null && last.length >= 4) Board.sqOf(last.substring(0, 2)) else -1
    val lastTo = if (last != null && last.length >= 4) Board.sqOf(last.substring(2, 4)) else -1

    Canvas(
        modifier.fillMaxWidth().aspectRatio(1f).pointerInput(flipped) {
            detectTapGestures { o ->
                val c = size.width / 8f
                val x = (o.x / c).toInt().coerceIn(0, 7)
                val y = (o.y / c).toInt().coerceIn(0, 7)
                val file = if (flipped) 7 - x else x
                val rank = if (flipped) y else 7 - y
                tap(rank * 8 + file)
            }
        }
    ) {
        val cell = size.width / 8f
        val k = cell * 0.92f / 443f   // 443 = haavon'ny viewBox lehibe indrindra (mpanjaka); zoom PNG = 0.5
        for (y in 0..7) for (x in 0..7) {
            val file = if (flipped) 7 - x else x
            val rank = if (flipped) y else 7 - y
            val s = rank * 8 + file
            val tl = Offset(x * cell, y * cell)
            drawRect(if ((rank + file) % 2 == 0) th[1] else th[0], tl, Size(cell, cell))
            if (s == lastFrom || s == lastTo) drawRect(Color(0x55FFD54F), tl, Size(cell, cell))
            if (s == sel) drawRect(Color(0x8800E676), tl, Size(cell, cell))
            val p = b.sq[s]
            if (p != 0) {
                val bm = bmps[p]
                if (bm != null) {
                    val dw = (bm.width * 2 * k).toInt()
                    val dh = (bm.height * 2 * k).toInt()
                    drawImage(
                        image = bm,
                        dstOffset = IntOffset((tl.x + (cell - dw) / 2f).toInt(), (tl.y + cell * 0.97f - dh).toInt()),
                        dstSize = IntSize(dw, dh),
                        filterQuality = FilterQuality.Medium
                    )
                }
            }
            if (s in targets) drawCircle(Color(0xAA00E676), cell * 0.14f, Offset(tl.x + cell / 2, tl.y + cell / 2))
        }

        fun ctr(sq: Int): Offset {
            val f = sq % 8; val rk = sq / 8
            val x = if (flipped) 7 - f else f
            val y = if (flipped) rk else 7 - rk
            return Offset((x + 0.5f) * cell, (y + 0.5f) * cell)
        }
        // anamanana: hetsika tsara kokoa
        if (arrow != null && arrow.length >= 4) {
            val a = ctr(Board.sqOf(arrow.substring(0, 2))); val z = ctr(Board.sqOf(arrow.substring(2, 4)))
            val dx = z.x - a.x; val dy = z.y - a.y
            val len = sqrt(dx * dx + dy * dy)
            if (len > 1f) {
                val ux = dx / len; val uy = dy / len
                val head = cell * 0.34f
                val w = cell * 0.16f
                val col = Color(0xCC81B64C)
                val bx = z.x - ux * head; val by = z.y - uy * head
                drawLine(col, Offset(a.x + ux * cell * 0.2f, a.y + uy * cell * 0.2f), Offset(bx, by), strokeWidth = w)
                val path = Path()
                path.moveTo(z.x, z.y)
                path.lineTo(bx - uy * head * 0.55f, by + ux * head * 0.55f)
                path.lineTo(bx + uy * head * 0.55f, by - ux * head * 0.55f)
                path.close()
                drawPath(path, col)
            }
        }
        // badge: sokajin'ny hetsika eo amin'ny efitra niafara
        if (badge != null && lastTo >= 0) {
            val c0 = ctr(lastTo)
            val r = cell * 0.2f
            val c = Offset(c0.x + cell * 0.5f - r * 0.95f, c0.y - cell * 0.5f + r * 0.95f)
            drawCircle(Color.White, r + 2f, c)
            drawCircle(Color(badge.second), r, c)
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true
                color = android.graphics.Color.WHITE
                textSize = r * (if (badge.first.length > 1) 1.0f else 1.25f)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                textAlign = android.graphics.Paint.Align.CENTER
            }
            drawContext.canvas.nativeCanvas.drawText(badge.first, c.x, c.y - (paint.descent() + paint.ascent()) / 2f, paint)
        }
    }
}
