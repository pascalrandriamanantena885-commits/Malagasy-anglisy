package mg.joro.chess.match

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** net = (feature fotsy - mainty); cp = net*lanja/scale (fotsy POV); active = tafiditra ao amin'ny eval izao */
class Feat(val net: Double, val cp: Double, val active: Boolean)
class Trace(val evalWhite: Int, val groups: Map<String, Double>, val feats: Map<String, Feat>, val profile: String)
class ParamInfo(val name: String, val value: Int, val def: Int, val lo: Int, val hi: Int, val group: String, val scale: Int)

object TraceParse {
    private fun tok(l: String): List<String> = l.trim().split(" ").filter { it.isNotEmpty() }

    /** Valin'ny baiko "evaltrace" (andalana hatramin'ny "end" tsy ao anatiny) */
    fun trace(lines: List<String>): Trace? {
        var ev = 0
        var prof = "none"
        var head = false
        val groups = LinkedHashMap<String, Double>()
        val feats = LinkedHashMap<String, Feat>()
        for (l in lines) {
            val t = tok(l)
            if (t.isEmpty()) continue
            when (t[0]) {
                "evaltrace" -> {
                    head = true
                    val i = t.indexOf("eval_white")
                    if (i >= 0 && i + 1 < t.size) ev = t[i + 1].toIntOrNull() ?: 0
                    val j = t.indexOf("profile")
                    if (j >= 0 && j + 1 < t.size) prof = t[j + 1]
                }
                "group" -> {
                    if (t.size >= 3) groups[t[1]] = t[2].toDoubleOrNull() ?: 0.0
                }
                "feat" -> {
                    if (t.size >= 5) feats[t[1]] = Feat(t[2].toDoubleOrNull() ?: 0.0, t[3].toDoubleOrNull() ?: 0.0, t[4] == "1")
                }
            }
        }
        return if (head) Trace(ev, groups, feats, prof) else null
    }

    /** Valin'ny baiko "params" */
    fun params(lines: List<String>): Map<String, ParamInfo> {
        val m = LinkedHashMap<String, ParamInfo>()
        for (l in lines) {
            val t = tok(l)
            if (t.size >= 8 && t[0] == "param") {
                m[t[1]] = ParamInfo(
                    t[1], t[2].toIntOrNull() ?: 0, t[3].toIntOrNull() ?: 0, t[4].toIntOrNull() ?: 0,
                    t[5].toIntOrNull() ?: 0, t[6], t[7].toIntOrNull() ?: 1
                )
            }
        }
        return m
    }

    /** Valin'ny baiko "searchstats": "stats k v k v ..." */
    fun stats(lines: List<String>): Map<String, Long> {
        val m = LinkedHashMap<String, Long>()
        for (l in lines) {
            val t = tok(l)
            if (t.isNotEmpty() && t[0] == "stats") {
                var i = 1
                while (i + 1 < t.size) {
                    m[t[i]] = t[i + 1].toLongOrNull() ?: 0L
                    i += 2
                }
            }
        }
        return m
    }
}

class Proposal(val name: String, val group: String, val old: Int, val new: Int, val mean: Double, val isNew: Boolean)

object Learn {
    /**
     * items = (trace, signe): signe = +1 raha ny fotsy no nampiofana, -1 raha ny mainty (ny lalao nandresy).
     * mean(lanja) = salan'ny (feature net araka ny sisiny nandresy). Raha > 0 dia nanana betsaka kokoa ny mpandresy -> ampitomboina ny lanja;
     * raha < 0 -> ahena. Aorian'ny fampiofanana voalohany, ny lanja vaovao (tsy ao amin'ny `seen`) dia raisina foana na kely aza ny salany. Ny lanja search (null move, LMR...) dia tsy azo
     * tsoahina avy amin'ny lalao tokana: tsy ao anatin'ny soso-kevitra (SPRT no mitsara azy).
     */
    fun propose(
        items: List<Pair<Trace, Int>>, params: Map<String, ParamInfo>, current: Map<String, Int>,
        seen: Set<String>, rate: Double
    ): List<Proposal> {
        val n = items.size
        if (n == 0) return emptyList()
        val sum = HashMap<String, Double>()
        for ((tr, sg) in items) {
            for ((k, f) in tr.feats) {
                if (f.active) sum[k] = (sum[k] ?: 0.0) + sg * f.net
            }
        }
        val out = ArrayList<Proposal>()
        for ((k, s) in sum) {
            val info = params[k] ?: continue
            if (info.group == "search") continue
            val mean = s / n
            val isNew = seen.isNotEmpty() && !seen.contains(k)   // fampiofanana voalohany: tsy misy ★
            if (abs(mean) < 0.15 && !(isNew && abs(mean) > 0.0)) continue
            val cur = current[k] ?: info.def
            val mag = min(1.0, abs(mean) / 2.0)
            // lanja manomboka amin'ny 0 (PinPenalty, SkewerPenalty...): ny dingana dia mifototra amin'ny haavon'ny lanja (hi/5), tsy 4 fotsiny
            val base = if (cur == 0) max(4, info.hi / 5) else max(abs(cur), 4)
            val step = max(1, (0.25 * base * rate * mag).roundToInt())
            val nw = (cur + (if (mean > 0) step else -step)).coerceIn(info.lo, info.hi)
            if (nw != cur) out.add(Proposal(k, info.group, cur, nw, mean, isNew))
        }
        out.sortByDescending { abs(it.mean) }
        return out
    }
}

// =====================================================================================
// Ghost view / Race view (valin'ny baiko `ghostview` sy `raceview` an'ny moteur 1.2)
// =====================================================================================
/** Defense manakana ny ataka: case, karazana pièce (P N B R Q), lanja, vidin'ny fanalana (1 mora .. 3 mafy), mpanafika/mpiaro, `by` = case ny pièce mpanafika */
class DefInfo(
    val sq: Int, val pc: Char, val w: Int, val cost: Int, val att: Int, val prot: Int, val top: Boolean, val by: List<Int>,
    val pw: Int = -1          // piece power (%) an'io defense io; -1 = tsy fantatra
)

class GhostView(
    val side: Int, val king: Int, val realKing: Int, val score: Int, val tempo: Int, val cost: Int,
    val rcov12: Int, val cost6: Int, val pattern: Double, val check: Int,
    val zone: List<Int>, val gcov: List<Int>, val rcov: List<Int>, val blocked: List<Int>, val free: List<Int>,
    val future: List<Pair<Char, Int>>, val eta: Int, val committed: Int, val defCost: Int, val escapes: Int,
    val defs: List<DefInfo>, val shields: List<Pair<Int, Int>>, val heat: Map<Int, Int>
)

class PlanPiece(val pc: Char, val sq: Int, val d: Int, val committed: Boolean)
class RacePlan(val rank: Int, val eta: Int, val pieces: List<PlanPiece>)

class RaceSide(val side: Int, val eta: Int, val committed: Int, val d01: Int, val defCost: Int, val escapes: Int) {
    val plans = ArrayList<RacePlan>()
    val defs = ArrayList<DefInfo>()
    val shields = ArrayList<Pair<Int, Int>>()
    var care = 0.0
    var verdict = ""
}

class RaceFuture(val side: Int, val score: Int, val tempo: Int, val pval: Double, val pieces: List<Pair<Char, Int>>)

class RaceView(val sides: List<RaceSide>, val etaW: Int, val etaB: Int, val term: Int, val stm: Int) {
    val futures = ArrayList<RaceFuture>()                 // future (ghost) an'ny sisiny roa
    var first = "none"                                    // "w" / "b" / "tie" / "none": iza no tonga aloha
    var margin = 0.0                                      // elanelana (dingana)
    val suggest = HashMap<Int, Pair<String, Double>>()    // sisiny -> (care|letgo|take|none, margin)
}

/** Piece power (0..100%) isaky ny pièce: liberty, potential, safety/escape, adidy; libSq = lalana azo antoka, xrSq = lalana hisokatra raha mihetsika pion */
class PowerPiece(
    val side: Int, val pc: Char, val sq: Int, val power: Int, val lib: Int, val pot: Int, val safe: Int, val duty: Int,
    val mob: Int, val smob: Int, val open: Int, val lock: Int, val tags: List<String>,
    val libSq: List<Int>, val xrSq: List<Int>, val dutySq: List<Int>
)
class PowerSide(val side: Int, val avg: Int, val n: Int, val weakest: String, val strongest: String)
class PowerView(val stm: Int, val on: Boolean, val term: Int, val sides: List<PowerSide>, val pieces: List<PowerPiece>)

object ViewParse {
    private fun tok(l: String): List<String> = l.trim().split(" ").filter { it.isNotEmpty() }

    /** (t[from], t[from+1]), (t[from+2], t[from+3]) ... */
    private fun kv(t: List<String>, from: Int): Map<String, String> {
        val m = HashMap<String, String>()
        var i = from
        while (i + 1 < t.size) {
            m[t[i]] = t[i + 1]
            i += 2
        }
        return m
    }

    fun sq(n: String): Int =
        if (n.length >= 2 && n[0] in 'a'..'h' && n[1] in '1'..'8') (n[1] - '1') * 8 + (n[0] - 'a') else -1

    fun sqName(s: Int): String = "" + ('a' + s % 8) + ('1' + s / 8)

    private fun sqs(s: String): List<Int> = if (s == "-") emptyList() else s.split(",").map { sq(it) }.filter { it >= 0 }

    private fun defOf(t: List<String>): DefInfo? {
        if (t.size < 3) return null
        val m = kv(t, 3)
        val sqv = sq(t[1])
        if (sqv < 0 || t[2].isEmpty()) return null
        return DefInfo(
            sqv, t[2][0], m["w"]?.toIntOrNull() ?: 0, m["cost"]?.toIntOrNull() ?: 3, m["att"]?.toIntOrNull() ?: 0,
            m["prot"]?.toIntOrNull() ?: 0, m["top"] == "1", sqs(m["by"] ?: "-"), m["pw"]?.toIntOrNull() ?: -1
        )
    }

    private fun shieldOf(t: List<String>): Pair<Int, Int>? {
        if (t.size < 4) return null
        val s = sq(t[1])
        return if (s < 0) null else Pair(s, t[3].toIntOrNull() ?: 2)
    }

    /** null raha tsy misy "ghostview" na misy error (ohatra case misy pièce) */
    fun ghost(lines: List<String>): GhostView? {
        var head: Map<String, String>? = null
        var parts: Map<String, String> = emptyMap()
        var zone = emptyList<Int>(); var gcov = emptyList<Int>(); var rcov = emptyList<Int>()
        var blocked = emptyList<Int>(); var free = emptyList<Int>()
        var future = ArrayList<Pair<Char, Int>>()
        var eta: Map<String, String> = emptyMap()
        val defs = ArrayList<DefInfo>()
        val shields = ArrayList<Pair<Int, Int>>()
        val heat = LinkedHashMap<Int, Int>()
        for (l in lines) {
            val t = tok(l)
            if (t.isEmpty()) continue
            when (t[0]) {
                "ghostview" -> { if (t.size >= 2 && t[1] == "error") return null; head = kv(t, 1) }
                "parts" -> parts = kv(t, 1)
                "zone" -> { if (t.size >= 2) zone = sqs(t[1]) }
                "gcov" -> { if (t.size >= 2) gcov = sqs(t[1]) }
                "rcov" -> { if (t.size >= 2) rcov = sqs(t[1]) }
                "blocked" -> { if (t.size >= 2) blocked = sqs(t[1]) }
                "free" -> { if (t.size >= 2) free = sqs(t[1]) }
                "future" -> {
                    val m = kv(t, 1)
                    val ps = m["pieces"] ?: "-"
                    future = ArrayList()
                    if (ps != "-") for (e in ps.split(",")) {
                        if (e.length >= 3) { val s = sq(e.substring(1, 3)); if (s >= 0) future.add(Pair(e[0], s)) }
                    }
                }
                "eta" -> eta = kv(t, 0)
                "def" -> { val d = defOf(t); if (d != null) defs.add(d) }
                "shield" -> { val s = shieldOf(t); if (s != null) shields.add(s) }
                "heat" -> {
                    // heat <sq> <score> <tempo> <attacked>: tazonina ho an'ny toerana ahafahan'ny king mijanona (tsy voadona) ihany
                    if (t.size >= 5 && t[4] == "0") { val s = sq(t[1]); if (s >= 0) heat[s] = t[2].toIntOrNull() ?: 0 }
                }
            }
        }
        val h = head ?: return null
        return GhostView(
            if (h["side"] == "w") 0 else 1, sq(h["king"] ?: ""), sq(h["real_king"] ?: ""),
            h["score"]?.toIntOrNull() ?: 0, h["tempo"]?.toIntOrNull() ?: 0, h["cost"]?.toIntOrNull() ?: 0,
            parts["rcov12"]?.toIntOrNull() ?: 0, parts["cost6"]?.toIntOrNull() ?: 0, parts["pattern"]?.toDoubleOrNull() ?: 0.0,
            parts["check"]?.toIntOrNull() ?: 0,
            zone, gcov, rcov, blocked, free, future,
            eta["eta"]?.toIntOrNull() ?: 40, eta["committed"]?.toIntOrNull() ?: 0, eta["defense_cost"]?.toIntOrNull() ?: 0,
            eta["escapes"]?.toIntOrNull() ?: 0, defs, shields, heat
        )
    }

    private fun planPieces(s: String): List<PlanPiece> {
        val out = ArrayList<PlanPiece>()
        for (e in s.split(",")) {
            // Qd1:1*  -> pièce, case, elanelana, * = efa afaka manafika
            if (e.length < 5) continue
            val sqv = sq(e.substring(1, 3))
            if (sqv < 0) continue
            val rest = e.substring(4)
            val com = rest.endsWith("*")
            val d = rest.trimEnd('*').toIntOrNull() ?: 0
            out.add(PlanPiece(e[0], sqv, d, com))
        }
        return out
    }

    fun race(lines: List<String>): RaceView? {
        val sides = ArrayList<RaceSide>()
        var cur: RaceSide? = null
        var etaW = 40; var etaB = 40; var term = 0; var stm = 0
        var any = false
        val futures = ArrayList<RaceFuture>()
        var first = "none"; var margin = 0.0
        val suggest = HashMap<Int, Pair<String, Double>>()
        for (l in lines) {
            val t = tok(l)
            if (t.isEmpty()) continue
            when (t[0]) {
                "raceview" -> {
                    any = true
                    val m = kv(t, 1)
                    val rs = RaceSide(
                        if (m["side"] == "w") 0 else 1, m["eta"]?.toIntOrNull() ?: 40, m["committed"]?.toIntOrNull() ?: 0,
                        m["d01"]?.toIntOrNull() ?: 0, m["defense_cost"]?.toIntOrNull() ?: 0, m["escapes"]?.toIntOrNull() ?: 0
                    )
                    sides.add(rs)
                    cur = rs
                }
                "plan" -> {
                    val c = cur
                    if (c != null && t.size >= 6) c.plans.add(RacePlan(t[1].toIntOrNull() ?: 0, t[3].toIntOrNull() ?: 40, planPieces(t[5])))
                }
                "def" -> { val c = cur; val d = defOf(t); if (c != null && d != null) c.defs.add(d) }
                "shield" -> { val c = cur; val s = shieldOf(t); if (c != null && s != null) c.shields.add(s) }
                "race" -> {
                    val m = kv(t, 1)
                    etaW = m["eta_w"]?.toIntOrNull() ?: 40
                    etaB = m["eta_b"]?.toIntOrNull() ?: 40
                    term = m["term_white_pov"]?.toIntOrNull() ?: 0
                    stm = if (m["stm"] == "w") 0 else 1
                }
                "gfuture" -> {
                    if (t.size >= 3) {
                        val m = kv(t, 2)
                        val list = ArrayList<Pair<Char, Int>>()
                        val ps = m["pieces"] ?: "-"
                        if (ps != "-") for (e in ps.split(",")) {
                            if (e.length >= 3) { val s = sq(e.substring(1, 3)); if (s >= 0) list.add(Pair(e[0], s)) }
                        }
                        futures.add(RaceFuture(if (t[1] == "w") 0 else 1, m["score"]?.toIntOrNull() ?: 0, m["tempo"]?.toIntOrNull() ?: 0, m["pval"]?.toDoubleOrNull() ?: 0.0, list))
                    }
                }
                "first" -> {
                    if (t.size >= 2) { first = t[1]; margin = kv(t, 2)["margin"]?.toDoubleOrNull() ?: 0.0 }
                }
                "suggest" -> {
                    if (t.size >= 5) suggest[if (t[1] == "w") 0 else 1] = Pair(t[2], t[4].toDoubleOrNull() ?: 0.0)
                }
                "verdict" -> {
                    if (t.size >= 5) {
                        val rs = sides.firstOrNull { it.side == (if (t[1] == "w") 0 else 1) }
                        if (rs != null) { rs.care = t[3].toDoubleOrNull() ?: 0.0; rs.verdict = t[4] }
                    }
                }
            }
        }
        if (!any) return null
        val rv = RaceView(sides, etaW, etaB, term, stm)
        rv.futures.addAll(futures)
        rv.first = first
        rv.margin = margin
        rv.suggest.putAll(suggest)
        return rv
    }

    /** Valin'ny baiko `powerview` */
    fun power(lines: List<String>): PowerView? {
        var head: Map<String, String>? = null
        val sides = ArrayList<PowerSide>()
        val pieces = ArrayList<PowerPiece>()
        for (l in lines) {
            val t = tok(l)
            if (t.isEmpty()) continue
            when (t[0]) {
                "powerview" -> head = kv(t, 1)
                "side" -> {
                    if (t.size >= 3) {
                        val m = kv(t, 2)
                        sides.add(PowerSide(if (t[1] == "w") 0 else 1, m["avg"]?.toIntOrNull() ?: 0, m["n"]?.toIntOrNull() ?: 0, m["weakest"] ?: "-", m["strongest"] ?: "-"))
                    }
                }
                "piece" -> {
                    if (t.size >= 5) {
                        val sqv = sq(t[3])
                        if (sqv >= 0 && t[2].isNotEmpty()) {
                            val m = kv(t, 4)
                            val tg = m["tags"] ?: "-"
                            pieces.add(
                                PowerPiece(
                                    if (t[1] == "w") 0 else 1, t[2][0], sqv, m["power"]?.toIntOrNull() ?: 0, m["lib"]?.toIntOrNull() ?: 0,
                                    m["pot"]?.toIntOrNull() ?: 0, m["safe"]?.toIntOrNull() ?: 0, m["duty"]?.toIntOrNull() ?: 0,
                                    m["mob"]?.toIntOrNull() ?: 0, m["smob"]?.toIntOrNull() ?: 0, m["open"]?.toIntOrNull() ?: 0,
                                    m["lock"]?.toIntOrNull() ?: 0, if (tg == "-") emptyList() else tg.split(","),
                                    sqs(m["libsq"] ?: "-"), sqs(m["xrsq"] ?: "-"), sqs(m["dutysq"] ?: "-")
                                )
                            )
                        }
                    }
                }
            }
        }
        val h = head ?: return null
        return PowerView(if (h["stm"] == "w") 0 else 1, h["on"] == "1", h["term_white_pov"]?.toIntOrNull() ?: 0, sides, pieces)
    }
}
