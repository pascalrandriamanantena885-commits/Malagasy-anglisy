package mg.joro.chess.match

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import mg.joro.chess.chess.Res
import kotlin.math.roundToInt

/**
 * Calibrage ny "Game Rating": ACPL -> Elo.
 * Raha tsy misy teboka dia ampiasaina ny formula default (Rv.baseRating). Rehefa vita ny calibrage,
 * ny teboka (ACPL, Elo Stockfish UCI_Elo) no interpolé (linear), ary ny faran'ny curve dia mitohy amin'ny
 * endrika default nohitsin'ny haavo farany.
 */
object RatingCalib {
    var points by mutableStateOf<List<Pair<Double, Double>>>(emptyList())   // (acpl, elo), acpl miakatra
    var calMs by mutableStateOf(0)
    var status by mutableStateOf("")
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("ratingcalib", Context.MODE_PRIVATE)
        prefs = p
        points = normalize(parse(p.getString("points", "") ?: ""))
        calMs = p.getInt("ms", 0)
    }

    fun parse(txt: String): List<Pair<Double, Double>> = txt.split(',').mapNotNull {
        val a = it.split(':')
        val x = a.getOrNull(0)?.toDoubleOrNull()
        val y = a.getOrNull(1)?.toDoubleOrNull()
        if (x != null && y != null) Pair(x, y) else null
    }

    /** Alahatra araka ny ACPL; ny Elo tsy tokony hiakatra rehefa miakatra ny ACPL */
    fun normalize(raw: List<Pair<Double, Double>>): List<Pair<Double, Double>> {
        val out = ArrayList<Pair<Double, Double>>()
        for (p in raw.sortedBy { it.first }) {
            if (out.isNotEmpty() && p.first - out.last().first < 0.5) continue
            val elo = if (out.isEmpty()) p.second else minOf(p.second, out.last().second)
            out.add(Pair(p.first, elo))
        }
        return out
    }

    fun set(p: List<Pair<Double, Double>>, ms: Int = 0) {
        points = normalize(p)
        calMs = ms
        prefs?.edit()?.putString("points", points.joinToString(",") { "${it.first}:${it.second}" })?.putInt("ms", ms)?.apply()
    }

    fun reset() { set(emptyList(), 0) }

    fun describe(): String =
        if (points.size < 2) "Default (formule ACPL, tsy mbola calibré)"
        else "Calibré @ ${calMs}ms · " + points.joinToString(" · ") { "ACPL ${f1(it.first)} → ${it.second.roundToInt()}" }

    fun rating(acpl: Double): Int {
        val pts = points
        if (pts.size < 2) return Rv.ratingFromAcpl(acpl)
        val lo = pts.first()
        val hi = pts.last()
        val v: Double = when {
            acpl <= lo.first -> Rv.baseRating(acpl) * (lo.second / Rv.baseRating(lo.first))
            acpl >= hi.first -> Rv.baseRating(acpl) * (hi.second / Rv.baseRating(hi.first))
            else -> {
                var r = hi.second
                for (i in 0 until pts.size - 1) {
                    val a = pts[i]
                    val b = pts[i + 1]
                    if (acpl >= a.first && acpl <= b.first) {
                        val t = (acpl - a.first) / (b.first - a.first)
                        r = a.second + t * (b.second - a.second)
                        break
                    }
                }
                r
            }
        }
        return v.roundToInt().coerceIn(100, 3200)
    }

    /**
     * Milalao Stockfish (UCI_Elo = haavo) vs Stockfish (haavo mitovy), dinihina amin'ny `evalMs`
     * (mitovy amin'ny fanadihadiana mahazatra), ary raisina ny ACPL salan'isa ho an'ny haavo tsirairay.
     */
    suspend fun calibrate(evalMs: Int, levels: List<Int> = listOf(1400, 1800, 2200, 2600, 3000), games: Int = 2) {
        val entry = Host.engines.firstOrNull { it.id == "stockfish" } ?: throw IllegalStateException("Tsy misy Stockfish integré")
        val spec = EngineSpec(entry.path, entry.name)
        val pw = Player(spec)
        val pb = Player(spec)
        val pa = Player(spec)
        val pts = ArrayList<Pair<Double, Double>>()
        val rows = ArrayList<List<String>>()
        val title = "Calibrage Game Rating"
        try {
            pw.open(); pb.open(); pa.open()
            pa.setAll(mapOf("UCI_LimitStrength" to "false"))
            if (pa.eng.has("MultiPV")) pa.eng.setOption("MultiPV", "2")
            pa.eng.ready()
            val o = pw.eng.option("UCI_Elo")
            val lo = o?.min ?: 1320
            val hi = o?.max ?: 3190
            for ((li, lv0) in levels.withIndex()) {
                val lv = lv0.coerceIn(lo, hi)
                val opt = mapOf("UCI_LimitStrength" to "true", "UCI_Elo" to lv.toString())
                pw.setAll(opt); pb.setAll(opt)
                var sum = 0.0
                var cnt = 0
                for (g in 0 until games) {
                    status = "Haavo $lv (${li + 1}/${levels.size}) · lalao ${g + 1}/$games"
                    Host.post(title, status, listOf(listOf("SF Elo", "ACPL", "lalao")) + rows)
                    val pk = Openings.official(System.nanoTime() / 1000 + li * 1000L + g)   // book ofisialy (ECO)
                    val fen = pk.fen
                    val out = playGame(pw.eng, pb.eng, fen, TC(ms = 100), adjudicate = false, maxPlies = 120, prefix = pk.prefix)
                    if (out.moves.size < 24) continue
                    pa.eng.newGame()
                    val e = Analysis.evaluate(pa.eng, fen, out.moves, evalMs)
                    val r = Analysis.build(fen, e.used, e.boards, e.ev, "A", "B", Res.DRAW, "", "calib")
                    sum += (r.acpl[0] + r.acpl[1]) / 2.0
                    cnt++
                }
                if (cnt > 0) {
                    pts.add(Pair(sum / cnt, lv.toDouble()))
                    rows.add(listOf("$lv", f1(sum / cnt), "$cnt"))
                }
            }
            if (pts.size >= 2) {
                set(pts, evalMs)
                status = "Vita: ${points.size} teboka @ ${evalMs}ms. Ny Game Rating vaovao dia mampiasa ity calibrage ity."
            } else {
                status = "Tsy ampy ny angona (lalao fohy loatra). Tsy novana ny calibrage."
            }
            Host.post(title, status, listOf(listOf("SF Elo", "ACPL", "lalao")) + rows)
            Notifier.notify("$title vita", status)
        } finally {
            pw.close(); pb.close(); pa.close()
        }
    }
}
