package mg.joro.chess.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import mg.joro.chess.CrashLog

private fun copyLog(ctx: Context) {
    try {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Blind crash log", CrashLog.text))
        Toast.makeText(ctx, "Voakopia", Toast.LENGTH_SHORT).show()
    } catch (_: Throwable) { }
}

@Composable
private fun LogBox() {
    Column(Modifier.fillMaxWidth().heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
        Text(CrashLog.text.take(6000), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

/** Dialog aseho rehefa misokatra ny app aorian'ny crash */
@Composable
fun CrashDialog() {
    if (!CrashLog.showDialog || CrashLog.text.isEmpty()) return
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = { CrashLog.showDialog = false },
        title = { Text("Nianjera ny app farany") },
        text = { LogBox() },
        confirmButton = { TextButton(onClick = { copyLog(ctx) }) { Text("Kopia") } },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { CrashLog.clear() }) { Text("Fafao") }
                TextButton(onClick = { CrashLog.showDialog = false }) { Text("Akatony") }
            }
        }
    )
}

/** Panel ao amin'ny Réglages */
@Composable
fun CrashPanel() {
    val ctx = LocalContext.current
    Panel("Log crash", subtitle = if (CrashLog.text.isEmpty()) "Tsy misy crash voatahiry" else "Misy hadisoana voatahiry", glyph = "⚠", startOpen = CrashLog.text.isNotEmpty()) {
        if (CrashLog.text.isEmpty()) {
            Caption("Tsy misy crash na hadisoana tsy voasambotra hatramin'izay.")
        } else {
            LogBox()
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { copyLog(ctx) }) { Text("Kopia") }
                OutlinedButton(onClick = { CrashLog.clear() }) { Text("Fafao") }
            }
        }
    }
}
