package mg.joro.chess.ui

import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.abs
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import mg.joro.chess.match.*

@Composable
fun TrainingScreen() {
    val setup = remember { mutableStateOf("e4") }
    val nameSt = remember { mutableStateOf("") }
    var side by remember { mutableIntStateOf(0) }
    var flip by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val g = Training.game
    Training.rev      // mamaky ny rev mba hamerenana ny composition
    Training.statRev
    Training.viewRev
    Column(Modifier.padding(10.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (g != null) {
            val trainedTxt = if (Training.trained == 0) "Fotsy" else "Mainty"
            Text("${Training.startName} · ampiofanina: $trainedTxt · profil ${Training.pid()}", fontSize = 14.sp)
            val hide = Training.mode == 1 && Training.ghostHide
            val kingNow = if (Training.ghostKing >= 0) Training.ghostKing else (Training.ghost?.realKing ?: -1)
            BoardView(if (hide) Training.ghostBoard() else g.board, if (Training.trained == 1) !flip else flip,
                if (hide) (if (Training.kingSel) kingNow else -1) else Training.selected,
                if (hide) emptySet() else Training.targets, g.moves.lastOrNull(),
                onTap = { if (hide) Training.ghostTap(it) else Training.tap(it) },
                overlay = Training.overlay(), rings = Training.rings())
            Text(Training.status.ifEmpty {
                if (Training.busy) "Mieritreritra... ${Training.info}"
                else if (g.result != Res.ONGOING) ""
                else if (g.board.stm == 0) "Fotsy no hihetsika" else "Mainty no hihetsika"
            })
            Column(Modifier.heightIn(max = 110.dp).verticalScroll(rememberScrollState())) {
                Training.sans.chunked(2).forEachIndexed { i, pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("${i + 1}.", Modifier.width(30.dp), fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                        pair.forEach { san -> Text(san, fontSize = 14.sp, fontFamily = FontFamily.Monospace) }
                    }
                }
            }
            val canMove = !Training.busy && g.result == Res.ONGOING
            Text("Iza no hihetsika ankehitriny? (hetsika iray isaky ny tsindrio)", fontSize = 14.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { Toast.makeText(ctx, "Tsindrio ny pièce, avy eo ny toerana", Toast.LENGTH_SHORT).show() }) { Text("✋ Manuel") }
                Button(enabled = canMove, onClick = { Training.engineMove(0) }) { Text("⚙ Moteur ▶") }
                Button(enabled = canMove, onClick = { Training.engineMove(1) }) { Text("🐟 SF ▶") }
            }
            Field("ms isaky ny hetsika (Moteur / SF)", Training.moteurMs, true)
            StrengthPicker("Hery Stockfish (Elo)", Training.sfElo)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { flip = !flip }) { Text("Vadiho") }
                OutlinedButton(onClick = { Training.undo() }) { Text("Undo") }
                OutlinedButton(onClick = { Training.markWin() }) { Text("✔ Fandresena") }
                OutlinedButton(onClick = { Training.stop(); Training.status = "Najanona" }) { Text("■ Ajanony") }
            }
            TrainView()
            TrainStats()
            TrainLearn()
        }
        TrainSetup(setup, nameSt, side, { side = it })
        TrainProfiles()
    }
    if (Training.pendingPromo.isNotEmpty()) {
        AlertDialog(onDismissRequest = { Training.pendingPromo = emptyList() }, confirmButton = {},
            title = { Text("Promotion") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("♕" to 5, "♖" to 4, "♗" to 3, "♘" to 2).forEach { (sym, p) -> Button(onClick = { Training.promote(p) }) { Text(sym) } }
                }
            })
    }
}

@Composable
private fun TrainSetup(setup: MutableState<String>, nameSt: MutableState<String>, side: Int, onSide: (Int) -> Unit) {
    val ctx = LocalContext.current
    HorizontalDivider()
    Text("Fampiofanana vaovao", style = MaterialTheme.typography.titleSmall)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("e4", "d4", "c4", "Nf3", "e4 e5 f4", "e4 c5").forEach { s ->
            FilterChip(selected = setup.value == s, onClick = { setup.value = s }, label = { Text(s) })
        }
    }
    Field("Opening (SAN: e4 / e4 c5 ; na FEN)", setup)
    Field("Anarana (azo avela foana)", nameSt)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = side == 0, onClick = { onSide(0) }, label = { Text("Ampiofanina: Fotsy") })
        FilterChip(selected = side == 1, onClick = { onSide(1) }, label = { Text("Mainty") })
    }
    Button(onClick = {
        val txt = setup.value.trim()
        val pl: PgnLine? = if (txt.contains('/')) {
            try { Board.fromFen(txt); PgnLine(txt, emptyList(), txt) } catch (_: Exception) { null }
        } else Pgn.movesOf(txt)
        if (pl == null) {
            Toast.makeText(ctx, "Opening/FEN diso", Toast.LENGTH_SHORT).show()
        } else {
            val key = Board.fromFen(pl.endFen).key()
            val nm = nameSt.value.trim().ifEmpty { OpeningBook.name(key)?.name ?: (if (txt.isEmpty()) "Position fototra" else txt) }
            Training.begin(pl.endFen, nm, side)
        }
    }) { Text("Manomboka ny lalao fampiofanana") }
}

private fun pc(a: Long?, b: Long?): String {
    if (a == null || b == null || b == 0L) return "-"
    return String.format(Locale.US, "%d/%d (%.0f%%)", a, b, 100.0 * a / b)
}

@Composable
private fun TrainStats() {
    Training.statRev
    Text("Statistique (araka ny sisiny ampiofanina)", style = MaterialTheme.typography.titleSmall)
    val t = Training.cur
    val sg = if (Training.trained == 0) 1 else -1
    if (t == null) {
        Text("Mbola tsy misy (miandry ny moteur JORO)", fontSize = 14.sp)
    } else {
        val sb = StringBuilder()
        sb.append("Eval ${f2(sg * t.evalWhite / 100.0)}   profil: ${t.profile}\n")
        for (e in t.groups.entries.sortedByDescending { abs(it.value) }) {
            if (e.value != 0.0) sb.append(String.format(Locale.US, "[%-16s] %7.1f\n", e.key, sg * e.value))
        }
        sb.append(String.format(Locale.US, "%-17s %6s %7s %6s\n", "Lanja", "net", "cp", "moy"))
        val rows = t.feats.entries.filter { it.value.active }.sortedByDescending { abs(it.value.cp) }.take(18)
        for (e in rows) {
            val nm = (if (Training.isNew(e.key)) "★" else " ") + e.key
            sb.append(String.format(Locale.US, "%-17s %6.1f %7.1f %6.2f\n", nm, sg * e.value.net, sg * e.value.cp, Training.mean(e.key)))
        }
        Text(sb.toString(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
    }
    val s = Training.searchStat
    if (s.isNotEmpty()) {
        val txt = "Search: null move ${pc(s["null_cut"], s["null_try"])} · LMR re-search ${pc(s["lmr_research"], s["lmr_try"])}\n" +
            "RFP cut ${s["rfp_cut"] ?: 0} · TT cut ${s["tt_cut"] ?: 0} · hetsika 1 cut ${pc(s["first_cut"], s["beta_cut"])}"
        Text(txt, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
    }
}

@Composable
private fun TrainLearn() {
    val ctx = LocalContext.current
    HorizontalDivider()
    Text("Fianarana avy amin'ny fandresena farany", style = MaterialTheme.typography.titleSmall)
    Field("Rate (1.0 = ~25% ny lanja isaky ny dingana)", Training.rate)
    Button(enabled = !Training.busy, onClick = { Training.learn() }) { Text("🎓 Alaina ny lanja vaovao") }
    if (Training.learnMsg.isNotEmpty()) Text(Training.learnMsg, fontSize = 14.sp)
    for (r in Training.rows) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = r.on, onCheckedChange = { r.on = it })
            Column(Modifier.weight(1f)) {
                Text((if (r.p.isNew) "★ " else "") + r.p.name + " [" + r.p.group + "]", fontSize = 14.sp)
                Text("${r.p.old} → ${r.nw}   (moy ${f2(r.p.mean)})", fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            }
            OutlinedButton(onClick = { r.nw = r.nw - 1 }) { Text("−") }
            OutlinedButton(onClick = { r.nw = r.nw + 1 }) { Text("+") }
        }
    }
    if (Training.rows.isNotEmpty()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = Training.autoSprt, onCheckedChange = { Training.autoSprt = it })
            Text("Alefa ho azy ny SPRT aorian'ny Apply", fontSize = 14.sp)
        }
        if (Training.autoSprt) {
            Field("Lalao miaraka (parallèle)", Training.sprtWorkers, true)
            Text("TC: ${Nav.tc.toTC().text()} · Elo ${Training.sprtElo0.value}/${Training.sprtElo1.value} · max ${Training.sprtMax.value} (azo ovaina ao amin'ny \"Profil isaky ny opening\")", fontSize = 13.sp)
        }
        Button(onClick = { Toast.makeText(ctx, Training.applyProvisional(Nav.tc.toTC()), Toast.LENGTH_LONG).show() }) { Text("Apply (provisoire)") }
        Text("Ny lanja search (null move, LMR...) dia tsy azo tsoahina avy amin'ny lalao tokana; ny SPRT no mitsara azy.", fontSize = 13.sp)
    }
}

@Composable
private fun TrainProfiles() {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    HorizontalDivider()
    Text("Profil isaky ny opening", style = MaterialTheme.typography.titleSmall)
    if (OProfiles.list.isEmpty()) Text("Mbola tsy misy. Mifidiana opening, mihetsika, tsindrio 'Alaina ny lanja' ary 'Apply'.", fontSize = 14.sp)
    if (OProfiles.list.any { it.active.isNotEmpty() }) {
        OutlinedButton(onClick = {
            clip.setText(AnnotatedString(OProfiles.exportRelease()))
            Toast.makeText(ctx, "Voakopia: apetaho ao amin'ny assets/default_oprofiles.txt", Toast.LENGTH_LONG).show()
        }) { Text("📋 Copier profil nekena (release)") }
    }
    val anyProv = OProfiles.list.any { it.prov != null }
    if (anyProv) {
        Text("SPRT (opening ihany: provisoire vs taloha)", fontSize = 14.sp)
        Field("Elo0", Training.sprtElo0); Field("Elo1", Training.sprtElo1); Field("Lalao max", Training.sprtMax, true)
        Field("Lalao miaraka (parallèle, 1..${ParSprt.clampWorkers(64)})", Training.sprtWorkers, true)
        TcPicker(Nav.tc)
    }
    for (p in OProfiles.list) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("${p.name}  (${OProfiles.sideWord(p.side)})  · ${p.id}", style = MaterialTheme.typography.titleSmall)
                val shown = p.prov ?: p.active
                Text((if (p.prov != null) "PROVISOIRE: " else "Nekena: ") + shown.entries.joinToString(", ") { it.key + "=" + it.value },
                    fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                if (p.sprt.isNotEmpty()) Text("SPRT: ${p.sprt}", fontSize = 14.sp)
                if (p.prov != null && !OProfiles.canAccept(p))
                    Text(when (p.sprtOk) {
                        false -> "✗ H0: tsy azo ampiasaina ny Update moteur. Avereno ny Training na ✖ Delete experience."
                        else -> "Update moteur dia voasakana mandra-pahatongan'ny SPRT H1."
                    }, fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (p.prov != null) {
                        Button(enabled = !Host.running.value, onClick = {
                            val ok = Training.startSprt(p.id, Nav.tc.toTC())
                            Toast.makeText(ctx, if (ok) "SPRT natomboka (jereo ny tatitra ambany)" else "Asa hafa mbola mandeha", Toast.LENGTH_SHORT).show()
                        }) { Text("▶ SPRT") }
                        Button(enabled = OProfiles.canAccept(p), onClick = {
                            val done = OProfiles.accept(p.id)
                            Toast.makeText(ctx, if (done) "Moteur nohavaozina" else "Tsy azo: mila H1 ny SPRT aloha", Toast.LENGTH_SHORT).show()
                        }) { Text("✔ Update moteur") }
                        OutlinedButton(onClick = { OProfiles.discard(p.id) }) { Text("✖ Delete experience") }
                    }
                    if (p.active.isNotEmpty()) OutlinedButton(onClick = {
                        clip.setText(AnnotatedString(OpText.line(p)))
                        Toast.makeText(ctx, "Voakopia", Toast.LENGTH_SHORT).show()
                    }) { Text("📋 Copier") }
                    OutlinedButton(onClick = { OProfiles.remove(p.id) }) { Text("🗑 Fafao") }
                }
                RollbackPanel(p)
            }
        }
    }
    ReportPanel()
}


/** Tantara: version nekena taloha azo averina (Rollback). Ny version ankehitriny dia voatahiry koa, ka azo averina indray. */
@Composable
private fun RollbackPanel(p: OpProfile) {
    if (p.hist.isEmpty()) return
    val ctx = LocalContext.current
    var open by remember(p.id) { mutableStateOf(false) }
    TextButton(onClick = { open = !open }) { Text((if (open) "▾" else "▸") + " ↩ Rollback · version taloha (${p.hist.size})") }
    if (open) {
        p.hist.forEachIndexed { i, h ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("${History.date(h.time)} · ${h.active.size} lanja", style = MaterialTheme.typography.titleSmall)
                    Text("Nosoloina rehefa: ${h.by.ifEmpty { "-" }}", fontSize = 13.sp)
                    Text("Fiovana raha averina: " + OpText.diff(p.active, h.active), fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    OutlinedButton(onClick = {
                        OProfiles.rollback(p.id, i)
                        Toast.makeText(ctx, "Naverina ny version ${History.date(h.time)}", Toast.LENGTH_SHORT).show()
                    }) { Text("↩ Avereno ity version ity") }
                }
            }
        }
    }
}

// =====================================================================================
// Ghost view / Race view / fanapahan-kevitra / tanjona
// =====================================================================================
private fun nm(s: Int): String = ViewParse.sqName(s)

@Composable
private fun TrainView() {
    Training.rev
    Training.viewRev
    HorizontalDivider()
    Text("Mode fanadihadiana (Ghost / Race)", style = MaterialTheme.typography.titleSmall)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = Training.mode == 1, onClick = { Training.openView(1) }, label = { Text("👻 Ghost") })
        FilterChip(selected = Training.mode == 2, onClick = { Training.openView(2) }, label = { Text("🏁 Race") })
        FilterChip(selected = Training.mode == 3, onClick = { Training.openView(3) }, label = { Text("⚡ Power") })
    }
    if (Training.mode == 1) GhostPanel()
    if (Training.mode == 2) RacePanel()
    if (Training.mode == 3) PowerPanel()
    DecisionRow()
    if (Training.mode != 0) {
        Text("Ao amin'ny mode ity dia sandbox ny hetsika (Manuel / Moteur ▶ / SF ▶ / Undo). Raha mahomby dia Apply.", fontSize = 13.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { Training.applyView() }) { Text("✔ Apply ao amin'ny lalao") }
            OutlinedButton(onClick = { Training.cancelView() }) { Text("↩ Annuler") }
        }
    }
    if (Training.viewMsg.isNotEmpty()) Text(Training.viewMsg, fontSize = 14.sp)
    MissionBox()
}

@Composable
private fun DecisionRow() {
    Text("Fanapahan-kevitra ho an'ny moteur (hetsika manaraka)", fontSize = 14.sp)
    val sug = Training.suggestedCode()
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = Training.decision == 1, onClick = { Training.setDecision(1) }, label = { Text((if (sug == 1) "★ " else "") + "CARE") })
        FilterChip(selected = Training.decision == 2, onClick = { Training.setDecision(2) }, label = { Text((if (sug == 2) "★ " else "") + "LET IT GO") })
        FilterChip(selected = Training.decision == 3, onClick = { Training.setDecision(3) }, label = { Text((if (sug == 3) "★ " else "") + "LET IT TAKE") })
        FilterChip(selected = Training.decision == 0, onClick = { Training.setDecision(0) }, label = { Text("AUTO") })
    }
}

private fun costTxt(c: Int): String = when (c) { 1 -> "mora"; 2 -> "mikasika"; else -> "mafy" }

@Composable
private fun DefRow(d: DefInfo, attacker: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            "${d.pc}${nm(d.sq)}  lanja ${d.w} · fanalana ${costTxt(d.cost)} · ${d.att}↔${d.prot}" +
                (if (d.pw >= 0) " · power ${d.pw}%" + (if (d.pw < 33) " malemy" else "") else "") + (if (d.top) " ★" else ""),
            Modifier.weight(1f), fontSize = 14.sp, fontFamily = FontFamily.Monospace
        )
        OutlinedButton(onClick = { Training.setTarget(d, attacker) }) { Text("🎯") }
    }
}

@Composable
private fun GhostPanel() {
    val v = Training.ghost
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = Training.ghostSide == 0, onClick = { Training.setGhostSide(0) }, label = { Text("Mpanafika: Fotsy") })
        FilterChip(selected = Training.ghostSide == 1, onClick = { Training.setGhostSide(1) }, label = { Text("Mainty") })
        FilterChip(selected = Training.ghostHide, onClick = { Training.toggleHide() }, label = { Text("Hanafina ny defense") })
        FilterChip(selected = Training.showHeat, onClick = { Training.toggleHeat() }, label = { Text("Heatmap") })
    }
    if (Training.ghostHide) {
        Text("Board ghost: tsindrio ny king mpanohitra, avy eo ny case iray (what-if). Tsy azo atao ny hetsika eto: esory ny 'Hanafina ny defense' vao milalao.", fontSize = 13.sp)
    }
    if (Training.ghostKing >= 0) OutlinedButton(onClick = { Training.resetGhostKing() }) { Text("King: miverina amin'ny tena izy") }
    if (v == null) {
        Text("Miandry ny moteur...", fontSize = 14.sp)
    } else {
        val fut = v.future.joinToString(" ") { "${it.first}${nm(it.second)}" }
        val sb = StringBuilder()
        sb.append("Ghost score ${v.score}  tempo ${v.tempo}  cost ${v.cost}\n")
        sb.append("rcov ${v.rcov12} + cost ${v.cost6} + pattern ${f1(v.pattern)} + check ${v.check}\n")
        sb.append("Zone: ghost ${v.gcov.size} · tena izy ${v.rcov.size} · voasakana ${v.blocked.size} · malalaka ${v.free.size}\n")
        sb.append("Future: " + (if (fut.isEmpty()) "-" else fut) + "\n")
        sb.append("ETA ${v.eta} (committed ${v.committed}, fanalana ${v.defCost}, escape ${v.escapes})")
        Text(sb.toString(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
        Text("Loko: manga=zone · maitso=voasaron'ny tena izy · volomparasy=ghost ihany (voasakan'ny defense) · mavo=voasakana · mena=malalaka ho an'ny king · peratra mavo=future", fontSize = 13.sp)
        if (v.defs.isEmpty() && v.shields.isEmpty()) {
            Text("Tsy misy defense manakana (ny ghost = tena izy).", fontSize = 14.sp)
        } else {
            Text("Defense manakana ny future (tsindrio 🎯 ho tanjona hofafana):", fontSize = 14.sp)
            for (d in v.defs) DefRow(d, v.side)
            if (v.defs.isNotEmpty()) OutlinedButton(onClick = { Training.autoTarget(v.side) }) { Text("🎯 Tanjona mora indrindra (fanalana + power)") }
            if (v.shields.isNotEmpty()) {
                Text("Pion shield: " + v.shields.joinToString(" ") { nm(it.first) + "(" + costTxt(it.second) + ")" }, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun RacePanel() {
    val rv = Training.race
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = Training.raceSide == 0, onClick = { Training.setRaceSide(0) }, label = { Text("Drafitra ataka: Fotsy") })
        FilterChip(selected = Training.raceSide == 1, onClick = { Training.setRaceSide(1) }, label = { Text("Mainty") })
    }
    if (rv == null) {
        Text("Miandry ny moteur...", fontSize = 14.sp)
        return
    }
    val sb = StringBuilder()
    sb.append("ETA  Fotsy ${rv.etaW}   Mainty ${rv.etaB}   (40 = tsy misy)\n")
    sb.append("Race term ${rv.term} (fotsy POV) · hetsika: ${if (rv.stm == 0) "Fotsy" else "Mainty"}\n")
    for (rs in rv.sides) {
        sb.append("${if (rs.side == 0) "Fotsy" else "Mainty"}: ${rs.verdict.uppercase()} (care ${f2(rs.care)}) · fanalana ${rs.defCost} · escape ${rs.escapes}\n")
    }
    Text(sb.toString(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
    val fsb = StringBuilder()
    for (f in rv.futures) {
        val pcs = f.pieces.joinToString(" ") { "${it.first}${nm(it.second)}" }
        fsb.append("Future ${if (f.side == 0) "Fotsy" else "Mainty"}: ghost ${f.score}, tempo ${f.tempo}  ${if (pcs.isEmpty()) "-" else pcs}\n")
    }
    val firstTxt = when (rv.first) {
        "w" -> "Fotsy tonga voalohany (+${f2(rv.margin)} dingana)"
        "b" -> "Mainty tonga voalohany (+${f2(rv.margin)} dingana)"
        "tie" -> "Mitovy"
        else -> "Tsy misy ataka"
    }
    fsb.append("Tonga voalohany: $firstTxt")
    Text(fsb.toString(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
    val sg = rv.suggest[Training.trained]
    if (sg != null) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Soso-kevitra: ${sg.first.uppercase()} (${f2(sg.second)})", fontSize = 14.sp)
            OutlinedButton(onClick = { Training.applySuggestion() }) { Text("Ekeo") }
        }
    }
    val rs = rv.sides.firstOrNull { it.side == Training.raceSide }
    if (rs != null) {
        if (rs.plans.isEmpty()) {
            Text("Tsy misy drafitra ataka (pièce tsy ampy).", fontSize = 14.sp)
        } else {
            Text("Drafitra ataka (fohy indrindra aloha) — tsindrio hanamarika eo amin'ny board:", fontSize = 14.sp)
            rs.plans.forEachIndexed { i, pl ->
                val txt = (if (i == Training.planSel) "▶ " else "  ") + "${pl.rank}. ETA ${pl.eta}  " +
                    pl.pieces.joinToString("  ") { "${it.pc}${nm(it.sq)}:${it.d}" + (if (it.committed) "*" else "") }
                TextButton(onClick = { Training.planSel = i }) { Text(txt, fontSize = 13.sp, fontFamily = FontFamily.Monospace) }
            }
            Text("* = efa manafika ny zone ny king. Isa = dingana mbola ilaina.", fontSize = 13.sp)
        }
        if (rs.defs.isNotEmpty()) {
            Text("Defense mpanohitra manakana (tsindrio 🎯 ho tanjona hofafana):", fontSize = 14.sp)
            for (d in rs.defs) DefRow(d, rs.side)
            OutlinedButton(onClick = { Training.autoTarget(rs.side) }) { Text("🎯 Tanjona mora indrindra (fanalana + power)") }
        }
    }
}

@Composable
private fun MissionBox() {
    Training.rev
    Training.viewRev
    val ms = Training.mission ?: return
    val done = Training.missionDone()
    val etaNow = if (Training.mode == 2) Training.race?.sides?.firstOrNull { it.side == Training.raceSide }?.eta
                 else Training.ghost?.eta
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("🎯 Tanjona: ${ms.pc}${nm(ms.sq)} — " + (if (done) "VOAFAFA ✔ (mety Apply)" else "mbola eo"), style = MaterialTheme.typography.titleSmall)
            Text("ETA taloha ${ms.startEta} → ankehitriny ${etaNow ?: "?"}. Ny moteur dia mitady hetsika manala azy rehefa tsindriana ny 'Moteur ▶'.", fontSize = 13.sp)
            OutlinedButton(onClick = { Training.clearTarget() }) { Text("Esory ny tanjona") }
        }
    }
}


// =====================================================================================
// Piece Power view: tabilao (mainty = ankavia, fotsy = ankavanana), voasokajy araka ny herin'ny pièce
// =====================================================================================
private fun tagTxt(t: String): String = when (t) {
    "selfblock" -> "selfblk"; "pinned" -> "PIN"; "trapped" -> "TRAP"; "hanging" -> "HANG"; "locked" -> "lock"; "passive" -> "pass"
    "cramped" -> "cramp"; "check" -> "CHK"; "strong" -> "★"
    "mouse" -> "MOUSE"; "trapnear" -> "trap~"; "relpin" -> "RPIN"; "skewer" -> "SKEW"; "disc" -> "DISC"; else -> t
}

private fun bar(p: Int): String {
    val n = (p.coerceIn(0, 100) + 5) / 10
    return "█".repeat(n) + "░".repeat(10 - n)
}

@Composable
private fun PowerSideCol(pv: PowerView, side: Int, modifier: Modifier) {
    val sd = pv.sides.firstOrNull { it.side == side }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Text((if (side == 0) "FOTSY" else "MAINTY") + "  moy ${sd?.avg ?: 0}%", fontSize = 14.sp, style = MaterialTheme.typography.titleSmall)
        val list = pv.pieces.filter { it.side == side }.sortedByDescending { it.power }
        for (pp in list) {
            val sel = Training.powerSel == pp.sq
            TextButton(onClick = { Training.powerSel = if (sel) -1 else pp.sq; Training.viewRev++ }, contentPadding = PaddingValues(2.dp)) {
                Column(Modifier.fillMaxWidth()) {
                    Text((if (sel) "▶" else "") + "${pp.pc}${nm(pp.sq)} ${pp.power}% " + bar(pp.power), fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    if (pp.tags.isNotEmpty()) Text(pp.tags.joinToString(" ") { tagTxt(it) }, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun PowerPanel() {
    val pv = Training.power
    if (pv == null) {
        Text("Miandry ny moteur...", fontSize = 14.sp)
        return
    }
    Text("Herin'ny pièce (liberty 40% · potential 20% · safety/escape 20% · adidy 20%). King = escape.", fontSize = 13.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PowerSideCol(pv, 1, Modifier.weight(1f))      // ankavia = mainty
        PowerSideCol(pv, 0, Modifier.weight(1f))      // ankavanana = fotsy
    }
    val sel = pv.pieces.firstOrNull { it.sq == Training.powerSel }
    if (sel != null) {
        val sb = StringBuilder()
        sb.append("${sel.pc}${nm(sel.sq)}  POWER ${sel.power}%\n")
        sb.append("Liberty ${sel.lib}%  (${sel.smob} azo antoka / ${sel.mob})\n")
        if (sel.pc != 'K') {
            sb.append("Potential ${sel.pot}%  (hisokatra ${sel.open} · mbola mikatona ${sel.lock})\n")
            sb.append("Safety/escape ${sel.safe}%   Adidy ${sel.duty}%\n")
        } else {
            sb.append("Escape ${sel.smob} case azo ialana\n")
        }
        sb.append("Tag: " + (if (sel.tags.isEmpty()) "-" else sel.tags.joinToString(" ")))
        Text(sb.toString(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
        Text("Board: maitso=lalana azo antoka · manga=hisokatra raha mihetsika pion · mavo=adidy · peratra mavo=pièce voafidy", fontSize = 13.sp)
    } else {
        Text("Tsindrio pièce iray hijerena ny square sy ny lalany. Peratra mena = malemy (<33%), maitso = mahery (≥66%).", fontSize = 13.sp)
    }
    Text("Power eval term (fotsy POV): ${pv.term} cp · ${if (pv.on) "mihetsika ao amin'ny search" else "tsy mihetsika (PowerOn=0); statistique ihany"}", fontSize = 13.sp)
}
