package mg.joro.chess.match

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Game
import mg.joro.chess.chess.Res
import mg.joro.chess.uci.Info
import mg.joro.chess.uci.UciEngine
import java.util.Locale
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.random.Random

data class EngineSpec(val path: String, val label: String, val options: Map<String, String> = emptyMap())
/** Time control: movetime | tc (base+inc, ms) | nodes | depth */
data class TC(
    val ms: Int = 200, val mode: String = "movetime", val base: Int = 10_000, val inc: Int = 100,
    val nodes: Long = 100_000, val depth: Int = 8
) {
    val clocked get() = mode == "tc"
    fun goArgs(wt: Int, bt: Int): String = when (mode) {
        "tc" -> "wtime $wt btime $bt winc $inc binc $inc"
        "nodes" -> "nodes $nodes"
        "depth" -> "depth $depth"
        else -> "movetime $ms"
    }
    fun timeout(clock: Int): Long = when (mode) {
        "tc" -> clock + 3_000L
        "movetime" -> ms + 10_000L
        else -> 120_000L
    }
    fun text(): String = when (mode) {
        "tc" -> "${f1(base / 1000.0)}s+${f1(inc / 1000.0)}s"
        "nodes" -> "$nodes nodes"
        "depth" -> "depth $depth"
        else -> "${ms}ms/coup"
    }
}

fun parseOpts(s: String): Map<String, String> =
    s.split(';', ',').mapNotNull {
        val i = it.indexOf('=')
        if (i > 0) it.substring(0, i).trim() to it.substring(i + 1).trim() else null
    }.toMap()

fun f1(x: Double) = String.format(Locale.US, "%.1f", x)
fun f2(x: Double) = String.format(Locale.US, "%.2f", x)

class Player(val spec: EngineSpec) {
    val eng = UciEngine(spec.path)
    suspend fun open(extra: Map<String, String> = emptyMap()) {
        eng.start()
        if (eng.has("Hash")) eng.setOption("Hash", "16")
        if (eng.has("Threads")) eng.setOption("Threads", "1")
        setAll(spec.options + extra)
        eng.ready()
    }
    suspend fun setAll(o: Map<String, String>) {
        for ((k, v) in o) {
            // "oprof:<id>" = profil isaky ny opening (baiko manokana, tsy setoption)
            if (k.startsWith("oprof:")) eng.send("oprof add " + k.removePrefix("oprof:") + " " + v) else eng.setOption(k, v)
        }
        eng.ready()
    }
    fun close() = eng.close()
}

object Openings {
    /** Ouverture aléatoire (plies demi-coups) — mitovy ho an'ny lalao roa miova xolor (paire) */
    fun fen(seed: Long, plies: Int = 4): String {
        Books.pick(seed)?.let { return it }
        var s = seed
        while (true) {
            val rng = Random(s)
            var b = Board.fromFen(Board.START)
            var ok = true
            repeat(plies) {
                if (ok) {
                    val l = b.legalMoves()
                    if (l.isEmpty()) ok = false else b = b.play(l[rng.nextInt(l.size)])
                }
            }
            if (ok && b.legalMoves().size >= 15) return b.toFen()
            s += 7919
        }
    }
}

object Stats {
    fun scoreToElo(s: Double): Double {
        val x = s.coerceIn(0.001, 0.999)
        return -400.0 * log10(1.0 / x - 1.0)
    }
    fun eloToScore(e: Double) = 1.0 / (1.0 + 10.0.pow(-e / 400.0))

    private fun variance(w: Int, d: Int, l: Int): Double {
        val n = (w + d + l).toDouble()
        val s = (w + 0.5 * d) / n
        return (w * (1 - s) * (1 - s) + d * (0.5 - s) * (0.5 - s) + l * s * s) / n
    }
    fun elo(w: Int, d: Int, l: Int): Double {
        val n = w + d + l
        return if (n == 0) 0.0 else scoreToElo((w + 0.5 * d) / n)
    }
    fun err95(w: Int, d: Int, l: Int): Double {
        val n = w + d + l
        if (n < 2) return 999.0
        val s = (w + 0.5 * d) / n
        val se = sqrt(variance(w, d, l) / n)
        return (scoreToElo(s + 1.96 * se) - scoreToElo(s - 1.96 * se)) / 2
    }
    /** LLR approximation (trinomial, normal) — mitovy amin'ny cutechess/fishtest */
    fun llr(w: Int, d: Int, l: Int, elo0: Double, elo1: Double): Double {
        val n = w + d + l
        if (n == 0) return 0.0
        val s = (w + 0.5 * d) / n
        val v = maxOf(variance(w, d, l), 1e-6)
        val s0 = eloToScore(elo0)
        val s1 = eloToScore(elo1)
        return (s1 - s0) * (2 * s - s0 - s1) / (2 * v / n)
    }
    fun llrBounds(alpha: Double, beta: Double) = Pair(ln(beta / (1 - alpha)), ln((1 - beta) / alpha))
}

class GameOut(val score: Double, val reason: String, val moves: List<String>) // score = fotsy POV

/**
 * Milalao 1 lalao eo anelanelan'ny moteur roa. onPos(board, moveUci, info, moverColor) miantso isaky ny hetsika.
 */
suspend fun playGame(
    w: UciEngine, b: UciEngine, startFen: String, tc: TC, adjudicate: Boolean = true,
    maxPlies: Int = 400,
    prefix: List<String> = emptyList(),   // hetsika voatondro (ohatra ny defense) alohan'ny hisafidianan'ny moteur
    onInfo: (Int, Info) -> Unit = { _, _ -> },
    onPos: (Board, String, Info?, Int) -> Unit = { _, _, _, _ -> }
): GameOut {
    val game = Game(startFen)
    for (u in prefix) { val pm = game.board.parseMove(u) ?: break; game.play(pm) }
    w.newGame(); b.newGame()
    var wt = tc.base; var bt = tc.base
    var run = 0   // adjudication : isa misesy +/-
    while (game.result == Res.ONGOING) {
        currentCoroutineContext().ensureActive()
        val color = game.board.stm
        val mover = if (color == 0) w else b
        val clock = if (color == 0) wt else bt
        val t0 = System.nanoTime()
        val r = mover.go(startFen, game.moves, tc.goArgs(wt, bt), tc.timeout(clock)) { onInfo(color, it) }
        val el = ((System.nanoTime() - t0) / 1_000_000L).toInt()
        val loss = if (color == 0) 0.0 else 1.0
        if (r.move == null) return GameOut(loss, "${if (color == 0) "blanc" else "noir"}: ${r.status}", game.moves)
        if (tc.clocked) {
            if (el > clock + 100) return GameOut(loss, "temps (${el}ms > ${clock}ms)", game.moves)
            if (color == 0) wt = wt - el + tc.inc else bt = bt - el + tc.inc
        }
        val m = game.board.parseMove(r.move) ?: return GameOut(loss, "coup illégal ${r.move}", game.moves)
        game.play(m)
        onPos(game.board, r.move, r.info, color)
        if (game.moves.size >= maxPlies && game.result == Res.ONGOING) game.end(Res.DRAW, "limite de coups")
        if (adjudicate && r.info != null && game.result == Res.ONGOING) {
            val cp = r.info.mate?.let { if (it > 0) 10000 else -10000 } ?: r.info.cp ?: 0
            val wcp = if (color == 0) cp else -cp
            run = if (wcp >= 1000 && run >= 0) run + 1 else if (wcp <= -1000 && run <= 0) run - 1 else 0
            if (run >= 8) game.end(Res.WHITE, "adjudication") else if (run <= -8) game.end(Res.BLACK, "adjudication")
        }
    }
    val sc = when (game.result) { Res.WHITE -> 1.0; Res.BLACK -> 0.0; else -> 0.5 }
    return GameOut(sc, game.text(), game.moves)
}
