package mg.joro.chess.match

import android.content.Context
import android.os.Build
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import mg.joro.chess.BuildConfig
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Tsy misy compiler ao amin'ny finday, ka ny source C++ dia alefa any amin'ny GitHub repo (engines_src/<id>/),
 * dia ny workflow `compile-engine.yml` no mamorona ny binaire (NDK) ary mamoaka Release `engine-<id>`.
 * Ny app dia miandry ary mampidina ny binaire mifanaraka amin'ny ABI-n'ny finday.
 */
object CloudBuild {
    private fun call(method: String, url: String, token: String, body: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000; c.readTimeout = 60000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        return Pair(code, txt)
    }

    private fun iso(s: String): Long {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.parse(s)?.time ?: 0L
    }

    suspend fun compile(ctx: Context, src: File, srcName: String, display: String, flags: String, status: (String) -> Unit): File =
        withContext(Dispatchers.IO) {
            val prefs = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
            val token = (prefs.getString("token", "") ?: "").trim()
            val repo = (prefs.getString("repo", BuildConfig.GITHUB_REPO) ?: BuildConfig.GITHUB_REPO).trim()
            if (token.isEmpty()) throw IllegalStateException("Mila token GitHub (Moteur > Compile cloud)")
            val api = "https://api.github.com/repos/$repo"
            val id = java.lang.Long.toString(System.currentTimeMillis(), 36)
            val abi = Build.SUPPORTED_ABIS.firstOrNull { it == "arm64-v8a" || it == "armeabi-v7a" || it == "x86_64" }
                ?: throw IllegalStateException("ABI tsy tohanana")

            status("Mijery ny repo $repo ...")
            val r0 = call("GET", api, token)
            if (r0.first != 200) throw IllegalStateException("Repo/token diso (HTTP ${r0.first})")
            val branch = JSONObject(r0.second).getString("default_branch")

            val l = srcName.lowercase(Locale.US)
            val fname = when {
                l.endsWith(".tgz") || l.endsWith(".tar.gz") -> "src.tgz"
                l.endsWith(".zip") -> "src.zip"
                l.endsWith(".tar") -> "src.tar"
                else -> srcName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            }
            status("Mandefa source (${src.length() / 1024} KB)...")
            val b64 = Base64.encodeToString(src.readBytes(), Base64.NO_WRAP)
            val up = call("PUT", "$api/contents/engines_src/$id/$fname", token,
                JSONObject().put("message", "engine source $id").put("content", b64).put("branch", branch).toString())
            if (up.first != 200 && up.first != 201) throw IllegalStateException("Upload diso HTTP ${up.first}: ${up.second.take(160)}")

            val startMs = System.currentTimeMillis() - 60_000
            status("Manomboka ny compile...")
            val inputs = JSONObject().put("id", id).put("name", display).put("flags", flags)
            val dp = call("POST", "$api/actions/workflows/compile-engine.yml/dispatches", token,
                JSONObject().put("ref", branch).put("inputs", inputs).toString())
            if (dp.first != 204) throw IllegalStateException("Dispatch diso HTTP ${dp.first}: ${dp.second.take(160)}")

            for (i in 1..120) {
                delay(10_000)
                status("Miandry ny compile... ${i * 10}s")
                val rel = call("GET", "$api/releases/tags/engine-$id", token)
                if (rel.first == 200) {
                    val assets = JSONObject(rel.second).optJSONArray("assets")
                    if (assets != null) for (k in 0 until assets.length()) {
                        val a = assets.getJSONObject(k)
                        if (a.getString("name") == "engine-$id-$abi") {
                            status("Mampidina binaire $abi ...")
                            val out = File(ctx.cacheDir, "cloud_$id")
                            val c = URL(a.getString("browser_download_url")).openConnection() as HttpURLConnection
                            c.connectTimeout = 20000; c.readTimeout = 60000
                            c.inputStream.use { ins -> out.outputStream().use { o -> ins.copyTo(o) } }
                            return@withContext out
                        }
                    }
                    throw IllegalStateException("Tsy nisy binaire $abi tao amin'ny Release (compile tsy nety ho an'ity ABI ity)")
                }
                val runs = call("GET", "$api/actions/workflows/compile-engine.yml/runs?per_page=3", token)
                if (runs.first == 200) {
                    val arr = JSONObject(runs.second).optJSONArray("workflow_runs")
                    if (arr != null) for (k in 0 until arr.length()) {
                        val r = arr.getJSONObject(k)
                        if (iso(r.optString("created_at")) >= startMs && r.optString("conclusion") == "failure")
                            throw IllegalStateException("Compile diso — jereo: ${r.optString("html_url")}")
                    }
                }
            }
            throw IllegalStateException("Fotoana lany (20 min). Jereo ny Actions ao amin'ny repo.")
        }
}
