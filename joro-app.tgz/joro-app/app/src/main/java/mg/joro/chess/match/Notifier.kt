package mg.joro.chess.match

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import mg.joro.chess.MainActivity

/** Notification rehefa vita ny fitsapana (SPRT H1/H0, SPSA, ...) */
object Notifier {
    fun notify(title: String, text: String) {
        try {
            val ctx = Host.ctx
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26)
                nm.createNotificationChannel(NotificationChannel("joro_done", "JORO valiny", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, "joro_done")
                .setContentTitle(title).setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify((System.currentTimeMillis() % 100000).toInt() + 100, n)
        } catch (_: Exception) {
        }
    }
}
