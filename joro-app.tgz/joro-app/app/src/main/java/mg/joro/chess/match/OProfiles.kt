package mg.joro.chess.match

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

/**
 * Profil isaky ny opening. `fen` = position fototra (ohatra aorian'ny 1.e4), `side` = 0 fotsy / 1 mainty / -1 roa.
 * `active` = lanja nekena (ampiasain'ny Blind default), `prov` = lanja provisoire (mbola SPRT / fanapahan-kevitra).
 * `seen` = anaran'ny lanja efa hita tamin'ny fampiofanana (ny vaovao dia asiana ★).
 */
data class OpProfile(
    val id: String, val name: String, val fen: String, val side: Int,
    val active: Map<String, Int> = emptyMap(), val prov: Map<String, Int>? = null,
    val seen: Set<String> = emptySet(), val sprt: String = "", val sprtOk: Boolean? = null,
    val games: Int = 0,
    val hist: List<OpHist> = emptyList(),     // version taloha (vaovao indrindra aloha) ho an'ny Rollback
    val calibProv: OpCalib? = null,           // calibrage (Elo vs Stockfish) an'ny lanja provisoire
    val calibActive: OpCalib? = null          // calibrage an'ny lanja nekena
)

/** Valin'ny calibrage opening: Elo tombanana (vs Stockfish UCI_Elo, lalao manomboka amin'ny opening) + soratra fanazavana */
data class OpCalib(val elo: Double, val text: String, val time: Long, val ofProv: Boolean)

/** Version taloha: `active` nosoloina tamin'ny `time`; `by` = valin'ny SPRT nanaiky ny vaovao */
data class OpHist(val time: Long, val active: Map<String, Int>, val by: String)

/** Lojika soratra madio (tsy miankina amin'ny Android) — azo andramana amin'ny unit test */
object OpText {
    /** FIAROVANA: Update moteur dia azo atao raha misy provisoire ary H1 ny SPRT (sprtOk == true) */
    fun canAccept(p: OpProfile): Boolean = p.prov != null && p.sprtOk == true

    fun sideWord(side: Int): String = when (side) { 0 -> "w"; 1 -> "b"; else -> "both" }

    /** Profil aorian'ny "Update moteur": ny provisoire lasa nekena, ary ny calibrage an'ny provisoire no lasa an'ny nekena. null raha tsy azo atao. */
    fun accepted(p: OpProfile, now: Long, maxHist: Int = 10): OpProfile? {
        if (!canAccept(p)) return null
        val pv = p.prov ?: return null
        val h = if (p.active.isNotEmpty()) (listOf(OpHist(now, p.active, p.sprt)) + p.hist).take(maxHist) else p.hist
        return p.copy(active = pv, prov = null, hist = h, calibActive = p.calibProv?.copy(ofProv = false), calibProv = null)
    }

    /** Calibrage tokony aseho: "Provisoire 2013 (Δ +12 vs nekena 2001) · ..." */
    fun calibLine(p: OpProfile): String {
        val a = p.calibActive; val v = p.calibProv
        val out = ArrayList<String>()
        if (v != null) {
            val d = if (a != null) " (Δ ${if (v.elo - a.elo >= 0) "+" else ""}${"%.0f".format(java.util.Locale.US, v.elo - a.elo)} vs nekena)" else ""
            out.add("Provisoire: ${v.text}$d")
        }
        if (a != null) out.add("Nekena: ${a.text}")
        return out.joinToString("\n")
    }

    /** Haavo Stockfish avy amin'ny soratra ("1500, 2000;2500"); foana na diso => default. Voafetra 1..12 haavo, 100..3600. */
    fun parseLevels(t: String, default: List<Int> = listOf(1500, 2000, 2500)): List<Int> {
        val l = t.split(',', ';', ' ').mapNotNull { it.trim().toIntOrNull() }.filter { it in 100..3600 }.distinct().sorted().take(12)
        return if (l.isEmpty()) default else l
    }

    /** Ampahany aorian'ny "oprof add <id>": `side w fen <FEN> set A 1 B 2` */
    fun args(p: OpProfile, ov: Map<String, Int>): String =
        "side ${sideWord(p.side)} fen ${p.fen} set " + ov.entries.joinToString(" ") { "${it.key} ${it.value}" }

    /** Andalana iray ho an'ny release: `oprof add <id> side w fen <FEN> set A 1 B 2 # name=<anarana>` */
    fun line(p: OpProfile, ov: Map<String, Int> = p.active): String =
        "oprof add ${p.id} ${args(p, ov)} # name=${p.name.replace('\n', ' ')}"

    fun parseLine(l: String): OpProfile? {
        val t = l.trim()
        if (t.isEmpty() || t.startsWith("#")) return null
        val k = t.indexOf(" # name=")
        val name = if (k >= 0) t.substring(k + 8).trim() else null
        val body = (if (k >= 0) t.substring(0, k) else t).trim()
        val m = Regex("^oprof add (\\S+) side (w|b|both) fen (.+?) set (.+)$").find(body) ?: return null
        val tok = m.groupValues[4].trim().split(Regex("\\s+"))
        if (tok.size % 2 != 0) return null
        val ov = LinkedHashMap<String, Int>()
        var i = 0
        while (i < tok.size) { ov[tok[i]] = tok[i + 1].toIntOrNull() ?: return null; i += 2 }
        val side = when (m.groupValues[2]) { "w" -> 0; "b" -> 1; else -> -1 }
        return OpProfile(m.groupValues[1], if (name.isNullOrEmpty()) m.groupValues[1] else name, m.groupValues[3].trim(), side, active = ov)
    }

    /** Fiovana: "A 5→3, B 2→9" (\"-\" = tsy misy) */
    fun diff(from: Map<String, Int>, to: Map<String, Int>): String {
        val out = ArrayList<String>()
        for (k in LinkedHashSet<String>().also { it.addAll(from.keys); it.addAll(to.keys) }) {
            val a = from[k]; val b = to[k]
            if (a != b) out.add("$k ${a ?: "-"}→${b ?: "-"}")
        }
        return if (out.isEmpty()) "mitovy" else out.joinToString(", ")
    }
}

object OProfiles {
    val list = mutableStateListOf<OpProfile>()
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("oprofiles", Context.MODE_PRIVATE)
        prefs = p
        list.clear()
        val arr = try { JSONArray(p.getString("list", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            try { list.add(fromJson(arr.getJSONObject(i))) } catch (_: Exception) { }
        }
        // Profil release (assets/default_oprofiles.txt): ampiana raha tsy mbola ao sady tsy nofafan'ny mpampiasa
        val txt = try { ctx.assets.open("default_oprofiles.txt").bufferedReader().readText() } catch (_: Exception) { "" }
        val removed = p.getStringSet("removed", emptySet()) ?: emptySet()
        var added = false
        for (l in txt.lines()) {
            val op = OpText.parseLine(l) ?: continue
            if (get(op.id) == null && op.id !in removed) { list.add(op); added = true }
        }
        if (added) save()
    }

    fun get(id: String): OpProfile? = list.firstOrNull { it.id == id }

    private fun markRemoved(id: String, on: Boolean) {
        val cur = prefs?.getStringSet("removed", emptySet())?.toMutableSet() ?: return
        if (if (on) cur.add(id) else cur.remove(id)) prefs?.edit()?.putStringSet("removed", cur)?.apply()
    }

    fun put(p: OpProfile) {
        val i = list.indexOfFirst { it.id == p.id }
        if (i >= 0) list[i] = p else list.add(p)
        markRemoved(p.id, false)
        save()
    }

    fun remove(id: String) {
        list.removeAll { it.id == id }
        markRemoved(id, true)          // tsy hiverina avy amin'ny default_oprofiles.txt
        save()
    }

    const val MAX_HIST = 10

    /** Azo atao ve ny Update moteur? Ny SPRT ihany no mamaly: mila H1 (sprtOk == true) amin'ny provisoire ankehitriny. */
    fun canAccept(p: OpProfile): Boolean = OpText.canAccept(p)

    /** Update moteur: ny lanja provisoire no lasa lanja nekena; voatahiry ny version taloha (Rollback).
     *  FIAROVANA: tsy atao raha tsy H1 ny SPRT (mamerina false). */
    fun accept(id: String): Boolean {
        val p = get(id) ?: return false
        if (!canAccept(p)) return false
        if (p.prov == null) return false
        val np = OpText.accepted(p, System.currentTimeMillis(), MAX_HIST) ?: return false
        put(np)
        return true
    }

    /** Rollback: averina ny version `index` ao amin'ny tantara; ny version ankehitriny dia voatahiry koa (azo averina indray) */
    fun rollback(id: String, index: Int) {
        val p = get(id) ?: return
        val target = p.hist.getOrNull(index) ?: return
        val rest = p.hist.filterIndexed { i, _ -> i != index }
        val cur = if (p.active.isNotEmpty()) listOf(OpHist(System.currentTimeMillis(), p.active, "rollback")) else emptyList()
        // ny SPRT teo aloha dia nampitahaina tamin'ny version teo: foana izao
        put(p.copy(active = target.active, sprt = "", sprtOk = null, hist = (cur + rest).take(MAX_HIST), calibActive = null))
    }

    /** Release: andalana `oprof add ...` ho an'ny profil rehetra manana lanja nekena (apetaka ao amin'ny assets/default_oprofiles.txt) */
    fun exportRelease(): String =
        "# Blind profil isaky ny opening (nekena). Apetaho ao amin'ny app/src/main/assets/default_oprofiles.txt\n" +
        list.filter { it.active.isNotEmpty() }.joinToString("\n") { OpText.line(it) } + "\n"

    /** Delete experience: foanana ny provisoire; raha tsy misy lanja nekena dia foanana ny profil */
    fun discard(id: String) {
        val p = get(id) ?: return
        if (p.active.isEmpty()) remove(id) else put(p.copy(prov = null, sprt = "", sprtOk = null, calibProv = null))
    }

    /** Tahiry ny calibrage (provisoire na nekena araka ny `c.ofProv`) */
    fun setCalib(id: String, c: OpCalib) {
        val p = get(id) ?: return
        put(if (c.ofProv) p.copy(calibProv = c) else p.copy(calibActive = c))
    }

    fun idOf(name: String, side: Int): String {
        val s = name.replace(Regex("[^A-Za-z0-9_-]"), "_").trim('_')
        return (if (s.isEmpty()) "op" else s.take(24)) + "_" + sideWord(side)
    }

    fun sideWord(side: Int): String = OpText.sideWord(side)

    /** Ampahany aorian'ny "oprof add <id>" */
    fun args(p: OpProfile, ov: Map<String, Int>): String = OpText.args(p, ov)

    /** Options "oprof:<id>" ho an'ny EngineSpec (Player.setAll no mamadika azy ho baiko oprof) */
    fun engineOptions(): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (p in list) if (p.active.isNotEmpty()) m["oprof:" + p.id] = args(p, p.active)
        return m
    }

    private fun mapJson(m: Map<String, Int>): JSONObject {
        val j = JSONObject()
        for ((k, v) in m) j.put(k, v)
        return j
    }

    private fun jsonMap(j: JSONObject?): Map<String, Int> {
        val m = LinkedHashMap<String, Int>()
        if (j != null) for (k in j.keys()) m[k] = j.getInt(k)
        return m
    }

    private fun toJson(p: OpProfile): JSONObject {
        val j = JSONObject().put("id", p.id).put("name", p.name).put("fen", p.fen).put("side", p.side)
            .put("active", mapJson(p.active)).put("seen", JSONArray(p.seen.toList()))
            .put("sprt", p.sprt).put("games", p.games)
        if (p.prov != null) j.put("prov", mapJson(p.prov))
        if (p.sprtOk != null) j.put("ok", p.sprtOk)
        j.put("hist", JSONArray(p.hist.map { JSONObject().put("t", it.time).put("a", mapJson(it.active)).put("by", it.by) }))
        p.calibProv?.let { j.put("cprov", calibJson(it)) }
        p.calibActive?.let { j.put("cact", calibJson(it)) }
        return j
    }

    private fun calibJson(c: OpCalib) = JSONObject().put("elo", c.elo).put("txt", c.text).put("t", c.time).put("p", c.ofProv)
    private fun jsonCalib(j: JSONObject?): OpCalib? =
        if (j == null) null else OpCalib(j.optDouble("elo", 0.0), j.optString("txt", ""), j.optLong("t"), j.optBoolean("p"))

    private fun fromJson(j: JSONObject): OpProfile {
        val sn = LinkedHashSet<String>()
        val sa = j.optJSONArray("seen")
        if (sa != null) for (i in 0 until sa.length()) sn.add(sa.getString(i))
        return OpProfile(
            j.getString("id"), j.getString("name"), j.getString("fen"), j.getInt("side"),
            jsonMap(j.optJSONObject("active")), if (j.has("prov")) jsonMap(j.optJSONObject("prov")) else null,
            sn, j.optString("sprt", ""), if (j.has("ok")) j.getBoolean("ok") else null, j.optInt("games", 0),
            hist = (j.optJSONArray("hist")?.let { a -> (0 until a.length()).map { i -> a.getJSONObject(i) } } ?: emptyList())
                .map { h -> OpHist(h.optLong("t"), jsonMap(h.optJSONObject("a")), h.optString("by", "")) },
            calibProv = jsonCalib(j.optJSONObject("cprov")), calibActive = jsonCalib(j.optJSONObject("cact"))
        )
    }

    private fun save() {
        val arr = JSONArray()
        for (p in list) arr.put(toJson(p))
        prefs?.edit()?.putString("list", arr.toString())?.apply()
    }
}
