package mg.joro.chess.uci

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class EngineEntry(val id: String, val name: String, val path: String, val builtin: Boolean)

sealed class ImportOutcome
class Installed(val entry: EngineEntry) : ImportOutcome()
/** Source (.cpp na archive misy source) : tsy azo compile-na ao amin'ny finday -> compile cloud (GitHub Actions) */
class NeedsCompile(val file: File, val name: String) : ImportOutcome()

class EngineStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("engines", Context.MODE_PRIVATE)
    private val dir = File(ctx.filesDir, "engines").also { it.mkdirs() }

    fun list(): List<EngineEntry> {
        val out = ArrayList<EngineEntry>()
        // libblind.so = moteur Blind; libjoro.so = anarana taloha (mbola ekena raha tsy mbola nohavaozina ny workflow build)
        val bi = listOf("libblind.so", "libjoro.so").map { File(ctx.applicationInfo.nativeLibraryDir, it) }.firstOrNull { it.exists() }
        if (bi != null) out.add(EngineEntry("builtin", "Blind (integré)", bi.absolutePath, true))
        val sf = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (sf.exists()) out.add(EngineEntry("stockfish", "Stockfish (integré)", sf.absolutePath, true))
        val arr = JSONArray(prefs.getString("list", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (File(o.getString("path")).exists())
                out.add(EngineEntry(o.getString("id"), o.getString("name"), o.getString("path"), false))
        }
        return out
    }

    private fun save(l: List<EngineEntry>) {
        val arr = JSONArray()
        l.filter { !it.builtin }.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("path", it.path))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun delete(e: EngineEntry) {
        if (e.builtin) return
        File(e.path).parentFile?.deleteRecursively()
        save(list().filter { it.id != e.id })
    }

    private fun displayName(uri: Uri): String {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return "engine"
    }

    /** Import: ELF, archive (.zip/.tgz/.tar) misy ELF  ->  Installed ; .cpp na archive misy source -> NeedsCompile */
    suspend fun import(uri: Uri): ImportOutcome = withContext(Dispatchers.IO) {
        val fname = displayName(uri)
        val tmp = File(ctx.cacheDir, "import_" + System.currentTimeMillis()).apply { mkdirs() }
        val src = File(tmp, fname.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        (ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("tsy azo vakiana")).use { i ->
            src.outputStream().use { o -> i.copyTo(o) }
        }
        val kind = Pack.kind(src)
        val bin = File(tmp, "engine.bin")
        when {
            kind == "elf" || (kind != "text" && Pack.extractElf(src, bin)) -> {
                if (kind == "elf") src.copyTo(bin, true)
                val e = installBinary(bin, fname.substringBeforeLast('.', fname))
                tmp.deleteRecursively()
                Installed(e)
            }
            kind == "text" && Pack.looksLikeCpp(src, fname) -> NeedsCompile(src, fname)
            kind != "text" && Pack.hasSource(src) -> NeedsCompile(src, fname)
            else -> { tmp.deleteRecursively(); throw IllegalStateException("Tsy ELF, tsy source C++ (.cpp), ary tsy archive misy ireo") }
        }
    }

    /** Mametraka binaire ELF ho moteur (manamarina UCI) */
    suspend fun installBinary(file: File, fname: String): EngineEntry = withContext(Dispatchers.IO) {
        val id = System.currentTimeMillis().toString()
        val d = File(dir, id).apply { mkdirs() }
        val out = File(d, "engine")
        try {
            file.copyTo(out, true)
            out.setExecutable(true, false)
            val eng = UciEngine(out.absolutePath)
            val nm = try {
                eng.start()
                eng.name.ifBlank { fname }
            } finally {
                eng.close()
            }
            val e = EngineEntry(id, nm, out.absolutePath, false)
            save(list() + e)
            e
        } catch (ex: Exception) {
            d.deleteRecursively()
            throw ex
        }
    }

    /** Export binaire ELF ho .zip na .tgz */
    suspend fun export(e: EngineEntry, fmt: String, uri: Uri) = withContext(Dispatchers.IO) {
        val entry = Pack.safeName(e.name)
        (ctx.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("tsy azo soratana")).use { o ->
            if (fmt == "zip") Pack.writeZip(File(e.path), entry, o) else Pack.writeTgz(File(e.path), entry, o)
        }
    }
}

/** Fitaovana ho an'ny fichier: ELF / .zip / .tgz / .tar / source */
object Pack {
    private const val MIN_ELF = 4096L

    fun safeName(n: String) = n.substringBefore(" (").replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifEmpty { "engine" }

    private fun isElf(h: ByteArray) = h.size >= 4 && h[0] == 0x7F.toByte() && h[1] == 'E'.code.toByte() &&
        h[2] == 'L'.code.toByte() && h[3] == 'F'.code.toByte()

    /** elf | gz | zip | tar | text | other */
    fun kind(f: File): String {
        val h = ByteArray(512)
        val n = f.inputStream().use { it.read(h) }
        if (n < 4) return "other"
        val head = h.copyOf(4)
        return when {
            isElf(head) -> "elf"
            h[0] == 0x1f.toByte() && h[1] == 0x8b.toByte() -> "gz"
            h[0] == 'P'.code.toByte() && h[1] == 'K'.code.toByte() -> "zip"
            n >= 262 && String(h, 257, 5, Charsets.US_ASCII) == "ustar" -> "tar"
            (0 until n).none { h[it] == 0.toByte() } -> "text"
            else -> "other"
        }
    }

    fun looksLikeCpp(f: File, name: String): Boolean {
        val l = name.lowercase(Locale.US)
        if (l.endsWith(".cpp") || l.endsWith(".cc") || l.endsWith(".cxx") || l.endsWith(".c++")) return true
        return f.readText().take(20000).contains("#include")
    }

    private fun open(f: File, kind: String): InputStream {
        val b = BufferedInputStream(f.inputStream(), 1 shl 16)
        return if (kind == "gz") GZIPInputStream(b) else b
    }

    fun extractElf(f: File, out: File): Boolean = when (val k = kind(f)) {
        "elf" -> { f.copyTo(out, true); true }
        "gz", "tar" -> open(f, k).use { tar(it, out, null) }
        "zip" -> open(f, k).use { zip(it, out, null) }
        else -> false
    }

    fun hasSource(f: File): Boolean {
        val names = ArrayList<String>()
        val k = kind(f)
        try {
            if (k == "gz" || k == "tar") open(f, k).use { tar(it, null, names) }
            else if (k == "zip") open(f, k).use { zip(it, null, names) }
        } catch (_: Exception) {
        }
        return names.any { n -> val l = n.lowercase(Locale.US); l.endsWith(".cpp") || l.endsWith(".cc") || l.endsWith(".cxx") || l.endsWith(".c++") }
    }

    private fun zip(s: InputStream, out: File?, names: MutableList<String>?): Boolean {
        val z = ZipInputStream(s)
        while (true) {
            val e = z.nextEntry ?: return false
            if (e.isDirectory) continue
            names?.add(e.name)
            if (out == null) continue
            val bin = java.io.ByteArrayOutputStream()
            z.copyTo(bin)
            val b = bin.toByteArray()
            if (b.size > MIN_ELF && isElf(b.copyOf(4))) { out.writeBytes(b); return true }
        }
    }

    private fun readFully(s: InputStream, buf: ByteArray): Boolean {
        var n = 0
        while (n < buf.size) {
            val r = s.read(buf, n, buf.size - n)
            if (r < 0) return false
            n += r
        }
        return true
    }

    private fun skipN(s: InputStream, n: Long) {
        var left = n
        val tmp = ByteArray(8192)
        while (left > 0) {
            val r = s.read(tmp, 0, minOf(left, tmp.size.toLong()).toInt())
            if (r < 0) return
            left -= r
        }
    }

    private fun tar(s: InputStream, out: File?, names: MutableList<String>?): Boolean {
        val hdr = ByteArray(512)
        while (readFully(s, hdr)) {
            if (hdr.all { it == 0.toByte() }) break
            names?.add(String(hdr, 0, 100, Charsets.US_ASCII).trim('\u0000', ' '))
            val size = String(hdr, 124, 12, Charsets.US_ASCII).trim('\u0000', ' ').ifEmpty { "0" }.toLongOrNull(8) ?: return false
            val type = hdr[156].toInt().toChar()
            val pad = (512 - size % 512) % 512
            if (out != null && (type == '0' || type == '\u0000') && size > MIN_ELF) {
                val first = ByteArray(4)
                if (!readFully(s, first)) return false
                if (isElf(first)) {
                    out.outputStream().use { o ->
                        o.write(first)
                        var left = size - 4
                        val tmp = ByteArray(65536)
                        while (left > 0) {
                            val r = s.read(tmp, 0, minOf(left, tmp.size.toLong()).toInt())
                            if (r < 0) break
                            o.write(tmp, 0, r)
                            left -= r
                        }
                    }
                    return true
                }
                skipN(s, size - 4 + pad)
            } else skipN(s, size + pad)
        }
        return false
    }

    // ---------- export ----------
    fun writeZip(bin: File, entry: String, out: OutputStream) {
        ZipOutputStream(out).use { z ->
            z.putNextEntry(ZipEntry(entry))
            bin.inputStream().use { it.copyTo(z) }
            z.closeEntry()
        }
    }

    fun writeTgz(bin: File, entry: String, out: OutputStream) {
        GZIPOutputStream(out).use { gz ->
            val h = ByteArray(512)
            fun put(off: Int, s: String) { s.toByteArray(Charsets.US_ASCII).copyInto(h, off) }
            put(0, entry)
            put(100, "0000755\u0000"); put(108, "0000000\u0000"); put(116, "0000000\u0000")
            put(124, String.format(Locale.US, "%011o", bin.length()) + "\u0000")
            put(136, String.format(Locale.US, "%011o", System.currentTimeMillis() / 1000) + "\u0000")
            for (i in 148 until 156) h[i] = ' '.code.toByte()
            h[156] = '0'.code.toByte()
            put(257, "ustar\u0000"); put(263, "00")
            var sum = 0
            for (b in h) sum += b.toInt() and 0xff
            put(148, String.format(Locale.US, "%06o", sum) + "\u0000 ")
            gz.write(h)
            bin.inputStream().use { it.copyTo(gz) }
            gz.write(ByteArray(((512 - bin.length() % 512) % 512).toInt()))
            gz.write(ByteArray(1024))
        }
    }
}
