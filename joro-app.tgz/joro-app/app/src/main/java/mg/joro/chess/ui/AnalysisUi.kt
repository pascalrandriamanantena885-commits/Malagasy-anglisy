package mg.joro.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.widget.Toast
import mg.joro.chess.chess.Board
import mg.joro.chess.match.*
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun AnalysisScreen() {
    val r = Analysis.review
    Column(Modifier.padding(10.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (Analysis.running) {
            Text("Mandinika (Stockfish)... ${Analysis.done}/${Analysis.total}")
            LinearProgressIndicator(progress = { if (Analysis.total == 0) 0f else Analysis.done.toFloat() / Analysis.total }, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { Analysis.cancel() }) { Text("Atsaharo") }
        }
        if (Analysis.error.isNotEmpty()) Text(Analysis.error, color = MaterialTheme.colorScheme.error)
        if (r != null && !Analysis.running) {
            if (Analysis.retryMode) RetryView(r)
            else {
                OutlinedButton(onClick = { Analysis.review = null }) { Text("◀ Lisitry ny lalao") }
                ReviewView(r)
            }
        } else {
            GamesList()
            CalibCard()
            Field("ms isaky ny toerana (Stockfish)", Analysis.msText, true)
        }
    }
}

/** Lalao rehetra voatahiry (Milalao + Live), miaraka amin'ny review raha efa vita */
@Composable
private fun GamesList() {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    if (ReviewStore.games.isEmpty())
        Text("Mbola tsy misy lalao voatahiry. Rehefa vita ny lalao (Milalao na Live) dia hiseho eto, ary azo tsindrina ny “Review”.")
    ReviewStore.games.forEach { g ->
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("${g.source} · ${History.date(g.time)}", style = MaterialTheme.typography.titleSmall)
                Text("⚪ ${g.white}  vs  ⚫ ${g.black}", fontSize = 12.sp, maxLines = 1)
                Text("${g.resultText} · ${g.moves.size} hetsika", fontSize = 11.sp)
                if (g.reviewed)
                    Text("Accuracy ⚪ ${f1(g.accW)}% · ⚫ ${f1(g.accB)}%   Rating ⚪ ${g.ratW} · ⚫ ${g.ratB}", fontSize = 11.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(enabled = !Analysis.running, onClick = { Analysis.openSaved(g) }) {
                        Text(if (g.reviewed) "📊 Jereo review" else "📊 Review")
                    }
                    OutlinedButton(onClick = {
                        clip.setText(AnnotatedString(Pgn.build(g.startFen, g.moves, g.white, g.black, g.res, "")))
                        Toast.makeText(ctx, "PGN voakopia", Toast.LENGTH_SHORT).show()
                    }) { Text("PGN") }
                    OutlinedButton(onClick = { ReviewStore.remove(g.id) }) { Text("Fafao") }
                }
            }
        }
    }
    if (ReviewStore.games.isNotEmpty()) OutlinedButton(onClick = { ReviewStore.clear() }) { Text("Fafao rehetra") }
}

private fun markFor(c: MC) = c.pgn

private val BAD = setOf(MC.INACCURACY, MC.MISTAKE, MC.MISS, MC.BLUNDER)

private fun evText(cp: Int): String {
    val a = abs(cp)
    if (a >= Rv.MATE - 2000) {
        val m = (Rv.MATE - a) / 10
        return (if (cp < 0) "-" else "") + (if (m == 0) "#" else "M$m")
    }
    return String.format(Locale.US, "%+.1f", cp / 100.0)
}

/** Boribory misy famantarana (toa ny icône chess.com) */
@Composable
private fun ClsIcon(c: MC, size: Int = 22) {
    Box(Modifier.size(size.dp).background(Color(c.color), CircleShape), contentAlignment = Alignment.Center) {
        Text(c.sym, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size * 0.45f).sp, maxLines = 1)
    }
}

@Composable
private fun RatingPill(value: Int, light: Boolean, modifier: Modifier) {
    Box(
        modifier.background(if (light) Color(0xFFF2F2F2) else Color(0xFF3A3936), RoundedCornerShape(8.dp)).padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(if (value > 0) "$value" else "—", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp,
            color = if (light) Color(0xFF262421) else Color.White)
    }
}

/** Card famintinana: Accuracy + Game Rating + isan'ny sokajy, toa ny chess.com "Game Review" */
@Composable
private fun SummaryCard(r: Review) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Game Review", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (r.opening.isNotEmpty()) Text("📖 ${r.opening}", fontSize = 12.sp, color = Color(MC.BOOK.color))
            Row(Modifier.fillMaxWidth()) {
                Text("⚪ ${r.white}", Modifier.weight(1f), fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center)
                Spacer(Modifier.weight(1f))
                Text("⚫ ${r.black}", Modifier.weight(1f), fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(f1(r.acc[0]), Modifier.weight(1f), fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text("Accuracy", Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.Center)
                Text(f1(r.acc[1]), Modifier.weight(1f), fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                RatingPill(r.rating[0], true, Modifier.weight(1f))
                Text("Game Rating", Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.Center)
                RatingPill(r.rating[1], false, Modifier.weight(1f))
            }
            MC.values().forEach { c ->
                val a = r.counts[0][c] ?: 0; val b = r.counts[1][c] ?: 0
                if ((c == MC.BOOK || c == MC.FORCED) && a + b == 0) return@forEach
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("$a", Modifier.weight(1f), color = Color(c.color), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Row(Modifier.weight(1.6f), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically) {
                        ClsIcon(c, 20)
                        Text(c.label, fontSize = 13.sp)
                    }
                    Text("$b", Modifier.weight(1f), color = Color(c.color), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

/** Eval bar: fotsy = tombony ho an'ny Fotsy */
@Composable
private fun EvalBar(cp: Int, win: Double) {
    Box(Modifier.fillMaxWidth().height(20.dp)) {
        Canvas(Modifier.matchParentSize()) {
            drawRect(Color(0xFF2B2B2B))
            drawRect(Color(0xFFF2F2F2), Offset(0f, 0f), androidx.compose.ui.geometry.Size(size.width * win.toFloat().coerceIn(0f, 1f), size.height))
        }
        Text(evText(cp), Modifier.align(if (win >= 0.5) Alignment.CenterStart else Alignment.CenterEnd).padding(horizontal = 6.dp),
            fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (win >= 0.5) Color.Black else Color.White)
    }
}

@Composable
private fun ReviewView(r: Review) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    var showBest by remember { mutableStateOf(true) }
    val n = r.moves.size
    val ply = Analysis.viewPly.coerceIn(0, n)
    val mv = if (ply > 0) r.moves[ply - 1] else null
    Text("${r.white} vs ${r.black} — ${r.result}", style = MaterialTheme.typography.titleSmall)
    Text("Moteur: ${r.engine}", fontSize = 10.sp)

    SummaryCard(r)

    // ---- board + eval bar ----
    if (r.cpW.size > ply) EvalBar(r.cpW[ply], r.curve[ply])
    BoardView(
        r.boards[ply], Analysis.flip, -1, emptySet(), if (ply > 0) r.uciMoves[ply - 1] else null, onTap = {},
        badge = mv?.let { it.cls.sym to it.cls.color },
        arrow = if (showBest && mv != null && mv.cls in BAD) mv.bestUci else null
    )
    if (mv != null) {
        val bb = r.boards[ply - 1]
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ClsIcon(mv.cls, 24)
            Text("${bb.full}${if (bb.stm == 0) "." else "..."} ${mv.san} dia ${mv.cls.label}",
                color = Color(mv.cls.color), fontWeight = FontWeight.Bold)
        }
        if (mv.opening.isNotEmpty()) Text("📖 ${mv.opening}", fontSize = 12.sp, color = Color(MC.BOOK.color))
        if (mv.bestLine.isNotEmpty()) Text("Andalana (moteur): ${mv.bestLine}", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        if (mv.bestSan != null) Text("Tsara kokoa: ${mv.bestSan}   (very ${f1(mv.loss * 100)}% amin'ny sandan'ny fandresena)", fontSize = 12.sp)
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { Analysis.viewPly = 0 }) { Text("⏮") }
        OutlinedButton(onClick = { Analysis.viewPly = maxOf(0, ply - 1) }) { Text("◀") }
        OutlinedButton(onClick = { Analysis.viewPly = minOf(n, ply + 1) }) { Text("▶") }
        OutlinedButton(onClick = { Analysis.viewPly = n }) { Text("⏭") }
        OutlinedButton(onClick = { Analysis.flip = !Analysis.flip }) { Text("⇅ Vadiho") }
        OutlinedButton(onClick = { Analysis.retryMode = true }) { Text("🎯 Retry") }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Switch(checked = showBest, onCheckedChange = { showBest = it })
        Text("Asehoy ny hetsika tsara kokoa (anamanana)", fontSize = 12.sp)
    }

    // ---- courbe d'évaluation (fandresena % an'ny fotsy) ----
    val curve = r.curve
    Canvas(Modifier.fillMaxWidth().height(90.dp).pointerInput(curve.size) {
        detectTapGestures { o ->
            if (curve.size > 1) Analysis.viewPly = ((o.x / size.width) * (curve.size - 1)).roundToInt().coerceIn(0, curve.size - 1)
        }
    }) {
        drawRect(Color(0xFF2B2B2B))
        if (curve.size > 1) {
            val w = size.width; val h = size.height
            fun x(i: Int) = w * i / (curve.size - 1)
            fun y(i: Int) = h * (1f - curve[i].toFloat())
            val fill = Path()
            fill.moveTo(0f, h)
            for (i in curve.indices) fill.lineTo(x(i), y(i))
            fill.lineTo(w, h); fill.close()
            drawPath(fill, Color(0xCCFFFFFF))
            drawLine(Color(0xFF888888), Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 1f)
            r.moves.forEachIndexed { i, mm ->
                if (mm.cls == MC.BLUNDER || mm.cls == MC.MISTAKE || mm.cls == MC.MISS || mm.cls == MC.BRILLIANT || mm.cls == MC.GREAT)
                    drawCircle(Color(mm.cls.color), 5f, Offset(x(i + 1), y(i + 1)))
            }
            drawLine(Color(0xFFFFCA28), Offset(x(ply), 0f), Offset(x(ply), h), strokeWidth = 3f)
        }
    }

    // ---- lisitry ny hetsika ----
    Text("Hetsika", style = MaterialTheme.typography.titleSmall)
    r.moves.chunked(2).forEachIndexed { i, pair ->
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("${i + 1}.", Modifier.width(30.dp), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            pair.forEachIndexed { k, m2 ->
                val p = i * 2 + k + 1
                Text(m2.san + " " + m2.cls.sym, Modifier.clickable { Analysis.viewPly = p }.padding(2.dp),
                    color = Color(m2.cls.color), fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                    fontWeight = if (p == ply) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = {
            val marks = r.moves.map { markFor(it.cls) }
            clip.setText(AnnotatedString(Pgn.build(r.startFen, r.uciMoves, r.white, r.black, r.res, "", marks)))
            Toast.makeText(ctx, "PGN annoté voakopia", Toast.LENGTH_SHORT).show()
        }) { Text("Copier PGN annoté") }
    }
}

/** "Retry": hitady ny hetsika tsara kokoa amin'ny toerana nisy ny hadisoana */
@Composable
private fun RetryView(r: Review) {
    var side by remember { mutableIntStateOf(2) }
    val targets = remember(r, side) { Retry.targets(r, side) }
    var idx by remember(r, side) { mutableIntStateOf(0) }
    var sel by remember(r, side) { mutableIntStateOf(-1) }
    var msg by remember(r, side) { mutableStateOf("") }
    var solved by remember(r, side) { mutableStateOf(false) }
    var reveal by remember(r, side) { mutableStateOf(false) }
    var score by remember(r, side) { mutableIntStateOf(0) }

    OutlinedButton(onClick = { Analysis.retryMode = false }) { Text("◀ Review") }
    Text("🎯 Retry — hitady ny hetsika tsara kokoa", style = MaterialTheme.typography.titleSmall)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = side == 2, onClick = { side = 2 }, label = { Text("Roa") })
        FilterChip(selected = side == 0, onClick = { side = 0 }, label = { Text("Fotsy") })
        FilterChip(selected = side == 1, onClick = { side = 1 }, label = { Text("Mainty") })
    }
    if (targets.isEmpty()) {
        Text("Tsy misy hadisoana azo averina amin'ity sisiny ity 👏")
        return
    }
    val pos = idx.coerceIn(0, targets.size - 1)
    val i = targets[pos]
    val mv = r.moves[i]
    val board = r.boards[i]
    Text("Hadisoana ${pos + 1}/${targets.size} · ${if (board.stm == 0) "⚪ Fotsy" else "⚫ Mainty"} no mandeha · vita: $score", fontSize = 12.sp)
    val legal = board.legalMoves()
    val dots = if (sel >= 0) legal.filter { Board.from(it) == sel }.map { Board.to(it) }.toSet() else emptySet()
    BoardView(
        board, board.stm == 1, sel, dots, if (i > 0) r.uciMoves[i - 1] else null,
        onTap = { s ->
            if (!solved && !reveal) {
                val cand = if (sel >= 0) legal.filter { Board.from(it) == sel && Board.to(it) == s } else emptyList()
                if (cand.isNotEmpty()) {
                    val m = cand.firstOrNull { Board.promo(it) == 4 } ?: cand[0]
                    val v = Retry.judge(mv, board.uci(m))
                    sel = -1
                    if (v == Retry.Verdict.BEST) { solved = true; score += 1; msg = "✅ Marina! ${board.san(m)} no hetsika tsara indrindra." }
                    else if (v == Retry.Verdict.PLAYED) msg = "❌ Io ihany no hetsika nilalaoana (${mv.cls.label}). Andramo indray."
                    else msg = "❌ ${board.san(m)} tsy no tsara indrindra. Andramo indray."
                } else if (board.sq[s] != 0 && (board.sq[s] shr 3) == board.stm) sel = s
                else sel = -1
            }
        },
        arrow = if (reveal) mv.bestUci else null
    )
    if (msg.isNotEmpty()) Text(msg, fontWeight = FontWeight.Bold)
    if (solved || reveal) {
        Text("Hetsika tsara kokoa: ${mv.bestSan ?: ""}", fontWeight = FontWeight.Bold)
        if (mv.bestLine.isNotEmpty()) Text("Andalana: ${mv.bestLine}", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text("Ny nilalaoana: ${mv.san} (${mv.cls.label})", fontSize = 12.sp, color = Color(mv.cls.color))
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!solved && !reveal) OutlinedButton(onClick = { reveal = true; msg = "" }) { Text("💡 Asehoy ny valiny") }
        OutlinedButton(enabled = pos > 0, onClick = { idx = pos - 1; sel = -1; msg = ""; solved = false; reveal = false }) { Text("◀") }
        Button(enabled = pos < targets.size - 1, onClick = { idx = pos + 1; sel = -1; msg = ""; solved = false; reveal = false }) { Text("Manaraka ▶") }
    }
}

/** Calibrage ny Game Rating (ACPL -> Elo) */
@Composable
private fun CalibCard() {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Calibrage Game Rating", style = MaterialTheme.typography.titleSmall)
            Text(RatingCalib.describe(), fontSize = 11.sp)
            Text("Stockfish (UCI_Elo 1400…3000) milalao samy irery, dinihina amin'ny ms etsy ambany, ary ny ACPL ↔ Elo no mamolavola ny curve. Ny Elo dia ny an'ny Stockfish, tsy mitovy tanteraka amin'ny chess.com. Maharitra minitra maromaro.", fontSize = 10.sp)
            if (RatingCalib.status.isNotEmpty()) Text(RatingCalib.status, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !Host.running.value && !Analysis.running, onClick = { Analysis.startCalibration() }) { Text("Manomboka calibrage") }
                OutlinedButton(onClick = { RatingCalib.reset() }) { Text("Default") }
            }
        }
    }
}
