package mg.joro.chess.match

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HistEntry(
    val id: String, val time: Long, val type: String, val subject: String, val tc: String,
    val headline: String, val table: String
)

/** Tantaran'ny fitsapana vita (daty, TC, moteur, valiny) */
object History {
    val list = mutableStateListOf<HistEntry>()
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)
        list.clear()
        val arr = try { JSONArray(prefs?.getString("list", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(HistEntry(o.getString("id"), o.getLong("time"), o.getString("type"), o.getString("subject"),
                o.getString("tc"), o.getString("headline"), o.getString("table")))
        }
    }

    fun add(e: HistEntry) {
        list.add(0, e)
        while (list.size > 100) list.removeAt(list.size - 1)
        save()
    }

    fun remove(id: String) { list.removeAll { it.id == id }; save() }
    fun clear() { list.clear(); save() }

    fun date(t: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(t))

    fun text(e: HistEntry): String =
        "JORO Chess · ${e.type} · ${date(e.time)} · ${e.tc}\n${e.subject}\n\n${e.headline}\n\n${e.table}"

    private fun save() {
        val arr = JSONArray()
        for (e in list) arr.put(JSONObject().put("id", e.id).put("time", e.time).put("type", e.type)
            .put("subject", e.subject).put("tc", e.tc).put("headline", e.headline).put("table", e.table))
        prefs?.edit()?.putString("list", arr.toString())?.apply()
    }
}
