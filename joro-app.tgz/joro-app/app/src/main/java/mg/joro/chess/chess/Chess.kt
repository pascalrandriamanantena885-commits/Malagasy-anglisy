package mg.joro.chess.chess

import kotlin.math.abs

private val KN = arrayOf(intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
    intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1))
private val DIAG = arrayOf(intArrayOf(1, 1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(-1, -1))
private val ORTH = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))

private fun cmask(s: Int): Int = when (s) {
    4 -> 12; 7 -> 14; 0 -> 13; 60 -> 3; 63 -> 11; 56 -> 7; else -> 15
}

/** piece = type (1..6 = P N B R Q K) | (color shl 3), color 0 = fotsy, 1 = mainty. sq = rank*8+file (a1 = 0) */
class Board(
    val sq: IntArray, val stm: Int, val castle: Int, val ep: Int, val half: Int, val full: Int
) {
    companion object {
        const val START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        fun fromFen(fen: String): Board {
            val p = fen.trim().split(" ").filter { it.isNotEmpty() }
            val b = IntArray(64)
            var r = 7
            var f = 0
            for (ch in p[0]) {
                when {
                    ch == '/' -> { r--; f = 0 }
                    ch.isDigit() -> f += ch - '0'
                    else -> {
                        val t = "pnbrqk".indexOf(ch.lowercaseChar()) + 1
                        b[r * 8 + f] = if (ch.isUpperCase()) t else t or 8
                        f++
                    }
                }
            }
            val stm = if (p.getOrElse(1) { "w" } == "w") 0 else 1
            val cs = p.getOrElse(2) { "-" }
            var c = 0
            if (cs.contains('K')) c = c or 1
            if (cs.contains('Q')) c = c or 2
            if (cs.contains('k')) c = c or 4
            if (cs.contains('q')) c = c or 8
            val eps = p.getOrElse(3) { "-" }
            val ep = if (eps == "-") -1 else sqOf(eps)
            return Board(b, stm, c, ep, p.getOrElse(4) { "0" }.toIntOrNull() ?: 0, p.getOrElse(5) { "1" }.toIntOrNull() ?: 1)
        }

        fun name(s: Int): String = "${'a' + (s and 7)}${(s shr 3) + 1}"
        fun sqOf(n: String): Int = (n[1] - '1') * 8 + (n[0] - 'a')
        fun from(m: Int) = m and 63
        fun to(m: Int) = (m shr 6) and 63
        fun promo(m: Int) = (m shr 12) and 7
        fun mv(f: Int, t: Int, p: Int = 0) = f or (t shl 6) or (p shl 12)
    }

    fun toFen(): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var e = 0
            for (f in 0..7) {
                val p = sq[r * 8 + f]
                if (p == 0) e++ else {
                    if (e > 0) { sb.append(e); e = 0 }
                    val c = "?pnbrqk"[p and 7]
                    sb.append(if ((p shr 3) == 0) c.uppercaseChar() else c)
                }
            }
            if (e > 0) sb.append(e)
            if (r > 0) sb.append('/')
        }
        sb.append(if (stm == 0) " w " else " b ")
        var c = ""
        if ((castle and 1) != 0) c += "K"
        if ((castle and 2) != 0) c += "Q"
        if ((castle and 4) != 0) c += "k"
        if ((castle and 8) != 0) c += "q"
        sb.append(if (c.isEmpty()) "-" else c)
        sb.append(' ').append(if (ep < 0) "-" else name(ep))
        sb.append(' ').append(half).append(' ').append(full)
        return sb.toString()
    }

    /** fanalahidy ho an'ny famerenana toeran-javatra (3-fold) */
    fun key(): String = toFen().substringBeforeLast(" ").substringBeforeLast(" ")

    fun uci(m: Int): String {
        val pr = promo(m)
        return name(from(m)) + name(to(m)) + (if (pr != 0) "_nbrq"[pr - 1].toString() else "")
    }

    fun parseMove(s: String): Int? = legalMoves().firstOrNull { uci(it) == s }

    /** SAN (ho an'ny lisitry ny hetsika sy PGN) */
    fun san(m: Int): String {
        val f = from(m); val t = to(m)
        val type = sq[f] and 7
        var s: String
        if (type == 6 && abs(t - f) == 2) s = if (t > f) "O-O" else "O-O-O"
        else {
            val cap = sq[t] != 0 || (type == 1 && (f and 7) != (t and 7))
            val sb = StringBuilder()
            if (type == 1) {
                if (cap) sb.append('a' + (f and 7))
            } else {
                sb.append("?PNBRQK"[type])
                val others = legalMoves().filter { it != m && to(it) == t && (sq[from(it)] and 7) == type }
                if (others.isNotEmpty()) {
                    val sameFile = others.any { (from(it) and 7) == (f and 7) }
                    val sameRank = others.any { (from(it) shr 3) == (f shr 3) }
                    if (!sameFile) sb.append('a' + (f and 7))
                    else if (!sameRank) sb.append('1' + (f shr 3))
                    else sb.append(name(f))
                }
            }
            if (cap) sb.append('x')
            sb.append(name(t))
            if (promo(m) != 0) sb.append('=').append("??NBRQ"[promo(m)])
            s = sb.toString()
        }
        val nb = play(m)
        if (nb.inCheck()) s += if (nb.legalMoves().isEmpty()) "#" else "+"
        return s
    }

    /** Mamaky SAN (e4, Nbd7, exd5, O-O, e8=Q ...) -> hetsika legal na null */
    fun parseSan(raw: String): Int? {
        var s = raw.trim().trimEnd('+', '#', '!', '?').replace('0', 'O')
        if (s.isEmpty()) return null
        val legal = legalMoves()
        if (s.startsWith("O-O-O")) return legal.firstOrNull { (sq[from(it)] and 7) == 6 && to(it) == from(it) - 2 }
        if (s.startsWith("O-O")) return legal.firstOrNull { (sq[from(it)] and 7) == 6 && to(it) == from(it) + 2 }
        s = s.replace("x", "").replace("=", "")
        var pr = 0
        if (s.length >= 3 && s.last() in "NBRQ" && s[s.length - 2].isDigit()) { pr = "??NBRQ".indexOf(s.last()); s = s.dropLast(1) }
        if (s.length < 2 || s[s.length - 2] !in 'a'..'h' || s.last() !in '1'..'8') return null
        val dest = sqOf(s.substring(s.length - 2))
        val head = s.substring(0, s.length - 2)
        val isPiece = head.isNotEmpty() && head[0] in "NBRQK"
        val type = if (isPiece) "?PNBRQK".indexOf(head[0]) else 1
        val dis = if (isPiece) head.drop(1) else head
        return legal.firstOrNull { m ->
            to(m) == dest && (sq[from(m)] and 7) == type && promo(m) == pr &&
                dis.all { ch ->
                    if (ch in 'a'..'h') (from(m) and 7) == (ch - 'a')
                    else if (ch in '1'..'8') (from(m) shr 3) == (ch - '1')
                    else false
                }
        }
    }

    fun kingSq(c: Int): Int {
        val k = 6 or (c shl 3)
        for (i in 0..63) if (sq[i] == k) return i
        return -1
    }

    fun isAttacked(s: Int, by: Int): Boolean {
        val r = s shr 3
        val f = s and 7
        val dir = if (by == 0) 1 else -1
        val pr = r - dir
        if (pr in 0..7) {
            for (df in intArrayOf(-1, 1)) {
                val pf = f + df
                if (pf in 0..7 && sq[pr * 8 + pf] == (1 or (by shl 3))) return true
            }
        }
        for (d in KN) {
            val nr = r + d[0]
            val nf = f + d[1]
            if (nr in 0..7 && nf in 0..7 && sq[nr * 8 + nf] == (2 or (by shl 3))) return true
        }
        for (dr in -1..1) for (df in -1..1) {
            if (dr == 0 && df == 0) continue
            val nr = r + dr
            val nf = f + df
            if (nr in 0..7 && nf in 0..7 && sq[nr * 8 + nf] == (6 or (by shl 3))) return true
        }
        for (d in DIAG) {
            var nr = r + d[0]
            var nf = f + d[1]
            while (nr in 0..7 && nf in 0..7) {
                val p = sq[nr * 8 + nf]
                if (p != 0) {
                    val t = p and 7
                    if ((p shr 3) == by && (t == 3 || t == 5)) return true
                    break
                }
                nr += d[0]; nf += d[1]
            }
        }
        for (d in ORTH) {
            var nr = r + d[0]
            var nf = f + d[1]
            while (nr in 0..7 && nf in 0..7) {
                val p = sq[nr * 8 + nf]
                if (p != 0) {
                    val t = p and 7
                    if ((p shr 3) == by && (t == 4 || t == 5)) return true
                    break
                }
                nr += d[0]; nf += d[1]
            }
        }
        return false
    }

    /** Sanda (P=1, N/B=3, R=5, Q=9, K=100) an'ny sombin-javatra `by` manafika ny `s` — ho an'ny SEE */
    fun attackerValues(s: Int, by: Int): List<Int> {
        val out = ArrayList<Int>()
        val r = s shr 3
        val f = s and 7
        val dir = if (by == 0) 1 else -1
        val pr = r - dir
        if (pr in 0..7) for (df in intArrayOf(-1, 1)) {
            val pf = f + df
            if (pf in 0..7 && sq[pr * 8 + pf] == (1 or (by shl 3))) out.add(1)
        }
        for (d in KN) {
            val nr = r + d[0]; val nf = f + d[1]
            if (nr in 0..7 && nf in 0..7 && sq[nr * 8 + nf] == (2 or (by shl 3))) out.add(3)
        }
        for (dr in -1..1) for (df in -1..1) {
            if (dr == 0 && df == 0) continue
            val nr = r + dr; val nf = f + df
            if (nr in 0..7 && nf in 0..7 && sq[nr * 8 + nf] == (6 or (by shl 3))) out.add(100)
        }
        for (d in DIAG) {
            var nr = r + d[0]; var nf = f + d[1]
            while (nr in 0..7 && nf in 0..7) {
                val p = sq[nr * 8 + nf]
                if (p != 0) {
                    if ((p shr 3) == by) { val t = p and 7; if (t == 3) out.add(3) else if (t == 5) out.add(9) }
                    break
                }
                nr += d[0]; nf += d[1]
            }
        }
        for (d in ORTH) {
            var nr = r + d[0]; var nf = f + d[1]
            while (nr in 0..7 && nf in 0..7) {
                val p = sq[nr * 8 + nf]
                if (p != 0) {
                    if ((p shr 3) == by) { val t = p and 7; if (t == 4) out.add(5) else if (t == 5) out.add(9) }
                    break
                }
                nr += d[0]; nf += d[1]
            }
        }
        return out
    }

    fun inCheck(): Boolean = isAttacked(kingSq(stm), 1 - stm)

    private fun addPawn(out: ArrayList<Int>, f: Int, t: Int, promo: Boolean) {
        if (promo) for (p in 2..5) out.add(mv(f, t, p)) else out.add(mv(f, t))
    }

    private fun pseudo(): ArrayList<Int> {
        val out = ArrayList<Int>(48)
        val dir = if (stm == 0) 8 else -8
        val startRank = if (stm == 0) 1 else 6
        val promoRank = if (stm == 0) 6 else 1
        for (s in 0..63) {
            val p = sq[s]
            if (p == 0 || (p shr 3) != stm) continue
            val type = p and 7
            val r = s shr 3
            val f = s and 7
            when (type) {
                1 -> {
                    val one = s + dir
                    if (one in 0..63 && sq[one] == 0) {
                        addPawn(out, s, one, r == promoRank)
                        if (r == startRank && sq[one + dir] == 0) out.add(mv(s, one + dir))
                    }
                    for (df in intArrayOf(-1, 1)) {
                        val nf = f + df
                        if (nf !in 0..7) continue
                        val to = s + dir + df
                        if (to < 0 || to > 63) continue
                        if (sq[to] != 0 && (sq[to] shr 3) != stm) addPawn(out, s, to, r == promoRank)
                        else if (to == ep && sq[to] == 0) out.add(mv(s, to))
                    }
                }
                2 -> for (d in KN) {
                    val nr = r + d[0]
                    val nf = f + d[1]
                    if (nr in 0..7 && nf in 0..7) {
                        val t = nr * 8 + nf
                        if (sq[t] == 0 || (sq[t] shr 3) != stm) out.add(mv(s, t))
                    }
                }
                6 -> {
                    for (dr in -1..1) for (df in -1..1) {
                        if (dr == 0 && df == 0) continue
                        val nr = r + dr
                        val nf = f + df
                        if (nr in 0..7 && nf in 0..7) {
                            val t = nr * 8 + nf
                            if (sq[t] == 0 || (sq[t] shr 3) != stm) out.add(mv(s, t))
                        }
                    }
                    val base = if (stm == 0) 0 else 56
                    val rook = 4 or (stm shl 3)
                    if (s == base + 4 && !isAttacked(s, 1 - stm)) {
                        val ks = if (stm == 0) 1 else 4
                        val qs = if (stm == 0) 2 else 8
                        if ((castle and ks) != 0 && sq[base + 5] == 0 && sq[base + 6] == 0 && sq[base + 7] == rook &&
                            !isAttacked(base + 5, 1 - stm) && !isAttacked(base + 6, 1 - stm)) out.add(mv(s, base + 6))
                        if ((castle and qs) != 0 && sq[base + 1] == 0 && sq[base + 2] == 0 && sq[base + 3] == 0 && sq[base] == rook &&
                            !isAttacked(base + 3, 1 - stm) && !isAttacked(base + 2, 1 - stm)) out.add(mv(s, base + 2))
                    }
                }
                else -> {
                    val dirs = when (type) { 3 -> DIAG; 4 -> ORTH; else -> DIAG + ORTH }
                    for (d in dirs) {
                        var nr = r + d[0]
                        var nf = f + d[1]
                        while (nr in 0..7 && nf in 0..7) {
                            val t = nr * 8 + nf
                            if (sq[t] == 0) out.add(mv(s, t)) else {
                                if ((sq[t] shr 3) != stm) out.add(mv(s, t))
                                break
                            }
                            nr += d[0]; nf += d[1]
                        }
                    }
                }
            }
        }
        return out
    }

    fun play(m: Int): Board {
        val f = from(m)
        val t = to(m)
        val pr = promo(m)
        val nb = sq.copyOf()
        val p = nb[f]
        val type = p and 7
        var nep = -1
        var nh = half + 1
        if (type == 1 || nb[t] != 0) nh = 0
        if (type == 1 && t == ep && (f and 7) != (t and 7)) nb[t + (if (stm == 0) -8 else 8)] = 0
        if (type == 1 && abs(t - f) == 16) nep = (f + t) / 2
        nb[t] = if (pr != 0) (pr or (stm shl 3)) else p
        nb[f] = 0
        if (type == 6 && abs(t - f) == 2) {
            if (t > f) { nb[f + 1] = nb[f + 3]; nb[f + 3] = 0 } else { nb[f - 1] = nb[f - 4]; nb[f - 4] = 0 }
        }
        val nc = castle and cmask(f) and cmask(t)
        return Board(nb, 1 - stm, nc, nep, nh, if (stm == 1) full + 1 else full)
    }

    fun legalMoves(): List<Int> {
        val out = ArrayList<Int>(40)
        for (m in pseudo()) {
            val nb = play(m)
            if (!nb.isAttacked(nb.kingSq(stm), nb.stm)) out.add(m)
        }
        return out
    }

    fun perft(d: Int): Long {
        if (d == 0) return 1
        var n = 0L
        for (m in legalMoves()) n += if (d == 1) 1 else play(m).perft(d - 1)
        return n
    }

    fun insufficient(): Boolean {
        var minors = 0
        for (p in sq) {
            val t = p and 7
            if (p == 0 || t == 6) continue
            if (t == 2 || t == 3) minors++ else return false
        }
        return minors <= 1
    }
}

enum class Res { ONGOING, WHITE, BLACK, DRAW }

class Game(val startFen: String = Board.START) {
    var board: Board = Board.fromFen(startFen)
    val moves = ArrayList<String>()
    private val keys = ArrayList<String>()
    var result = Res.ONGOING
    var reason = ""

    init { keys.add(board.key()); evaluateState() }

    fun play(m: Int) {
        moves.add(board.uci(m))
        board = board.play(m)
        keys.add(board.key())
        evaluateState()
    }

    fun end(r: Res, why: String) { result = r; reason = why }

    private fun evaluateState() {
        val legal = board.legalMoves()
        val k = keys.last()
        when {
            legal.isEmpty() -> if (board.inCheck()) end(if (board.stm == 0) Res.BLACK else Res.WHITE, "échec et mat")
                               else end(Res.DRAW, "pat")
            board.half >= 100 -> end(Res.DRAW, "règle des 50 coups")
            keys.count { it == k } >= 3 -> end(Res.DRAW, "répétition x3")
            board.insufficient() -> end(Res.DRAW, "matériel insuffisant")
        }
    }

    fun text(): String = when (result) {
        Res.ONGOING -> ""
        Res.WHITE -> "1-0 ($reason)"
        Res.BLACK -> "0-1 ($reason)"
        Res.DRAW -> "1/2-1/2 ($reason)"
    }
}
