package mg.joro.chess.match

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import mg.joro.chess.chess.Board
import java.io.File
import kotlin.random.Random

/** Livre d'ouvertures: EPD / PGN / lisitry FEN -> lisitry FEN (voatahiry ao amin'ny filesDir/books) */
object Books {
    val names = mutableStateListOf<String>()
    var active by mutableStateOf("")       // "" = ouverture aléatoire
    var count by mutableIntStateOf(0)
    val msg = mutableStateOf("")
    private var fens: List<String> = emptyList()
    private lateinit var dir: File
    private lateinit var prefs: SharedPreferences
    private const val MAX = 50_000

    fun init(ctx: Context) {
        dir = File(ctx.filesDir, "books").also { it.mkdirs() }
        prefs = ctx.getSharedPreferences("books", Context.MODE_PRIVATE)
        names.clear()
        names.addAll(dir.list()?.filter { it.endsWith(".fen") }?.map { it.removeSuffix(".fen") }?.sorted() ?: emptyList())
        select(prefs.getString("active", "") ?: "")
    }

    fun select(n: String) {
        active = if (n in names) n else ""
        prefs.edit().putString("active", active).apply()
        fens = if (active.isEmpty()) emptyList() else File(dir, "$active.fen").readLines().filter { it.isNotBlank() }
        count = fens.size
    }

    fun delete(n: String) {
        File(dir, "$n.fen").delete()
        names.remove(n)
        if (active == n) select("")
    }

    fun pick(seed: Long): String? = if (fens.isEmpty()) null else fens[Random(seed).nextInt(fens.size)]

    private fun valid(fen: String): Boolean = try {
        val b = Board.fromFen(fen)
        b.legalMoves().isNotEmpty() && b.kingSq(0) >= 0 && b.kingSq(1) >= 0
    } catch (_: Exception) { false }

    fun parseEpd(text: String): List<String> {
        val out = LinkedHashSet<String>()
        for (line in text.lines()) {
            val t = line.substringBefore(';').trim()
            if (t.isEmpty() || t.startsWith("#") || !t.contains('/')) continue
            val f = t.split(Regex("\\s+"))
            if (f.size < 4) continue
            val half = f.getOrNull(4)?.toIntOrNull()
            val full = f.getOrNull(5)?.toIntOrNull()
            val fen = f.take(4).joinToString(" ") + " " + (half ?: 0) + " " + (full ?: 1)
            if (valid(fen)) out.add(fen)
            if (out.size >= MAX) break
        }
        return out.toList()
    }

    fun parsePgn(text: String, plies: Int): List<String> {
        val out = LinkedHashSet<String>()
        for (g in Pgn.splitGames(text)) {
            val r = Pgn.movesOf(g, plies) ?: continue
            if (r.moves.size >= 2 && valid(r.endFen)) out.add(r.endFen)
            if (out.size >= MAX) break
        }
        return out.toList()
    }

    suspend fun import(uri: Uri, plies: Int): Int = withContext(Dispatchers.IO) {
        val ctx = Host.ctx
        var nm = "book"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) nm = c.getString(i)
        }
        nm = nm.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "book" }
        val text = (ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("tsy azo vakiana")).use { it.bufferedReader().readText() }
        var list = parseEpd(text)
        if (list.isEmpty()) list = parsePgn(text, plies)
        if (list.isEmpty()) throw IllegalStateException("Tsy nahitana toerana (EPD/PGN/FEN) ao anaty fichier")
        File(dir, "$nm.fen").writeText(list.joinToString("\n"))
        if (nm !in names) names.add(nm)
        select(nm)
        list.size
    }
}
