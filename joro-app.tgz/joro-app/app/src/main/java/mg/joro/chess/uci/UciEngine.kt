package mg.joro.chess.uci

import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedWriter
import kotlin.concurrent.thread

data class UciOption(val name: String, val type: String, val def: String, val min: Int?, val max: Int?)
data class Info(val depth: Int, val cp: Int?, val mate: Int?, val nodes: Long, val nps: Long, val pv: String, val multipv: Int = 1) {
    /** score amin'ny fotsy (mover = 0) na mainty */
    fun text(): String = "d$depth " + when {
        mate != null -> "#$mate"
        cp != null -> (if (cp >= 0) "+" else "") + String.format(java.util.Locale.US, "%.2f", cp / 100.0)
        else -> "?"
    }
}
class BestMove(val move: String?, val info: Info?, val status: String) // status: ok | timeout | crash

class UciEngine(val path: String) {
    private var proc: Process? = null
    private var writer: BufferedWriter? = null
    private val lines = Channel<String>(Channel.UNLIMITED)
    var name = ""
    val options = ArrayList<UciOption>()

    fun has(opt: String) = options.any { it.name == opt }
    fun option(opt: String) = options.firstOrNull { it.name == opt }

    suspend fun start() {
        val p = ProcessBuilder(path).redirectErrorStream(true).start()
        proc = p
        writer = p.outputStream.bufferedWriter()
        thread(isDaemon = true) {
            try {
                val r = p.inputStream.bufferedReader()
                while (true) {
                    val l = r.readLine() ?: break
                    lines.trySend(l)
                }
            } catch (_: Exception) {
            }
            lines.trySend("<eof>")
        }
        send("uci")
        withTimeout(10_000) {
            var done = false
            while (!done) {
                val l = lines.receive()
                when {
                    l == "<eof>" -> throw IllegalStateException("Ny moteur dia nijanona (tsy UCI?)")
                    l.startsWith("id name") -> name = l.removePrefix("id name").trim()
                    l.startsWith("option name") -> parseOption(l)?.let { options.add(it) }
                    l == "uciok" -> done = true
                }
            }
        }
        ready()
    }

    private fun parseOption(l: String): UciOption? {
        val t = l.split(" ").filter { it.isNotEmpty() }
        val ni = t.indexOf("name")
        val ti = t.indexOf("type")
        if (ni < 0 || ti < 0 || ti + 1 >= t.size) return null
        fun after(k: String): String? {
            val j = (ti + 2 until t.size).firstOrNull { t[it] == k } ?: return null
            return if (j + 1 < t.size) t[j + 1] else null
        }
        return UciOption(t.subList(ni + 1, ti).joinToString(" "), t[ti + 1], after("default") ?: "",
            after("min")?.toIntOrNull(), after("max")?.toIntOrNull())
    }

    fun send(s: String) {
        try {
            writer?.apply { write(s); write("\n"); flush() }
        } catch (_: Exception) {
        }
    }

    suspend fun ready() {
        send("isready")
        withTimeout(20_000) {
            while (true) {
                val l = lines.receive()
                if (l == "readyok") break
                if (l == "<eof>") throw IllegalStateException("Moteur mort")
            }
        }
    }

    fun setOption(n: String, v: String) = send("setoption name $n value $v")

    suspend fun newGame() { send("ucinewgame"); ready() }

    suspend fun go(fen: String, moves: List<String>, goArgs: String, timeoutMs: Long, onInfo: ((Info) -> Unit)? = null): BestMove {
        send("position fen $fen" + if (moves.isNotEmpty()) " moves " + moves.joinToString(" ") else "")
        send("go $goArgs")
        var last: Info? = null
        var res: BestMove? = null
        withTimeoutOrNull(timeoutMs) {
            while (res == null) {
                val l = lines.receive()
                if (l == "<eof>") res = BestMove(null, last, "crash")
                else if (l.startsWith("info")) {
                    parseInfo(l)?.let { last = it; onInfo?.invoke(it) }
                } else if (l.startsWith("bestmove")) {
                    val m = l.split(" ").getOrNull(1)
                    res = BestMove(if (m == null || m == "(none)" || m == "0000") null else m, last, "ok")
                }
            }
        }
        return res ?: BestMove(null, last, "timeout")
    }

    private fun parseInfo(l: String): Info? {
        val t = l.split(" ")
        var depth = -1; var cp: Int? = null; var mate: Int? = null; var nodes = 0L; var nps = 0L; var pv = ""; var mpv = 1
        var i = 1
        while (i < t.size) {
            when (t[i]) {
                "depth" -> { depth = t.getOrNull(i + 1)?.toIntOrNull() ?: depth; i++ }
                "multipv" -> { mpv = t.getOrNull(i + 1)?.toIntOrNull() ?: 1; i++ }
                "nodes" -> { nodes = t.getOrNull(i + 1)?.toLongOrNull() ?: 0; i++ }
                "nps" -> { nps = t.getOrNull(i + 1)?.toLongOrNull() ?: 0; i++ }
                "score" -> {
                    if (t.getOrNull(i + 1) == "cp") cp = t.getOrNull(i + 2)?.toIntOrNull()
                    else if (t.getOrNull(i + 1) == "mate") mate = t.getOrNull(i + 2)?.toIntOrNull()
                    i += 2
                }
                "pv" -> { pv = t.drop(i + 1).joinToString(" "); i = t.size }
            }
            i++
        }
        return if (depth >= 0 && (cp != null || mate != null)) Info(depth, cp, mate, nodes, nps, pv, mpv) else null
    }

    fun close() {
        send("quit")
        try { proc?.destroy() } catch (_: Exception) { }
        try { proc?.destroyForcibly() } catch (_: Exception) { }
    }
}
