package mg.joro.chess.match

import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PgnLine(val startFen: String, val moves: List<String>, val endFen: String)

object Pgn {
    fun splitGames(text: String): List<String> = text.split(Regex("(?m)^(?=\\[Event )"))

    /** Mamaky lalao PGN iray -> FEN fiandohana + hetsika UCI (hatramin'ny maxPlies) */
    fun movesOf(chunk: String, maxPlies: Int = 1000): PgnLine? {
        val lines = chunk.lines()
        val startFen = lines.firstOrNull { it.startsWith("[FEN ") }?.substringAfter('"')?.substringBefore('"') ?: Board.START
        var mt = lines.filter { !it.trimStart().startsWith("[") }.joinToString(" ") { it.substringBefore(';') }
        mt = mt.replace(Regex("\\{[^}]*\\}"), " ").replace(Regex("\\$\\d+"), " ")
        while (mt.contains('(')) {
            val n = mt.replace(Regex("\\([^()]*\\)"), " ")
            if (n == mt) break
            mt = n
        }
        var b = try { Board.fromFen(startFen) } catch (_: Exception) { return null }
        val out = ArrayList<String>()
        for (raw in mt.split(Regex("\\s+"))) {
            if (out.size >= maxPlies) break
            val tok = raw.replace(Regex("^\\d+\\.+"), "")
            if (tok.isEmpty() || tok == "1-0" || tok == "0-1" || tok == "1/2-1/2" || tok == "*") continue
            val m = b.parseSan(tok) ?: break
            out.add(b.uci(m))
            b = b.play(m)
        }
        return PgnLine(startFen, out, b.toFen())
    }

    fun build(startFen: String, moves: List<String>, white: String, black: String, result: Res, reason: String = "", marks: List<String> = emptyList()): String {
        val res = when (result) { Res.WHITE -> "1-0"; Res.BLACK -> "0-1"; Res.DRAW -> "1/2-1/2"; else -> "*" }
        val date = SimpleDateFormat("yyyy.MM.dd", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.append("[Event \"Blind Chess\"]\n[Site \"?\"]\n[Date \"$date\"]\n[Round \"?\"]\n")
        sb.append("[White \"$white\"]\n[Black \"$black\"]\n[Result \"$res\"]\n")
        if (startFen != Board.START) sb.append("[SetUp \"1\"]\n[FEN \"$startFen\"]\n")
        if (reason.isNotEmpty()) sb.append("[Termination \"$reason\"]\n")
        sb.append('\n')
        var b = Board.fromFen(startFen)
        val words = ArrayList<String>()
        for ((idx, u) in moves.withIndex()) {
            val m = b.parseMove(u) ?: break
            if (b.stm == 0) words.add("${b.full}.")
            else if (words.isEmpty()) words.add("${b.full}...")
            words.add(b.san(m) + marks.getOrElse(idx) { "" })
            b = b.play(m)
        }
        words.add(res)
        var line = StringBuilder()
        for (w in words) {
            if (line.length + w.length + 1 > 80) { sb.append(line.toString().trimEnd()).append('\n'); line = StringBuilder() }
            line.append(w).append(' ')
        }
        sb.append(line.toString().trimEnd()).append('\n')
        return sb.toString()
    }
}
