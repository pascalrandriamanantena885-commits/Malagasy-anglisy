package mg.joro.chess.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import mg.joro.chess.match.Host

/**
 * Safidin'ny fisehoana (voatahiry ao amin'ny SharedPreferences "ui").
 * Ny theme (maizina / mazava) dia an'ny app ihany: TSY manaraka ny mode light/dark an'ny finday.
 */
object UiPrefs {
    private var sp: SharedPreferences? = null

    /** true = maizina (default), false = mazava */
    var dark by mutableStateOf(true)
        private set

    /** true = card grid, false = lisitra */
    var grid by mutableStateOf(false)
        private set

    /** isan'ny zavatra isaky ny pejy (pagination) */
    var pageSize by mutableIntStateOf(6)
        private set

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)
        sp = p
        dark = p.getBoolean("dark", true)
        grid = p.getBoolean("grid", false)
        pageSize = p.getInt("pageSize", 6).coerceIn(3, 50)
        Host.boardTheme.value = p.getInt("board", 0).coerceIn(0, 1)
    }

    fun updateDark(v: Boolean) { dark = v; sp?.edit()?.putBoolean("dark", v)?.apply() }
    fun updateGrid(v: Boolean) { grid = v; sp?.edit()?.putBoolean("grid", v)?.apply() }
    fun updatePageSize(v: Int) { pageSize = v.coerceIn(3, 50); sp?.edit()?.putInt("pageSize", pageSize)?.apply() }
    fun setBoard(v: Int) { Host.boardTheme.value = v.coerceIn(0, 1); sp?.edit()?.putInt("board", Host.boardTheme.value)?.apply() }
}
