package mg.joro.chess.match

import mg.joro.chess.chess.Board
import java.io.BufferedReader
import java.io.StringReader

/** Lalao PGN iray: fiandohana + hetsika UCI + valiny ("1-0", "0-1", "1/2-1/2", "*"). Tsy tazonina fa avy hatrany ny fanodinana. */
class PgnGame(val startFen: String, val moves: List<String>, val result: String)

/**
 * Opening hita ho azy ao anaty PGN, ho an'ny sisiny nandresy: `fen` = toerana (ao amin'ny opening) hanombohan'ny fianarana,
 * `packed` = hetsika aorian'io toerana io isaky ny lalao nandresy (tahiry kely: 1 hetsika = 1 Short), `games` = isan'ny lalao nandresy.
 */
class PgnOpening(val name: String, val fen: String, val side: Int, val packed: List<ShortArray>, val games: Int) {
    /** Hetsika UCI (ho an'ny test / fampiasana kely; ny Training dia mamaky ny `packed` mivantana) */
    val lines: List<List<String>> get() = packed.map { l -> l.map { PgnTrain.unpack(it) } }
}

/** `total` = lalao rehetra, `decisive` = tsy nul, `unnamed` = tsy hita ao amin'ny book ECO, `small` = opening latsaky ny lalao min */
class PgnGrouping(val groups: List<PgnOpening>, val total: Int, val decisive: Int, val unnamed: Int, val small: Int)

/** Lojika madio (tsy miankina amin'ny Android) ho an'ny fianarana avy amin'ny PGN ivelany */
object PgnTrain {
    private val resultTag = Regex("(?m)^\\[Result\\s+\"([^\"]*)\"\\s*]")
    private val resultEnd = Regex("(1-0|0-1|1/2-1/2)\\s*$")
    private val tagLine = Regex("^\\[[A-Za-z0-9_]+\\s+\"")

    fun resultOf(chunk: String): String {
        val h = resultTag.find(chunk)?.groupValues?.get(1)?.trim()
        if (h == "1-0" || h == "0-1" || h == "1/2-1/2") return h
        return resultEnd.find(chunk.trimEnd())?.groupValues?.get(1) ?: "*"
    }

    /** 0 = fotsy no nandresy, 1 = mainty, -1 = nul na tsy fantatra */
    fun winner(result: String): Int = when (result) { "1-0" -> 0; "0-1" -> 1; else -> -1 }

    // ---- tahiry kely ho an'ny hetsika: from(6 bit) | to(6 bit)<<6 | promo(3 bit)<<12 ----
    fun pack(u: String): Short {
        val f = (u[1] - '1') * 8 + (u[0] - 'a')
        val t = (u[3] - '1') * 8 + (u[2] - 'a')
        val p = if (u.length > 4) "nbrq".indexOf(u[4].lowercaseChar()) + 1 else 0
        return (f or (t shl 6) or (p shl 12)).toShort()
    }

    fun unpack(c: Short): String {
        val v = c.toInt()
        val f = v and 63
        val t = (v shr 6) and 63
        val p = (v shr 12) and 7
        val sb = StringBuilder(5)
        sb.append('a' + f % 8).append('1' + f / 8).append('a' + t % 8).append('1' + t / 8)
        if (p in 1..4) sb.append("nbrq"[p - 1])
        return sb.toString()
    }

    private fun gameOf(chunk: String): PgnGame? {
        val pl = Pgn.movesOf(chunk) ?: return null
        if (pl.moves.isEmpty()) return null
        return PgnGame(pl.startFen, pl.moves, resultOf(chunk))
    }

    /**
     * Mamaky PGN tsipika tsipika (streaming): lalao iray isaky ny indray mandeha no ao anaty memoire, ary `onGame` no antsoina avy hatrany.
     * Lalao vaovao = tsipika header (`[Tag "..."]`) aorian'ny hetsika. Tsy misy fetra amin'ny isan'ny lalao.
     */
    fun stream(r: BufferedReader, onGame: (PgnGame) -> Unit) {
        val buf = StringBuilder()
        var sawMoves = false
        var first = true
        fun flush() {
            if (buf.isNotBlank()) gameOf(buf.toString())?.let(onGame)
            buf.setLength(0)
            sawMoves = false
        }
        while (true) {
            var l = r.readLine() ?: break
            if (first) { l = l.removePrefix("\uFEFF"); first = false }
            val t = l.trimStart()
            if (tagLine.containsMatchIn(t)) { if (sawMoves) flush() } else if (t.isNotEmpty()) sawMoves = true
            buf.append(l).append('\n')
        }
        flush()
    }

    /** Mamaky lalao rehetra ao amin'ny teny (ho an'ny test / PGN kely); ny PGN lehibe dia `stream` no ampiasaina */
    fun parse(text: String): List<PgnGame> {
        val out = ArrayList<PgnGame>()
        stream(BufferedReader(StringReader(text))) { out.add(it) }
        return out
    }

    /** "King's Gambit Accepted: Knight Gambit" -> "King's Gambit Accepted" */
    fun family(name: String): String = name.substringBefore(':').trim()

    /**
     * Ny app no mijery ny opening: isaky ny lalao nandresy (tsy nul), mitady ny toerana lalina indrindra voasoratra ao amin'ny book
     * (`nameOf(Board.key())` = anaran'ny opening na null) ; ny "fianakaviana" (ohatra "Sicilian Defense") no ampiasaina, ary ny toerana
     * fohy indrindra an'io fianakaviana io no fototry ny profil (ka mitovy ny profil raha tonga amin'ny transposition).
     * Ny mpandresy (fotsy/mainty) no sisiny ampiofanina. Hetsika aorian'io toerana io no ianarana.
     * Default: tsy misy fetra (lalao rehetra, hetsika rehetra, opening rehetra, na lalao iray aza); ny paramètre dia ho an'ny test / fanamafisana.
     * Azo ampiasaina amin'ny streaming: `add(game)` isaky ny lalao, dia `result()`.
     */
    class Grouper(
        private val nameOf: (String) -> String?,
        private val maxPlies: Int = Int.MAX_VALUE, private val minGames: Int = 1,
        private val maxOpenings: Int = Int.MAX_VALUE, private val perOpening: Int = Int.MAX_VALUE
    ) {
        private class Acc(val name: String, val fen: String, val side: Int) {
            val lines = ArrayList<ShortArray>()
            var n = 0
        }
        private val acc = LinkedHashMap<String, Acc>()
        var total = 0
            private set
        var decisive = 0
            private set
        var unnamed = 0
            private set

        fun add(g: PgnGame) {
            total++
            val side = winner(g.result)
            if (side < 0) return
            decisive++
            var b = try { Board.fromFen(g.startFen) } catch (_: Exception) { return }
            val keys = ArrayList<String>()
            val fens = ArrayList<String>()
            val names = ArrayList<String?>()
            for (u in g.moves) {
                val m = b.parseMove(u) ?: break
                b = b.play(m)
                val k = b.key()
                keys.add(k); fens.add(b.toFen()); names.add(nameOf(k))
            }
            val deepest = names.indexOfLast { it != null }
            if (deepest < 0) { unnamed++; return }
            val fam = family(names[deepest]!!)
            val j = names.indexOfFirst { it != null && family(it) == fam }
            val rest = g.moves.drop(j + 1).take(maxPlies.coerceAtLeast(1))
            if (rest.isEmpty()) return
            val a = acc.getOrPut("$fam|$side|${keys[j]}") { Acc(fam, fens[j], side) }
            a.n++
            if (a.lines.size < perOpening) a.lines.add(ShortArray(rest.size) { pack(rest[it]) })
        }

        fun result(): PgnGrouping {
            val mg = minGames.coerceAtLeast(1)
            val big = acc.values.filter { it.n >= mg }.sortedByDescending { it.n }.take(maxOpenings.coerceAtLeast(1))
            val used = HashMap<String, Int>()
            val out = ArrayList<PgnOpening>()
            for (a in big) {
                val k = "${a.name}|${a.side}"
                val c = (used[k] ?: 0) + 1
                used[k] = c
                out.add(PgnOpening(if (c == 1) a.name else "${a.name} #$c", a.fen, a.side, a.lines, a.n))
            }
            return PgnGrouping(out, total, decisive, unnamed, acc.size - acc.values.count { it.n >= mg })
        }
    }

    fun group(
        games: List<PgnGame>, nameOf: (String) -> String?,
        maxPlies: Int = Int.MAX_VALUE, minGames: Int = 1, maxOpenings: Int = Int.MAX_VALUE, perOpening: Int = Int.MAX_VALUE
    ): PgnGrouping {
        val gp = Grouper(nameOf, maxPlies, minGames, maxOpenings, perOpening)
        for (g in games) gp.add(g)
        return gp.result()
    }
}
