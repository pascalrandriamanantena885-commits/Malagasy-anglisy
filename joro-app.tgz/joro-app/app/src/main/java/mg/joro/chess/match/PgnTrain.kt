package mg.joro.chess.match

import mg.joro.chess.chess.Board

/** Lalao PGN iray: fiandohana + hetsika UCI + valiny ("1-0", "0-1", "1/2-1/2", "*") */
class PgnGame(val startFen: String, val moves: List<String>, val result: String)

/**
 * Opening hita ho azy ao anaty PGN, ho an'ny sisiny nandresy: `fen` = toerana (ao amin'ny opening) hanombohan'ny fianarana,
 * `lines` = hetsika (UCI) aorian'io toerana io isaky ny lalao nandresy, `games` = isan'ny lalao nandresy tamin'io opening io.
 */
class PgnOpening(val name: String, val fen: String, val side: Int, val lines: List<List<String>>, val games: Int)

/** `total` = lalao rehetra, `decisive` = tsy nul, `unnamed` = tsy hita ao amin'ny book ECO, `small` = opening latsaky ny lalao min */
class PgnGrouping(val groups: List<PgnOpening>, val total: Int, val decisive: Int, val unnamed: Int, val small: Int)

/** Lojika madio (tsy miankina amin'ny Android) ho an'ny fianarana avy amin'ny PGN ivelany */
object PgnTrain {
    private val resultTag = Regex("(?m)^\\[Result\\s+\"([^\"]*)\"\\s*]")
    private val resultEnd = Regex("(1-0|0-1|1/2-1/2)\\s*$")

    fun resultOf(chunk: String): String {
        val h = resultTag.find(chunk)?.groupValues?.get(1)?.trim()
        if (h == "1-0" || h == "0-1" || h == "1/2-1/2") return h
        return resultEnd.find(chunk.trimEnd())?.groupValues?.get(1) ?: "*"
    }

    /** 0 = fotsy no nandresy, 1 = mainty, -1 = nul na tsy fantatra */
    fun winner(result: String): Int = when (result) { "1-0" -> 0; "0-1" -> 1; else -> -1 }

    /** Mamaky lalao rehetra ao amin'ny PGN (lalao tsy misy hetsika dia lavina) */
    fun parse(text: String, maxGames: Int = 20000): List<PgnGame> {
        val out = ArrayList<PgnGame>()
        for (chunk in Pgn.splitGames(text)) {
            if (chunk.isBlank()) continue
            val pl = Pgn.movesOf(chunk) ?: continue
            if (pl.moves.isEmpty()) continue
            out.add(PgnGame(pl.startFen, pl.moves, resultOf(chunk)))
            if (out.size >= maxGames) break
        }
        return out
    }

    /** "King's Gambit Accepted: Knight Gambit" -> "King's Gambit Accepted" */
    fun family(name: String): String = name.substringBefore(':').trim()

    /**
     * Ny app no mijery ny opening: isaky ny lalao nandresy (tsy nul), mitady ny toerana lalina indrindra voasoratra ao amin'ny book
     * (`nameOf(Board.key())` = anaran'ny opening na null) ; ny "fianakaviana" (ohatra "Sicilian Defense") no ampiasaina, ary ny toerana
     * fohy indrindra an'io fianakaviana io no fototry ny profil (ka mitovy ny profil raha tonga amin'ny transposition).
     * Ny mpandresy (fotsy/mainty) no sisiny ampiofanina. Hetsika aorian'io toerana io no ianarana (hatramin'ny `maxPlies`).
     * Default: tsy misy fetra (lalao rehetra, hetsika rehetra, opening rehetra, na lalao iray aza); ny paramètre dia ho an'ny test / fanamafisana.
     */
    fun group(
        games: List<PgnGame>, nameOf: (String) -> String?,
        maxPlies: Int = Int.MAX_VALUE, minGames: Int = 1, maxOpenings: Int = Int.MAX_VALUE, perOpening: Int = Int.MAX_VALUE
    ): PgnGrouping {
        class Acc(val name: String, val fen: String, val side: Int) {
            val lines = ArrayList<List<String>>()
            var n = 0
        }
        val acc = LinkedHashMap<String, Acc>()
        var decisive = 0
        var unnamed = 0
        for (g in games) {
            val side = winner(g.result)
            if (side < 0) continue
            decisive++
            var b = try { Board.fromFen(g.startFen) } catch (_: Exception) { continue }
            val keys = ArrayList<String>()
            val fens = ArrayList<String>()
            val names = ArrayList<String?>()
            for (u in g.moves) {
                val m = b.parseMove(u) ?: break
                b = b.play(m)
                val k = b.key()
                keys.add(k); fens.add(b.toFen()); names.add(nameOf(k))
            }
            val deepest = names.indexOfLast { it != null }
            if (deepest < 0) { unnamed++; continue }
            val fam = family(names[deepest]!!)
            val j = names.indexOfFirst { it != null && family(it) == fam }
            val rest = g.moves.drop(j + 1).take(maxPlies.coerceAtLeast(1))
            if (rest.isEmpty()) continue
            val a = acc.getOrPut("$fam|$side|${keys[j]}") { Acc(fam, fens[j], side) }
            a.n++
            if (a.lines.size < perOpening) a.lines.add(rest)
        }
        val big = acc.values.filter { it.n >= minGames.coerceAtLeast(1) }.sortedByDescending { it.n }.take(maxOpenings.coerceAtLeast(1))
        val used = HashMap<String, Int>()
        val out = ArrayList<PgnOpening>()
        for (a in big) {
            val k = "${a.name}|${a.side}"
            val c = (used[k] ?: 0) + 1
            used[k] = c
            out.add(PgnOpening(if (c == 1) a.name else "${a.name} #$c", a.fen, a.side, a.lines, a.n))
        }
        return PgnGrouping(out, games.size, decisive, unnamed, acc.size - acc.values.count { it.n >= minGames.coerceAtLeast(1) })
    }
}
