package mg.joro.chess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import mg.joro.chess.match.Host
import mg.joro.chess.ui.App

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Host.init(applicationContext)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}
