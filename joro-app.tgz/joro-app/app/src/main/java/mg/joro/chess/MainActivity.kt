package mg.joro.chess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import mg.joro.chess.match.Host
import mg.joro.chess.ui.App
import mg.joro.chess.ui.BlindTheme
import mg.joro.chess.ui.UiPrefs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.init(applicationContext)
        Host.init(applicationContext)
        UiPrefs.init(applicationContext)
        setContent { BlindTheme { App() } }
    }
}
