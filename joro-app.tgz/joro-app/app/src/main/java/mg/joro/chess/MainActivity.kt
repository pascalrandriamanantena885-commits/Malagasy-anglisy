package mg.joro.chess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import mg.joro.chess.match.Host
import mg.joro.chess.ui.App
import mg.joro.chess.ui.JoroTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Host.init(applicationContext)
        setContent { JoroTheme { App() } }
    }
}
