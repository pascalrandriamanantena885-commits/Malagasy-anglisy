package mg.joro.chess.match

import androidx.compose.runtime.getValue
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

class SpsaParam(val name: String, var value: Double, val min: Double, val max: Double, val cEnd: Double)

/** Lalao mivantana (Stockfish vs moteur) — ampiasain'ny tab "Live" */
object Live {
    var board by mutableStateOf(Board.fromFen(Board.START))
    var last by mutableStateOf<String?>(null)
    var moves by mutableStateOf(listOf<String>())
    var infoW by mutableStateOf("")
    var infoB by mutableStateOf("")
    var names by mutableStateOf(Pair("", ""))
    var status by mutableStateOf("")
    var w by mutableIntStateOf(0)   // A POV
    var d by mutableIntStateOf(0)
    var l by mutableIntStateOf(0)
    // lalao farany vita (ho an'ny Analyse)
    var lastStart by mutableStateOf(Board.START)
    var lastMoves by mutableStateOf(listOf<String>())
    var lastW by mutableStateOf("")
    var lastB by mutableStateOf("")
    var lastRes by mutableStateOf(Res.DRAW)
    var lastText by mutableStateOf("")
    var lastId by mutableStateOf<String?>(null)
}

/** Checkpoint: tehirizina isaky ny lalao/iteration mba ho azo tohizana rehefa nijanona ny app */
/** Angona ho an'ny graphique SPSA (curve θ isaky ny paramètre) */
object SpsaView {
    var names by mutableStateOf(listOf<String>())
    var mins by mutableStateOf(listOf<Double>())
    var maxs by mutableStateOf(listOf<Double>())
    var hist by mutableStateOf(listOf<List<Double>>())
    var rs by mutableStateOf(listOf<Double>())
}

object Ckpt {
    private var prefs: SharedPreferences? = null
    val pending = mutableStateOf<JSONObject?>(null)
    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("ckpt", Context.MODE_PRIVATE)
        pending.value = try { prefs?.getString("job", null)?.let { JSONObject(it) } } catch (_: Exception) { null }
    }
    fun save(j: JSONObject) { prefs?.edit()?.putString("job", j.toString())?.apply(); pending.value = j }
    fun clear() { prefs?.edit()?.remove("job")?.apply(); pending.value = null }
}

object Tasks {
    // ---------- JSON ----------
    private fun specJson(s: EngineSpec) = JSONObject().put("path", s.path).put("label", s.label).put("opts", JSONObject(s.options))
    private fun specOf(j: JSONObject): EngineSpec {
        val o = LinkedHashMap<String, String>()
        val oj = j.getJSONObject("opts")
        for (k in oj.keys()) o[k] = oj.getString(k)
        return EngineSpec(j.getString("path"), j.getString("label"), o)
    }
    private fun tcJson(t: TC) = JSONObject().put("ms", t.ms).put("mode", t.mode).put("base", t.base).put("inc", t.inc)
        .put("nodes", t.nodes).put("depth", t.depth)
    private fun tcOf(j: JSONObject) = TC(j.getInt("ms"), j.getString("mode"), j.getInt("base"), j.getInt("inc"), j.getLong("nodes"), j.getInt("depth"))

    fun newSprt(a: EngineSpec, b: EngineSpec, elo0: Double, elo1: Double, alpha: Double, beta: Double,
                maxGames: Int, tc: TC, seed: Long, profA: String, profB: String): JSONObject =
        JSONObject().put("type", "sprt").put("cfg", JSONObject().put("a", specJson(a)).put("b", specJson(b))
            .put("elo0", elo0).put("elo1", elo1).put("alpha", alpha).put("beta", beta).put("max", maxGames)
            .put("tc", tcJson(tc)).put("seed", seed).put("profA", profA).put("profB", profB))
            .put("prog", JSONObject().put("w", 0).put("d", 0).put("l", 0).put("g", 0))

    fun newMatrix(specs: List<EngineSpec>, gpp: Int, tc: TC, seed: Long): JSONObject =
        JSONObject().put("type", "matrix").put("cfg", JSONObject().put("specs", JSONArray(specs.map { specJson(it) }))
            .put("gpp", gpp).put("tc", tcJson(tc)).put("seed", seed)).put("prog", JSONObject().put("done", 0))

    fun newSpsa(base: EngineSpec, params: List<SpsaParam>, iters: Int, rEnd: Double, tc: TC, seed: Long, parent: String, pairs: Int = 1): JSONObject =
        JSONObject().put("type", "spsa").put("cfg", JSONObject().put("base", specJson(base))
            .put("params", JSONArray(params.map { JSONObject().put("name", it.name).put("init", it.value).put("min", it.min).put("max", it.max).put("cEnd", it.cEnd) }))
            .put("iters", iters).put("rEnd", rEnd).put("tc", tcJson(tc)).put("seed", seed).put("parent", parent).put("pairs", maxOf(1, pairs)))
            .put("prog", JSONObject().put("k", 0))

    fun newCalib(me: EngineSpec, sf: EngineSpec, levels: List<Int>, games: Int, tc: TC, seed: Long, profId: String): JSONObject =
        JSONObject().put("type", "calib").put("cfg", JSONObject().put("me", specJson(me)).put("sf", specJson(sf))
            .put("levels", JSONArray(levels)).put("games", games).put("tc", tcJson(tc)).put("seed", seed).put("profId", profId))
            .put("prog", JSONObject().put("li", 0).put("g", 0))

    fun title(j: JSONObject) = when (j.getString("type")) { "sprt" -> "SPRT"; "matrix" -> "Matrice"; "spsa" -> "SPSA"; else -> "Calibrage" }

    fun describe(j: JSONObject): String {
        val c = j.getJSONObject("cfg"); val p = j.getJSONObject("prog")
        return when (j.getString("type")) {
            "sprt" -> "SPRT: ${p.getInt("g")} lalao (+${p.getInt("w")} =${p.getInt("d")} -${p.getInt("l")})"
            "matrix" -> "Matrice: ${p.getInt("done")} lalao vita"
            "spsa" -> "SPSA: iteration ${p.getInt("k")}/${c.getInt("iters")}"
            else -> "Calibrage: haavo ${p.getInt("li") + 1}/${c.getJSONArray("levels").length()}, lalao ${p.getInt("g")}"
        }
    }

    /** Mandeha na mitohy ny asa avy amin'ny checkpoint JSON */
    suspend fun run(j: JSONObject) {
        Ckpt.save(j)
        when (j.getString("type")) {
            "sprt" -> sprt(j)
            "matrix" -> matrix(j)
            "spsa" -> spsa(j)
            else -> calibrate(j)
        }
        Ckpt.clear()
        val r = Host.report.value
        val now = System.currentTimeMillis()
        History.add(HistEntry(now.toString(), now, title(j), subject(j), tcOf(j.getJSONObject("cfg").getJSONObject("tc")).text(), r.headline, table(r.table)))
        Notifier.notify(title(j) + " vita", r.headline.lines().filter { it.isNotBlank() }.take(2).joinToString(" · "))
    }

    fun subject(j: JSONObject): String {
        val c = j.getJSONObject("cfg")
        return when (j.getString("type")) {
            "sprt" -> "${specOf(c.getJSONObject("a")).label} vs ${specOf(c.getJSONObject("b")).label}"
            "matrix" -> { val a = c.getJSONArray("specs"); (0 until a.length()).joinToString(" · ") { specOf(a.getJSONObject(it)).label } }
            "spsa" -> { val p = c.getJSONArray("params"); specOf(c.getJSONObject("base")).label + " · " + (0 until p.length()).joinToString(",") { p.getJSONObject(it).getString("name") } }
            else -> "${specOf(c.getJSONObject("me")).label} vs ${specOf(c.getJSONObject("sf")).label}"
        }
    }

    /** Lalao Live: A vs B, `games` lalao, mifandimby xolor. */
    suspend fun live(a: EngineSpec, b: EngineSpec, games: Int, tc: TC) {
        val pa = Player(a); val pb = Player(b)
        Live.w = 0; Live.d = 0; Live.l = 0
        try {
            pa.open(); pb.open()
            for (g in 0 until games) {
                val aWhite = g % 2 == 0
                val fen = Openings.fen(System.nanoTime() / 1000 + g, 2)
                Live.board = Board.fromFen(fen); Live.last = null; Live.moves = emptyList()
                Live.infoW = ""; Live.infoB = ""
                Live.names = if (aWhite) Pair(a.label, b.label) else Pair(b.label, a.label)
                Live.status = "Lalao ${g + 1}/$games"
                val white = if (aWhite) pa else pb
                val black = if (aWhite) pb else pa
                val ml = ArrayList<String>()
                val out = playGame(white.eng, black.eng, fen, tc,
                    onInfo = { c, i -> if (c == 0) Live.infoW = i.text() else Live.infoB = i.text() },
                    onPos = { bd, mv, _, _ -> ml.add(mv); Live.board = bd; Live.last = mv; Live.moves = ml.toList() })
                Live.lastStart = fen; Live.lastMoves = out.moves.toList()
                Live.lastW = Live.names.first; Live.lastB = Live.names.second
                Live.lastRes = if (out.score == 1.0) Res.WHITE else if (out.score == 0.0) Res.BLACK else Res.DRAW
                val tag = when (Live.lastRes) { Res.WHITE -> "1-0"; Res.BLACK -> "0-1"; else -> "1/2-1/2" }
                Live.lastText = "$tag (${out.reason})"
                if (out.moves.isNotEmpty())
                    Live.lastId = ReviewStore.addGame("Live", Live.lastW, Live.lastB, Live.lastText, Live.lastRes, fen, out.moves.toList(), false).id
                val sa = if (aWhite) out.score else 1 - out.score
                if (sa == 1.0) Live.w++ else if (sa == 0.0) Live.l++ else Live.d++
                Live.status = "Lalao ${g + 1}/$games vita: ${out.reason}"
            }
            Live.status = "Vita. +${Live.w} =${Live.d} -${Live.l}"
        } finally {
            pa.close(); pb.close()
        }
    }

    // ---------- SPRT ----------
    private suspend fun sprt(j: JSONObject) {
        val c = j.getJSONObject("cfg"); val pg = j.getJSONObject("prog")
        val a = specOf(c.getJSONObject("a")); val b = specOf(c.getJSONObject("b")); val tc = tcOf(c.getJSONObject("tc"))
        val elo0 = c.getDouble("elo0"); val elo1 = c.getDouble("elo1")
        val maxGames = c.getInt("max"); val seed = c.getLong("seed")
        val profA = c.optString("profA"); val profB = c.optString("profB")
        val (lo, hi) = Stats.llrBounds(c.getDouble("alpha"), c.getDouble("beta"))
        var w = pg.getInt("w"); var d = pg.getInt("d"); var l = pg.getInt("l"); var g = pg.getInt("g")
        val pa = Player(a); val pb = Player(b)
        val title = "SPRT [$elo0, $elo1] · ${tc.text()}"
        try {
            pa.open(); pb.open()
            var verdict = "Tsy vita (max lalao)"
            var ok: Boolean? = null
            while (g < maxGames) {
                val aWhite = g % 2 == 0
                val fen = Openings.fen(seed + g / 2)
                val out = if (aWhite) playGame(pa.eng, pb.eng, fen, tc) else playGame(pb.eng, pa.eng, fen, tc)
                val sa = if (aWhite) out.score else 1 - out.score
                if (sa == 1.0) w++ else if (sa == 0.0) l++ else d++
                g++
                pg.put("w", w).put("d", d).put("l", l).put("g", g); Ckpt.save(j)
                Host.log("#$g ${if (aWhite) "A-B" else "B-A"} ${out.reason} -> A $sa")
                val llr = Stats.llr(w, d, l, elo0, elo1)
                Host.post(title, "${a.label}\nvs ${b.label}\nlalao $g  +$w =$d -$l\nElo ${f1(Stats.elo(w, d, l))} ± ${f1(Stats.err95(w, d, l))}\nLLR ${f2(llr)}  [${f2(lo)} ; ${f2(hi)}]")
                if (llr >= hi) { verdict = "H1 ekena (A tsara kokoa)"; ok = true; break }
                if (llr <= lo) { verdict = "H0 ekena (A tsy tsara kokoa)"; ok = false; break }
            }
            if (profA.isNotEmpty() && profA != "base") {
                val txt = "${if (ok == true) "H1" else if (ok == false) "H0" else "?"} · Elo ${f1(Stats.elo(w, d, l))} ± ${f1(Stats.err95(w, d, l))} · $g lalao vs ${Profiles.get(profB)?.name ?: "base"} · ${tc.text()}"
                Profiles.update(profA) { it.copy(sprt = txt, sprtOk = ok) }
            }
            Host.post(title, "VITA: $verdict\nlalao $g  +$w =$d -$l\nElo ${f1(Stats.elo(w, d, l))} ± ${f1(Stats.err95(w, d, l))}\nLLR ${f2(Stats.llr(w, d, l, elo0, elo1))}")
        } finally { pa.close(); pb.close() }
    }

    // ---------- Matrice ----------
    private suspend fun matrix(j: JSONObject) {
        val c = j.getJSONObject("cfg"); val pg = j.getJSONObject("prog")
        val sa = c.getJSONArray("specs")
        val n = sa.length()
        val specs = (0 until n).map { specOf(sa.getJSONObject(it)) }.mapIndexed { i, s -> s.copy(label = "${i + 1}:${s.label}") }
        val gpp = c.getInt("gpp"); val tc = tcOf(c.getJSONObject("tc")); val seed = c.getLong("seed")
        val W = Array(n) { IntArray(n) }; val D = Array(n) { IntArray(n) }; val L = Array(n) { IntArray(n) }
        val wa = pg.optJSONArray("W")
        if (wa != null) {
            val da = pg.getJSONArray("D"); val la = pg.getJSONArray("L")
            for (i in 0 until n) for (k in 0 until n) { W[i][k] = wa.getInt(i * n + k); D[i][k] = da.getInt(i * n + k); L[i][k] = la.getInt(i * n + k) }
        }
        val skip = pg.optInt("done", 0)
        fun flat(m: Array<IntArray>) = JSONArray(m.flatMap { it.toList() })
        fun build(): List<List<String>> {
            val rows = ArrayList<List<String>>()
            rows.add(listOf("#", "Moteur") + (1..n).map { it.toString() } + listOf("Pts", "%", "Elo"))
            for (i in 0 until n) {
                var pts = 0.0; var gm = 0
                val cells = (0 until n).map { k ->
                    if (i == k) "·" else {
                        pts += W[i][k] + 0.5 * D[i][k]; gm += W[i][k] + D[i][k] + L[i][k]
                        "${W[i][k]}-${D[i][k]}-${L[i][k]}"
                    }
                }
                val pct = if (gm == 0) 0.5 else pts / gm
                rows.add(listOf("${i + 1}", specs[i].label.take(22)) + cells + listOf(f1(pts), f1(pct * 100), if (gm == 0) "-" else f1(Stats.scoreToElo(pct))))
            }
            return rows
        }
        val players = specs.map { Player(it) }
        val title = "Matrice · ${tc.text()}"
        try {
            players.forEach { it.open() }
            val total = n * (n - 1) / 2 * gpp
            var idx = 0
            for (i in 0 until n) for (k in i + 1 until n) for (g in 0 until gpp) {
                idx++
                if (idx <= skip) continue
                val iWhite = g % 2 == 0
                val fen = Openings.fen(seed + g / 2)
                val out = if (iWhite) playGame(players[i].eng, players[k].eng, fen, tc) else playGame(players[k].eng, players[i].eng, fen, tc)
                val si = if (iWhite) out.score else 1 - out.score
                if (si == 1.0) { W[i][k]++; L[k][i]++ } else if (si == 0.0) { L[i][k]++; W[k][i]++ } else { D[i][k]++; D[k][i]++ }
                pg.put("done", idx).put("W", flat(W)).put("D", flat(D)).put("L", flat(L)); Ckpt.save(j)
                Host.log("${i + 1} vs ${k + 1}: ${out.reason}")
                Host.post(title, "lalao $idx/$total  (W-D-L = fandresena-nul-resy, avy amin'ny andalana)", build())
            }
            Host.post(title, "VITA  ($total lalao)", build())
        } finally { players.forEach { it.close() } }
    }

    // ---------- SPSA ----------
    private suspend fun spsa(j: JSONObject) {
        val c = j.getJSONObject("cfg"); val pg = j.getJSONObject("prog")
        val base = specOf(c.getJSONObject("base")); val tc = tcOf(c.getJSONObject("tc"))
        val iters = c.getInt("iters"); val rEnd = c.getDouble("rEnd"); val seed = c.getLong("seed"); val parentId = c.optString("parent", "base")
        val pa = c.getJSONArray("params")
        val params = (0 until pa.length()).map {
            val o = pa.getJSONObject(it)
            SpsaParam(o.getString("name"), o.getDouble("init"), o.getDouble("min"), o.getDouble("max"), o.getDouble("cEnd"))
        }
        val th = pg.optJSONArray("theta")
        val theta = params.indices.map { if (th != null) th.getDouble(it) else params[it].value }.toMutableList()
        val init = params.map { it.value }
        val k0 = pg.optInt("k", 0)
        val pairs = c.optInt("pairs", 1)
        SpsaView.names = params.map { it.name }; SpsaView.mins = params.map { it.min }; SpsaView.maxs = params.map { it.max }
        val hj = pg.optJSONArray("hist")
        SpsaView.hist = if (hj != null) (0 until hj.length()).map { i -> val a = hj.getJSONArray(i); (0 until a.length()).map { a.getDouble(it) } } else listOf(theta.toList())
        val rj = pg.optJSONArray("rs")
        SpsaView.rs = if (rj != null) (0 until rj.length()).map { rj.getDouble(it) } else emptyList()
        val alpha = 0.602; val gamma = 0.101
        val bigA = 0.1 * iters
        val title = "SPSA · ${tc.text()}"
        fun opt(v: List<Double>) = params.indices.associate { params[it].name to Math.round(v[it]).toString() }
        val pp = Player(base); val pm = Player(base)
        try {
            pp.open(); pm.open()
            for (k in k0 + 1..iters) {
                val rnd = Random(seed + k * 7919L)
                val flip = params.map { if (rnd.nextBoolean()) 1.0 else -1.0 }
                val ck = params.map { it.cEnd * iters.toDouble().pow(gamma) / k.toDouble().pow(gamma) }
                val plus = params.indices.map { min(params[it].max, max(params[it].min, theta[it] + ck[it] * flip[it])) }
                val minus = params.indices.map { min(params[it].max, max(params[it].min, theta[it] - ck[it] * flip[it])) }
                pp.setAll(opt(plus)); pm.setAll(opt(minus))
                var pts = 0.0
                var why = ""
                for (pi in 0 until pairs) {                            // paires maro isaky ny iteration
                    val fen = Openings.fen(seed + k * 100L + pi)
                    val g1 = playGame(pp.eng, pm.eng, fen, tc)       // + blanc
                    val g2 = playGame(pm.eng, pp.eng, fen, tc)       // + noir
                    pts += g1.score + (1 - g2.score)
                    why = "${g1.reason} | ${g2.reason}"
                }
                val rr = pts / pairs - 1.0                           // -1..1
                for (i in params.indices) {
                    val cEnd = params[i].cEnd
                    val a = rEnd * (bigA + iters).pow(alpha) * cEnd * cEnd
                    val rk = a / (bigA + k).pow(alpha) / (ck[i] * ck[i])
                    theta[i] = min(params[i].max, max(params[i].min, theta[i] + ck[i] * rk * rr * flip[i]))
                }
                SpsaView.hist = SpsaView.hist + listOf(theta.toList())
                SpsaView.rs = SpsaView.rs + rr
                pg.put("k", k).put("theta", JSONArray(theta)).put("hist", JSONArray(SpsaView.hist.map { JSONArray(it) })).put("rs", JSONArray(SpsaView.rs))
                Ckpt.save(j)
                Host.log("k=$k  R=${f1(rr)}  $why")
                val rows = ArrayList<List<String>>()
                rows.add(listOf("param", "départ", "actuel", "c_k"))
                params.indices.forEach { rows.add(listOf(params[it].name, Math.round(init[it]).toString(), Math.round(theta[it]).toString(), f1(ck[it]))) }
                Host.post(title, "itération $k/$iters", rows)
            }
            val fin = params.indices.joinToString("\n") { "setoption name ${params[it].name} value ${Math.round(theta[it])}" }
            Host.log("=== RESULTAT ===\n$fin")
            val tuned = LinkedHashMap<String, String>(base.options)
            params.indices.forEach { tuned[params[it].name] = Math.round(theta[it]).toString() }
            val nm = Profiles.nextName()
            Profiles.add(Profile(System.currentTimeMillis().toString(), nm, tuned, parentId, "$iters itérations · ${tc.text()}"))
            Host.log("Profil '$nm' voatahiry (tab Pipeline)")
            Host.post(title, "VITA — profil '$nm' voatahiry. Soloy (setoption):\n$fin")
        } finally { pp.close(); pm.close() }
    }

    // ---------- Calibrage ----------
    private suspend fun calibrate(j: JSONObject) {
        val c = j.getJSONObject("cfg"); val pg = j.getJSONObject("prog")
        val me = specOf(c.getJSONObject("me")); val sf = specOf(c.getJSONObject("sf")); val tc = tcOf(c.getJSONObject("tc"))
        val la = c.getJSONArray("levels")
        val levels = (0 until la.length()).map { la.getInt(it) }
        val games = c.getInt("games"); val seed = c.getLong("seed"); val profId = c.optString("profId")
        val rows = ArrayList<List<String>>()
        val ra = pg.optJSONArray("rows")
        if (ra != null) for (i in 0 until ra.length()) { val r = ra.getJSONArray(i); rows.add((0 until r.length()).map { r.getString(it) }) }
        var num = pg.optDouble("num", 0.0); var den = pg.optDouble("den", 0.0)
        val startLi = pg.optInt("li", 0); val startG = pg.optInt("g", 0)
        val sw = pg.optInt("w", 0); val sd = pg.optInt("d", 0); val sl = pg.optInt("l", 0)
        val head = listOf("SF", "W-D-L", "Score", "Elo estimé")
        val title = "Calibrage · ${tc.text()}"
        val pm = Player(me); val ps = Player(sf)
        try {
            pm.open(); ps.open()
            val o = ps.eng.option("UCI_Elo")
            for (li in startLi until levels.size) {
                val lv0 = levels[li]
                val isMax = lv0 <= 0
                val lv = if (isMax) 0 else max(o?.min ?: 0, min(o?.max ?: 4000, lv0))
                val name = if (isMax) "Max" else lv.toString()
                if (isMax) ps.setAll(mapOf("UCI_LimitStrength" to "false"))
                else ps.setAll(mapOf("UCI_LimitStrength" to "true", "UCI_Elo" to lv.toString()))
                var w = if (li == startLi) sw else 0
                var d = if (li == startLi) sd else 0
                var l = if (li == startLi) sl else 0
                val g0 = if (li == startLi) startG else 0
                for (g in g0 until games) {
                    val meWhite = g % 2 == 0
                    val fen = Openings.fen(seed + g / 2)
                    val out = if (meWhite) playGame(pm.eng, ps.eng, fen, tc) else playGame(ps.eng, pm.eng, fen, tc)
                    val s = if (meWhite) out.score else 1 - out.score
                    if (s == 1.0) w++ else if (s == 0.0) l++ else d++
                    pg.put("li", li).put("g", g + 1).put("w", w).put("d", d).put("l", l); Ckpt.save(j)
                    val sc = (w + 0.5 * d) / (w + d + l)
                    val cur = ArrayList(rows)
                    cur.add(listOf(name, "$w-$d-$l", f1(sc * 100) + "%", if (isMax) "-" else f1(lv + Stats.scoreToElo(sc))))
                    Host.post(title, "SF $name : lalao ${g + 1}/$games", listOf(head) + cur)
                    Host.log("SF $name g${g + 1}: ${out.reason}")
                }
                val n = w + d + l
                val sc = if (n == 0) 0.5 else (w + 0.5 * d) / n
                if (!isMax && n > 0) {
                    val est = lv + Stats.scoreToElo(sc.coerceIn(0.02, 0.98))
                    val wt = n * sc * (1 - sc) + 1e-9
                    num += wt * est; den += wt
                }
                rows.add(listOf(name, "$w-$d-$l", f1(sc * 100) + "%", if (isMax) "-" else f1(lv + Stats.scoreToElo(sc))))
                pg.put("li", li + 1).put("g", 0).put("w", 0).put("d", 0).put("l", 0)
                    .put("rows", JSONArray(rows.map { JSONArray(it) })).put("num", num).put("den", den)
                Ckpt.save(j)
            }
            if (den > 0 && profId.isNotEmpty()) Profiles.update(profId) { it.copy(elo = num / den) }
            val baseElo = Profiles.get("base")?.elo
            val delta = if (den > 0 && profId != "base" && baseElo != null) "  (Δ vs base ${f1(num / den - baseElo)})" else ""
            val avg = if (den > 0) "Elo tombanana ≈ ${f1(num / den)}$delta" else "Elo tsy azo tombanana (tsy misy haavo voafetra)"
            Host.post(title, "VITA — $avg\n(miankina amin'ny time control ny UCI_Elo an'i Stockfish ; 'Max' dia tsy ampiasaina amin'ny Elo)", listOf(head) + rows)
        } finally { pm.close(); ps.close() }
    }

    suspend fun probeOptions(spec: EngineSpec): List<mg.joro.chess.uci.UciOption> {
        val e = mg.joro.chess.uci.UciEngine(spec.path)
        try { e.start(); return e.options.toList() } finally { e.close() }
    }
}
