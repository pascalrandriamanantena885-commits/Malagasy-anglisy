package mg.joro.chess.match

import androidx.compose.runtime.getValue
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/** Lalao mivantana (Stockfish vs moteur) — ampiasain'ny tab "Live" */
object Live {
    var board by mutableStateOf(Board.fromFen(Board.START))
    var last by mutableStateOf<String?>(null)
    var moves by mutableStateOf(listOf<String>())
    var infoW by mutableStateOf("")
    var infoB by mutableStateOf("")
    var names by mutableStateOf(Pair("", ""))
    var status by mutableStateOf("")
    var w by mutableIntStateOf(0)   // A POV
    var d by mutableIntStateOf(0)
    var l by mutableIntStateOf(0)
    // lalao farany vita (ho an'ny Analyse)
    var lastStart by mutableStateOf(Board.START)
    var lastMoves by mutableStateOf(listOf<String>())
    var lastW by mutableStateOf("")
    var lastB by mutableStateOf("")
    var lastRes by mutableStateOf(Res.DRAW)
    var lastText by mutableStateOf("")
    var lastId by mutableStateOf<String?>(null)
}

/** Checkpoint: tehirizina isaky ny lalao mba ho azo tohizana rehefa nijanona ny app */
object Ckpt {
    private var prefs: SharedPreferences? = null
    val pending = mutableStateOf<JSONObject?>(null)
    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("ckpt", Context.MODE_PRIVATE)
        val j = try { prefs?.getString("job", null)?.let { JSONObject(it) } } catch (_: Exception) { null }
        if (j != null && j.optString("type") == "spsa") { prefs?.edit()?.remove("job")?.apply(); pending.value = null }   // SPSA nesorina: foanana ny checkpoint taloha
        else pending.value = j
    }
    fun save(j: JSONObject) { prefs?.edit()?.putString("job", j.toString())?.apply(); pending.value = j }
    fun clear() { prefs?.edit()?.remove("job")?.apply(); pending.value = null }
}

object Tasks {
    // ---------- JSON ----------
    private fun specJson(s: EngineSpec) = JSONObject().put("path", s.path).put("label", s.label).put("opts", JSONObject(s.options))
    private fun specOf(j: JSONObject): EngineSpec {
        val o = LinkedHashMap<String, String>()
        val oj = j.getJSONObject("opts")
        for (k in oj.keys()) o[k] = oj.getString(k)
        return EngineSpec(j.getString("path"), j.getString("label"), o)
    }
    private fun tcJson(t: TC) = JSONObject().put("ms", t.ms).put("mode", t.mode).put("base", t.base).put("inc", t.inc)
        .put("nodes", t.nodes).put("depth", t.depth)
    private fun tcOf(j: JSONObject) = TC(j.getInt("ms"), j.getString("mode"), j.getInt("base"), j.getInt("inc"), j.getLong("nodes"), j.getInt("depth"))

    fun newSprt(a: EngineSpec, b: EngineSpec, elo0: Double, elo1: Double, alpha: Double, beta: Double,
                maxGames: Int, tc: TC, seed: Long, profA: String, profB: String, workers: Int = 1): JSONObject =
        JSONObject().put("type", "sprt").put("cfg", JSONObject().put("a", specJson(a)).put("b", specJson(b))
            .put("elo0", elo0).put("elo1", elo1).put("alpha", alpha).put("beta", beta).put("max", maxGames)
            .put("tc", tcJson(tc)).put("seed", seed).put("profA", profA).put("profB", profB).put("workers", workers))
            .put("prog", JSONObject().put("w", 0).put("d", 0).put("l", 0).put("g", 0))

    fun newMatrix(specs: List<EngineSpec>, gpp: Int, tc: TC, seed: Long): JSONObject =
        JSONObject().put("type", "matrix").put("cfg", JSONObject().put("specs", JSONArray(specs.map { specJson(it) }))
            .put("gpp", gpp).put("tc", tcJson(tc)).put("seed", seed)).put("prog", JSONObject().put("done", 0))

    fun newCalib(me: EngineSpec, sf: EngineSpec, levels: List<Int>, games: Int, tc: TC, seed: Long, profId: String): JSONObject =
        JSONObject().put("type", "calib").put("cfg", JSONObject().put("me", specJson(me)).put("sf", specJson(sf))
            .put("levels", JSONArray(levels)).put("games", games).put("tc", tcJson(tc)).put("seed", seed).put("profId", profId))
            .put("prog", JSONObject().put("li", 0).put("g", 0))

    fun title(j: JSONObject) = when (j.getString("type")) { "sprt" -> "SPRT"; "matrix" -> "Matrice"; else -> "Calibrage" }

    fun describe(j: JSONObject): String {
        val c = j.getJSONObject("cfg"); val p = j.getJSONObject("prog")
        return when (j.getString("type")) {
            "sprt" -> "SPRT: ${p.getInt("g")} lalao (+${p.getInt("w")} =${p.getInt("d")} -${p.getInt("l")})"
            "matrix" -> "Matrice: ${p.getInt("done")} lalao vita"
            else -> "Calibrage: haavo ${p.getInt("li") + 1}/${c.getJSONArray("levels").length()}, lalao ${p.getInt("g")}"
        }
    }

    /** Mandeha na mitohy ny asa avy amin'ny checkpoint JSON */
    suspend fun run(j: JSONObject) {
        Ckpt.save(j)
        when (j.getString("type")) {
            "sprt" -> sprt(j)
            "matrix" -> matrix(j)
            else -> calibrate(j)
        }
        Ckpt.clear()
        val r = Host.report.value
        val now = System.currentTimeMillis()
        History.add(HistEntry(now.toString(), now, title(j), subject(j), tcOf(j.getJSONObject("cfg").getJSONObject("tc")).text(), r.headline, table(r.table)))
        Notifier.notify(title(j) + " vita", r.headline.lines().filter { it.isNotBlank() }.take(2).joinToString(" · "))
    }

    fun subject(j: JSONObject): String {
        val c = j.getJSONObject("cfg")
        return when (j.getString("type")) {
            "sprt" -> "${specOf(c.getJSONObject("a")).label} vs ${specOf(c.getJSONObject("b")).label}"
            "matrix" -> { val a = c.getJSONArray("specs"); (0 until a.length()).joinToString(" · ") { specOf(a.getJSONObject(it)).label } }
            else -> "${specOf(c.getJSONObject("me")).label} vs ${specOf(c.getJSONObject("sf")).label}"
        }
    }

    /** Lalao Live: A vs B, `games` lalao, mifandimby xolor. */
    suspend fun live(a: EngineSpec, b: EngineSpec, games: Int, tc: TC) {
        val pa = Player(a); val pb = Player(b)
        Live.w = 0; Live.d = 0; Live.l = 0
        try {
            pa.open(); pb.open()
            for (g in 0 until games) {
                val aWhite = g % 2 == 0
                val fen = Openings.fen(System.nanoTime() / 1000 + g, 2)
                Live.board = Board.fromFen(fen); Live.last = null; Live.moves = emptyList()
                Live.infoW = ""; Live.infoB = ""
                Live.names = if (aWhite) Pair(a.label, b.label) else Pair(b.label, a.label)
                Live.status = "Lalao ${g + 1}/$games"
                val white = if (aWhite) pa else pb
                val black = if (aWhite) pb else pa
                val ml = ArrayList<String>()
                val out = playGame(white.eng, black.eng, fen, tc,
                    onInfo = { c, i -> if (c == 0) Live.infoW = i.text() else Live.infoB = i.text() },
                    onPos = { bd, mv, _, _ -> ml.add(mv); Live.board = bd; Live.last = mv; Live.moves = ml.toList() })
                Live.lastStart = fen; Live.lastMoves = out.moves.toList()
                Live.lastW = Live.names.first; Live.lastB = Live.names.second
                Live.lastRes = if (out.score == 1.0) Res.WHITE else if (out.score == 0.0) Res.BLACK else Res.DRAW
                val tag = when (Live.lastRes) { Res.WHITE -> "1-0"; Res.BLACK -> "0-1"; else -> "1/2-1/2" }
                Live.lastText = "$tag (${out.reason})"
                if (out.moves.isNotEmpty())
                    Live.lastId = ReviewStore.addGame("Live", Live.lastW, Live.lastB, Live.lastText, Live.lastRes, fen, out.moves.toList(), false).id
                val sa = if (aWhite) out.score else 1 - out.score
                if (sa == 1.0) Live.w++ else if (sa == 0.0) Live.l++ else Live.d++
                Live.status = "Lalao ${g + 1}/$games vita: ${out.reason}"
            }
            Live.status = "Vita. +${Live.w} =${Live.d} -${Live.l}"
        } finally {
            pa.close(); pb.close()
        }
    }

    // ---------- SPRT (parallèle: `workers` lalao miaraka) ----------
    private class Duo(val a: Player, val b: Player)

    private suspend fun sprt(j: JSONObject) {
        val c = j.getJSONObject("cfg"); val pg = j.getJSONObject("prog")
        val a = specOf(c.getJSONObject("a")); val b = specOf(c.getJSONObject("b")); val tc = tcOf(c.getJSONObject("tc"))
        val elo0 = c.getDouble("elo0"); val elo1 = c.getDouble("elo1")
        val maxGames = c.getInt("max"); val seed = c.getLong("seed")
        val profA = c.optString("profA"); val profB = c.optString("profB")
        val workers = ParSprt.clampWorkers(c.optInt("workers", 1))
        val (lo, hi) = Stats.llrBounds(c.getDouble("alpha"), c.getDouble("beta"))
        val start = SprtCounts(pg.getInt("w"), pg.getInt("d"), pg.getInt("l"))
        val title = "SPRT [$elo0, $elo1] · ${tc.text()} · $workers miaraka"
        val out = ParSprt.run<Duo>(
            workers, maxGames, start, elo0, elo1, lo, hi,
            open = { val d = Duo(Player(a), Player(b)); try { d.a.open(); d.b.open() } catch (e: Throwable) { d.a.close(); d.b.close(); throw e }; d },
            close = { it.a.close(); it.b.close() },
            play = { duo, g ->
                val aWhite = g % 2 == 0
                val fen = Openings.fen(seed + g / 2)
                val o = if (aWhite) playGame(duo.a.eng, duo.b.eng, fen, tc) else playGame(duo.b.eng, duo.a.eng, fen, tc)
                Pair(if (aWhite) o.score else 1 - o.score, "${if (aWhite) "A-B" else "B-A"} ${o.reason}")
            },
            onProgress = { cn, g, llr, reason ->
                pg.put("w", cn.w).put("d", cn.d).put("l", cn.l).put("g", cn.g); Ckpt.save(j)
                Host.log("#${g + 1} $reason")
                Host.post(title, "${a.label}\nvs ${b.label}\nlalao ${cn.g}  +${cn.w} =${cn.d} -${cn.l}\nElo ${f1(Stats.elo(cn.w, cn.d, cn.l))} ± ${f1(Stats.err95(cn.w, cn.d, cn.l))}\nLLR ${f2(llr)}  [${f2(lo)} ; ${f2(hi)}]")
            }
        )
        val cn = out.counts
        if (profA.isNotEmpty() && profA != "base") {
            val txt = "${if (out.ok == true) "H1" else if (out.ok == false) "H0" else "?"} · Elo ${f1(Stats.elo(cn.w, cn.d, cn.l))} ± ${f1(Stats.err95(cn.w, cn.d, cn.l))} · ${cn.g} lalao vs ${Profiles.get(profB)?.name ?: "base"} · ${tc.text()}"
            Profiles.update(profA) { it.copy(sprt = txt, sprtOk = out.ok) }
        }
        Host.post(title, "VITA: ${out.verdict}\nlalao ${cn.g}  +${cn.w} =${cn.d} -${cn.l}\nElo ${f1(Stats.elo(cn.w, cn.d, cn.l))} ± ${f1(Stats.err95(cn.w, cn.d, cn.l))}\nLLR ${f2(Stats.llr(cn.w, cn.d, cn.l, elo0, elo1))}")
    }

    // ---------- Matrice ----------
    private suspend fun matrix(j: JSONObject) {
        val c = j.getJSONObject("cfg"); val pg = j.getJSONObject("prog")
        val sa = c.getJSONArray("specs")
        val n = sa.length()
        val specs = (0 until n).map { specOf(sa.getJSONObject(it)) }.mapIndexed { i, s -> s.copy(label = "${i + 1}:${s.label}") }
        val gpp = c.getInt("gpp"); val tc = tcOf(c.getJSONObject("tc")); val seed = c.getLong("seed")
        val W = Array(n) { IntArray(n) }; val D = Array(n) { IntArray(n) }; val L = Array(n) { IntArray(n) }
        val wa = pg.optJSONArray("W")
        if (wa != null) {
            val da = pg.getJSONArray("D"); val la = pg.getJSONArray("L")
            for (i in 0 until n) for (k in 0 until n) { W[i][k] = wa.getInt(i * n + k); D[i][k] = da.getInt(i * n + k); L[i][k] = la.getInt(i * n + k) }
        }
        val skip = pg.optInt("done", 0)
        fun flat(m: Array<IntArray>) = JSONArray(m.flatMap { it.toList() })
        fun build(): List<List<String>> {
            val rows = ArrayList<List<String>>()
            rows.add(listOf("#", "Moteur") + (1..n).map { it.toString() } + listOf("Pts", "%", "Elo"))
            for (i in 0 until n) {
                var pts = 0.0; var gm = 0
                val cells = (0 until n).map { k ->
                    if (i == k) "·" else {
                        pts += W[i][k] + 0.5 * D[i][k]; gm += W[i][k] + D[i][k] + L[i][k]
                        "${W[i][k]}-${D[i][k]}-${L[i][k]}"
                    }
                }
                val pct = if (gm == 0) 0.5 else pts / gm
                rows.add(listOf("${i + 1}", specs[i].label.take(22)) + cells + listOf(f1(pts), f1(pct * 100), if (gm == 0) "-" else f1(Stats.scoreToElo(pct))))
            }
            return rows
        }
        val players = specs.map { Player(it) }
        val title = "Matrice · ${tc.text()}"
        try {
            players.forEach { it.open() }
            val total = n * (n - 1) / 2 * gpp
            var idx = 0
            for (i in 0 until n) for (k in i + 1 until n) for (g in 0 until gpp) {
                idx++
                if (idx <= skip) continue
                val iWhite = g % 2 == 0
                val fen = Openings.fen(seed + g / 2)
                val out = if (iWhite) playGame(players[i].eng, players[k].eng, fen, tc) else playGame(players[k].eng, players[i].eng, fen, tc)
                val si = if (iWhite) out.score else 1 - out.score
                if (si == 1.0) { W[i][k]++; L[k][i]++ } else if (si == 0.0) { L[i][k]++; W[k][i]++ } else { D[i][k]++; D[k][i]++ }
                pg.put("done", idx).put("W", flat(W)).put("D", flat(D)).put("L", flat(L)); Ckpt.save(j)
                Host.log("${i + 1} vs ${k + 1}: ${out.reason}")
                Host.post(title, "lalao $idx/$total  (W-D-L = fandresena-nul-resy, avy amin'ny andalana)", build())
            }
            Host.post(title, "VITA  ($total lalao)", build())
        } finally { players.forEach { it.close() } }
    }

    // ---------- Calibrage ----------
    private suspend fun calibrate(j: JSONObject) {
        val c = j.getJSONObject("cfg"); val pg = j.getJSONObject("prog")
        val me = specOf(c.getJSONObject("me")); val sf = specOf(c.getJSONObject("sf")); val tc = tcOf(c.getJSONObject("tc"))
        val la = c.getJSONArray("levels")
        val levels = (0 until la.length()).map { la.getInt(it) }
        val games = c.getInt("games"); val seed = c.getLong("seed"); val profId = c.optString("profId")
        val rows = ArrayList<List<String>>()
        val ra = pg.optJSONArray("rows")
        if (ra != null) for (i in 0 until ra.length()) { val r = ra.getJSONArray(i); rows.add((0 until r.length()).map { r.getString(it) }) }
        var num = pg.optDouble("num", 0.0); var den = pg.optDouble("den", 0.0)
        val startLi = pg.optInt("li", 0); val startG = pg.optInt("g", 0)
        val sw = pg.optInt("w", 0); val sd = pg.optInt("d", 0); val sl = pg.optInt("l", 0)
        val head = listOf("SF", "W-D-L", "Score", "Elo estimé")
        val title = "Calibrage · ${tc.text()}"
        val pm = Player(me); val ps = Player(sf)
        try {
            pm.open(); ps.open()
            val o = ps.eng.option("UCI_Elo")
            for (li in startLi until levels.size) {
                val lv0 = levels[li]
                val isMax = lv0 <= 0
                val lv = if (isMax) 0 else max(o?.min ?: 0, min(o?.max ?: 4000, lv0))
                val name = if (isMax) "Max" else lv.toString()
                if (isMax) ps.setAll(mapOf("UCI_LimitStrength" to "false"))
                else ps.setAll(mapOf("UCI_LimitStrength" to "true", "UCI_Elo" to lv.toString()))
                var w = if (li == startLi) sw else 0
                var d = if (li == startLi) sd else 0
                var l = if (li == startLi) sl else 0
                val g0 = if (li == startLi) startG else 0
                for (g in g0 until games) {
                    val meWhite = g % 2 == 0
                    val fen = Openings.fen(seed + g / 2)
                    val out = if (meWhite) playGame(pm.eng, ps.eng, fen, tc) else playGame(ps.eng, pm.eng, fen, tc)
                    val s = if (meWhite) out.score else 1 - out.score
                    if (s == 1.0) w++ else if (s == 0.0) l++ else d++
                    pg.put("li", li).put("g", g + 1).put("w", w).put("d", d).put("l", l); Ckpt.save(j)
                    val sc = (w + 0.5 * d) / (w + d + l)
                    val cur = ArrayList(rows)
                    cur.add(listOf(name, "$w-$d-$l", f1(sc * 100) + "%", if (isMax) "-" else f1(lv + Stats.scoreToElo(sc))))
                    Host.post(title, "SF $name : lalao ${g + 1}/$games", listOf(head) + cur)
                    Host.log("SF $name g${g + 1}: ${out.reason}")
                }
                val n = w + d + l
                val sc = if (n == 0) 0.5 else (w + 0.5 * d) / n
                if (!isMax && n > 0) {
                    val est = lv + Stats.scoreToElo(sc.coerceIn(0.02, 0.98))
                    val wt = n * sc * (1 - sc) + 1e-9
                    num += wt * est; den += wt
                }
                rows.add(listOf(name, "$w-$d-$l", f1(sc * 100) + "%", if (isMax) "-" else f1(lv + Stats.scoreToElo(sc))))
                pg.put("li", li + 1).put("g", 0).put("w", 0).put("d", 0).put("l", 0)
                    .put("rows", JSONArray(rows.map { JSONArray(it) })).put("num", num).put("den", den)
                Ckpt.save(j)
            }
            if (den > 0 && profId.isNotEmpty()) Profiles.update(profId) { it.copy(elo = num / den) }
            val baseElo = Profiles.get("base")?.elo
            val delta = if (den > 0 && profId != "base" && baseElo != null) "  (Δ vs base ${f1(num / den - baseElo)})" else ""
            val avg = if (den > 0) "Elo tombanana ≈ ${f1(num / den)}$delta" else "Elo tsy azo tombanana (tsy misy haavo voafetra)"
            Host.post(title, "VITA — $avg\n(miankina amin'ny time control ny UCI_Elo an'i Stockfish ; 'Max' dia tsy ampiasaina amin'ny Elo)", listOf(head) + rows)
        } finally { pm.close(); ps.close() }
    }

    suspend fun probeOptions(spec: EngineSpec): List<mg.joro.chess.uci.UciOption> {
        val e = mg.joro.chess.uci.UciEngine(spec.path)
        try { e.start(); return e.options.toList() } finally { e.close() }
    }
}
