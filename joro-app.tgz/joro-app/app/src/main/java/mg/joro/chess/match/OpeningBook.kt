package mg.joro.chess.match

import mg.joro.chess.chess.Board
import kotlin.random.Random

class OpeningInfo(val eco: String, val name: String) {
    fun label() = "$eco · $name"
}

/** Andalana iray ao amin'ny book ofisialy: hetsika UCI hatramin'ny farany + key an'ny toerana aorian'ny ply tsirairay */
class BookLine(
    val eco: String, val name: String,
    val ucis: List<String>, val keys: List<String>, val fen: String,
    val san: String = ""                      // hetsika SAN tsy misy laharana ("e4 c5 Nf3")
) {
    fun info() = OpeningInfo(eco, name)
}

/** Ouverture voafidy ho an'ny lalao: `fen` + `prefix` (hetsika UCI alohan'ny hisafidianan'ny moteur) */
class OpenPick(val fen: String, val prefix: List<String>, val info: OpeningInfo?) {
    fun label(): String = info?.label() ?: if (prefix.isEmpty()) "-" else prefix.joinToString(" ")
}

/**
 * Book ouverture ofisialy (ECO): assets/openings*.tsv  (eco <TAB> anarana <TAB> hetsika SAN).
 * Mekena ihany koa ny format Lichess `chess-openings` (header `eco name pgn`, a.tsv..e.tsv): apetraho ao amin'ny assets
 * (anarana manomboka amin'ny `openings` sy mifarana amin'ny `.tsv`) ary ampiana ho azy.
 * Toerana anaty "book" = toerana rehetra eo amin'ny lalana hatrany amin'ny ouverture voalaza.
 */
object OpeningBook {
    private var named = HashMap<String, OpeningInfo>()
    private var inBook = HashSet<String>()
    private var all: List<BookLine> = emptyList()
    private var loaded = false
    var skipped = 0
        private set

    /** Famakiana madio (tsy miankina amin'ny Android): mamerina andalana nahomby + isan'ny andalana diso */
    fun parse(text: String): Pair<List<BookLine>, Int> {
        val out = ArrayList<BookLine>()
        val seen = HashSet<String>()
        var skip = 0
        for (raw in text.lines()) {
            val line = raw.trimEnd('\r', '\n')
            if (line.isBlank() || line.startsWith("#")) continue
            val f = line.split('\t')
            if (f.size >= 3 && f[0].trim().equals("eco", ignoreCase = true)) continue   // header Lichess
            if (f.size < 3) { skip++; continue }
            val toks = f[2].trim().split(Regex("\\s+"))
                .map { it.replace(Regex("^\\d+\\.+"), "") }
                .filter { it.isNotEmpty() }
            var b = Board.fromFen(Board.START)
            val ucis = ArrayList<String>()
            val keys = ArrayList<String>()
            var valid = true
            for (t in toks) {
                val m = b.parseSan(t)
                if (m == null) { valid = false; break }
                ucis.add(b.uci(m))
                b = b.play(m)
                keys.add(b.key())
            }
            if (!valid || keys.isEmpty()) { skip++; continue }
            if (!seen.add(ucis.joinToString(" "))) continue           // andalana mitovy: tsy averina
            out.add(BookLine(f[0].trim(), f[1].trim(), ucis, keys, b.toFen(), toks.joinToString(" ")))
        }
        return Pair(out, skip)
    }

    /** Mamaky ny tabilao; mamerina ny isan'ny andalana nahomby */
    @Synchronized
    fun load(text: String): Int {
        val (lines, skip) = parse(text)
        val nm = HashMap<String, OpeningInfo>()
        val bk = HashSet<String>()
        for (l in lines) {
            bk.addAll(l.keys)
            if (!nm.containsKey(l.keys.last())) nm[l.keys.last()] = l.info()
        }
        named = nm; inBook = bk; all = lines; skipped = skip; loaded = true
        return lines.size
    }

    @Synchronized
    private fun ensure() {
        if (loaded) return
        try {
            val ctx = Host.ctx
            val files = (ctx.assets.list("") ?: emptyArray())
                .filter { it.startsWith("openings") && it.endsWith(".tsv") }
                .sortedWith(compareBy({ it != "openings.tsv" }, { it }))      // openings.tsv aloha
            val sb = StringBuilder()
            for (f in files) { ctx.assets.open(f).bufferedReader().use { sb.append(it.readText()).append('\n') } }
            load(sb.toString())
        } catch (_: Throwable) {
            loaded = true
        }
    }

    /** Isan'ny ouverture ofisialy voakajy (miandry raha mbola mamaky) */
    fun size(): Int { ensure(); return all.size }

    /** true rehefa vita ny famakiana (ho an'ny UI tsy tokony hiandry) */
    fun isReady(): Boolean = loaded

    /** Fikarohana ao amin'ny book (ECO na anarana; teny maro = rehetra tsy maintsy ao): fohy indrindra aloha */
    fun search(q: String, limit: Int = 8): List<BookLine> {
        val words = q.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        ensure()
        return all.filter { l -> val h = (l.eco + " " + l.name).lowercase(); words.all { it in h } }
            .sortedBy { it.ucis.size }.take(limit)
    }

    /** Ouverture ofisialy iray, voafidy araka ny `seed` (mitovy foana ho an'ny seed iray: ampiasaina ho an'ny paire xolor) */
    fun pick(seed: Long): BookLine? {
        ensure()
        val l = all
        return if (l.isEmpty()) null else l[Random(seed).nextInt(l.size)]
    }

    /**
     * Hetsika (UCI) manomboka amin'ny startFen hatramin'ny faran'ny andalana rehetra ao amin'ny tabilao izay mandalo
     * amin'io toerana io (ohatra defense rehetra aorian'ny 1.e4). Lisitra iray misy lisitra foana raha tsy hita.
     */
    fun continuations(startFen: String): List<List<String>> {
        val key = try { Board.fromFen(startFen).key() } catch (_: Exception) { return listOf(emptyList()) }
        ensure()
        val startKey = Board.fromFen(Board.START).key()
        val out = LinkedHashMap<String, List<String>>()
        for (l in all) {
            val hit = if (startKey == key) 0 else l.keys.indexOf(key) + 1       // 0 = tsy hita (indexOf -1 + 1)
            if (startKey != key && hit == 0) continue
            val cont = l.ucis.subList(hit, l.ucis.size).toList()
            out[cont.joinToString(" ")] = cont
        }
        val l = out.values.filter { it.isNotEmpty() }
        return if (l.isEmpty()) listOf(emptyList()) else l
    }

    /** key = Board.key() */
    fun isBook(key: String): Boolean { ensure(); return key in inBook }
    fun name(key: String): OpeningInfo? { ensure(); return named[key] }
}
