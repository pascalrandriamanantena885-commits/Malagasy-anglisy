package mg.joro.chess.match

import mg.joro.chess.chess.Board

class OpeningInfo(val eco: String, val name: String) {
    fun label() = "$eco · $name"
}

/**
 * Base ouverture kely (assets/openings.tsv : eco <TAB> anarana <TAB> hetsika SAN).
 * Toerana anaty "book" = toerana rehetra eo amin'ny lalana hatrany amin'ny ouverture voalaza.
 */
object OpeningBook {
    private var named = HashMap<String, OpeningInfo>()
    private var inBook = HashSet<String>()
    private var loaded = false
    var skipped = 0
        private set

    /** Mamaky ny tabilao; mamerina ny isan'ny andalana nahomby */
    @Synchronized
    fun load(text: String): Int {
        val nm = HashMap<String, OpeningInfo>()
        val bk = HashSet<String>()
        var skip = 0
        var ok = 0
        for (raw in text.lines()) {
            val line = raw.trimEnd('\r', '\n')
            if (line.isBlank() || line.startsWith("#")) continue
            val f = line.split('\t')
            if (f.size < 3) { skip++; continue }
            val toks = f[2].trim().split(Regex("\\s+"))
                .map { it.replace(Regex("^\\d+\\.+"), "") }
                .filter { it.isNotEmpty() }
            var b = Board.fromFen(Board.START)
            val keys = ArrayList<String>()
            var valid = true
            for (t in toks) {
                val m = b.parseSan(t)
                if (m == null) { valid = false; break }
                b = b.play(m)
                keys.add(b.key())
            }
            if (!valid || keys.isEmpty()) { skip++; continue }
            bk.addAll(keys)
            if (!nm.containsKey(keys.last())) nm[keys.last()] = OpeningInfo(f[0], f[1])
            ok++
        }
        named = nm; inBook = bk; skipped = skip; loaded = true
        return ok
    }

    private fun ensure() {
        if (loaded) return
        try {
            Host.ctx.assets.open("openings.tsv").bufferedReader().use { load(it.readText()) }
        } catch (_: Throwable) {
            loaded = true
        }
    }

    /**
     * Hetsika (UCI) manomboka amin'ny startFen hatramin'ny faran'ny andalana rehetra ao amin'ny tabilao izay mandalo
     * amin'io toerana io (ohatra defense rehetra aorian'ny 1.e4). Lisitra iray misy lisitra foana raha tsy hita.
     */
    fun continuations(startFen: String): List<List<String>> {
        val key = try { Board.fromFen(startFen).key() } catch (_: Exception) { return listOf(emptyList()) }
        val text = try { Host.ctx.assets.open("openings.tsv").bufferedReader().use { it.readText() } } catch (_: Throwable) { return listOf(emptyList()) }
        val out = LinkedHashMap<String, List<String>>()
        for (raw in text.lines()) {
            val line = raw.trimEnd('\r', '\n')
            if (line.isBlank() || line.startsWith("#")) continue
            val f = line.split('\t')
            if (f.size < 3) continue
            val toks = f[2].trim().split(Regex("\\s+")).map { it.replace(Regex("^\\d+\\.+"), "") }.filter { it.isNotEmpty() }
            var b = Board.fromFen(Board.START)
            val ucis = ArrayList<String>()
            var hit = if (b.key() == key) 0 else -1
            var valid = true
            for (t in toks) {
                val m = b.parseSan(t)
                if (m == null) { valid = false; break }
                ucis.add(b.uci(m))
                b = b.play(m)
                if (hit < 0 && b.key() == key) hit = ucis.size
            }
            if (!valid || hit < 0) continue
            val cont: List<String> = ucis.subList(hit, ucis.size).toList()
            out[cont.joinToString(" ")] = cont
        }
        val l = out.values.filter { it.isNotEmpty() }
        return if (l.isEmpty()) listOf(emptyList()) else l
    }

    /** key = Board.key() */
    fun isBook(key: String): Boolean { ensure(); return key in inBook }
    fun name(key: String): OpeningInfo? { ensure(); return named[key] }
}
