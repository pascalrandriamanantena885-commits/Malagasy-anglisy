package mg.joro.chess.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PermanentDrawerSheet
import androidx.compose.material3.PermanentNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import mg.joro.chess.BuildConfig
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import mg.joro.chess.match.*
import org.json.JSONObject

// =====================================================================================
// Firafitry ny app (organisation)
//
//  Tab (Nav.tab):  0 Milalao · 1 Live · 2 Review · 3 Training · 4 Fitsapana · 5 Moteur · 6 Update · 7 Réglages
//  Bara ambany (5 faritra):  Lalao(0,1) · Review(2) · Training(3) · Fitsapana(4) · Moteur(5,6,7)
//  Menu (☰ / drawer ankavia, hita foana amin'ny efijery lehibe): mampiseho ny pejy rehetra voakambana
//  Ao amin'ny Fitsapana: Nav.sub  0 Pipeline · 1 SPRT · 2 Matrice · 3 Calibrage · 4 Tantara
// =====================================================================================
private class Dest(val label: String, val glyph: String, val tab: Int, val sub: Int = -1)

private val GROUPS: List<Pair<String, List<Dest>>> = listOf(
    "Lalao" to listOf(Dest("Milalao vs Blind", "♞", 0), Dest("Live · Stockfish vs Blind", "▶", 1)),
    "Analyse" to listOf(Dest("Review", "◎", 2), Dest("Training", "⚔", 3)),
    "Fitsapana" to listOf(
        Dest("Pipeline", "Σ", 4, 0), Dest("SPRT", "≋", 4, 1), Dest("Matrice", "▦", 4, 2),
        Dest("Calibrage", "◐", 4, 3), Dest("Tantara", "☰", 4, 4)
    ),
    "Moteur" to listOf(Dest("Moteur", "⚙", 5), Dest("Update", "⬇", 6)),
    "Fanamafisana" to listOf(Dest("Réglages", "✦", 7))
)

private val SECTIONS = listOf("Lalao" to "♞", "Review" to "◎", "Training" to "⚔", "Fitsapana" to "Σ", "Moteur" to "⚙")
private val SECTION_TAB = listOf(0, 2, 3, 4, 5)
private fun sectionOf(tab: Int): Int = when (tab) { 0, 1 -> 0; 2 -> 1; 3 -> 2; 4 -> 3; else -> 4 }

private fun titleFor(tab: Int): String = when (tab) {
    0 -> "Milalao"; 1 -> "Live"; 2 -> "Review"; 3 -> "Training"; 4 -> "Fitsapana"
    5 -> "Moteur"; 6 -> "Update"; else -> "Réglages"
}

@Composable
fun App() {
    val scope = rememberCoroutineScope()
    CrashDialog()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 840.dp
        val go: (Dest) -> Unit = { d ->
            Nav.tab = d.tab
            if (d.sub >= 0) Nav.sub = d.sub
            if (!wide) scope.launch { drawer.close() }
        }
        val shell: @Composable () -> Unit = { Shell(wide) { scope.launch { drawer.open() } } }
        if (wide) {
            PermanentNavigationDrawer(
                drawerContent = { PermanentDrawerSheet(Modifier.width(290.dp)) { DrawerBody(go) } },
                content = shell
            )
        } else {
            ModalNavigationDrawer(
                drawerState = drawer,
                drawerContent = { ModalDrawerSheet { DrawerBody(go) } },
                content = shell
            )
        }
    }
}

@Composable
private fun DrawerBody(onGo: (Dest) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BrandMark(40.dp)
            Column {
                Text("Blind", style = MaterialTheme.typography.titleLarge)
                Caption("Chess · v${BuildConfig.VERSION_NAME}")
            }
        }
        GROUPS.forEach { (group, items) ->
            Text(group.uppercase(), Modifier.padding(start = 12.dp, top = 14.dp, bottom = 4.dp),
                fontSize = 12.sp, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant, letterSpacing = 1.2.sp)
            items.forEach { d ->
                val sel = d.tab == Nav.tab && (d.sub < 0 || d.sub == Nav.sub)
                NavigationDrawerItem(
                    label = { Text(d.label) },
                    selected = sel,
                    onClick = { onGo(d) },
                    icon = { Text(d.glyph, fontSize = 18.sp) },
                    modifier = Modifier.padding(vertical = 2.dp),
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = cs.primaryContainer,
                        selectedTextColor = cs.onPrimaryContainer,
                        selectedIconColor = cs.onPrimaryContainer
                    )
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Shell(wide: Boolean, onMenu: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tab = Nav.tab
    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BrandMark(30.dp)
                        Column {
                            Text("BLIND", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = cs.primary, letterSpacing = 1.6.sp)
                            Text(titleFor(tab), style = MaterialTheme.typography.titleMedium, maxLines = 1)
                        }
                    }
                },
                navigationIcon = {
                    if (!wide) IconButton(onClick = onMenu) { Text("☰", fontSize = 22.sp) }
                },
                actions = {
                    if (Host.running.value) Pill("● mandeha", Modifier.padding(end = 4.dp))
                    IconButton(onClick = { UiPrefs.updateDark(!UiPrefs.dark) }) { Text(if (UiPrefs.dark) "☀" else "☾", fontSize = 20.sp) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background)
            )
        },
        bottomBar = { if (!wide) BottomNav(tab) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0, 1 -> SubNav(listOf("♞ Vs Blind", "▶ Live"), tab) { Nav.tab = it }
                5, 6, 7 -> SubNav(listOf("⚙ Moteur", "⬇ Update", "✦ Réglages"), tab - 5) { Nav.tab = it + 5 }
                else -> {}
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> PlayScreen(); 1 -> LiveScreen(); 2 -> AnalysisScreen(); 3 -> TrainingScreen()
                    4 -> TestsScreen(); 5 -> EnginesScreen(); 6 -> UpdateScreen(); else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun SubNav(items: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
        Box(Modifier.widthIn(max = 820.dp).fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 6.dp)) {
            SegTabs(items, selected, onSelect = onSelect)
        }
    }
}

@Composable
private fun BottomNav(tab: Int) {
    val cs = MaterialTheme.colorScheme
    NavigationBar(containerColor = cs.surfaceContainerLow) {
        SECTIONS.forEachIndexed { i, s ->
            NavigationBarItem(
                selected = sectionOf(tab) == i,
                onClick = { if (sectionOf(tab) != i) Nav.tab = SECTION_TAB[i] },
                icon = { Text(s.second, fontSize = 20.sp) },
                label = { Text(s.first, fontSize = 12.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = cs.primaryContainer,
                    selectedIconColor = cs.onPrimaryContainer,
                    selectedTextColor = cs.primary
                )
            )
        }
    }
}

// ---------- fampiasa iombonana ----------
@Composable
fun Field(label: String, st: MutableState<String>, num: Boolean = false) {
    OutlinedTextField(
        value = st.value, onValueChange = { st.value = it }, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = if (num) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default
    )
}

/** Safidy dropdown: soratra kely ambony + bokotra misy ny sanda ankehitriny */
@Composable
private fun PickerBox(label: String, value: String, open: Boolean, setOpen: (Boolean) -> Unit, menu: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Caption(label)
        Box {
            OutlinedButton(onClick = { setOpen(true) }, modifier = Modifier.fillMaxWidth()) {
                Text(value, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("▾")
            }
            DropdownMenu(expanded = open, onDismissRequest = { setOpen(false) }, content = menu)
        }
    }
}

@Composable
fun EnginePicker(label: String, sel: MutableState<String>) {
    var open by remember { mutableStateOf(false) }
    val cur = Host.pick(sel.value)
    PickerBox(label, cur?.name ?: "(tsy misy moteur)", open, { open = it }) {
        Host.engines.forEach { e -> DropdownMenuItem(text = { Text(e.name) }, onClick = { sel.value = e.id; open = false }) }
    }
}

@Composable
fun ReportPanel() {
    val r = Host.report.value
    if (r.title.isEmpty() && !Host.running.value) return
    Panel("Tatitra" + (if (r.title.isNotEmpty()) " · ${r.title}" else ""), glyph = "▤", collapsible = false) {
        if (r.headline.isNotEmpty()) Text(r.headline, fontWeight = FontWeight.SemiBold)
        if (r.table.isNotEmpty()) Text(table(r.table), fontFamily = FontFamily.Monospace, fontSize = 13.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState()))
        r.log.takeLast(12).forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (Host.running.value) Button(onClick = { Host.stop() }) { Text("■ Atsaharo") }
    }
}

@Composable
fun ThemeToggle() {
    TextButton(onClick = { UiPrefs.setBoard(1 - Host.boardTheme.value) }) { Text("Loko board: ${if (Host.boardTheme.value == 0) "gris" else "marron"}") }
}

/** Andalana hetsika (1. e4 e5): ampiasaina amin'ny Milalao / Live / Review */
@Composable
internal fun MovePairRow(num: Int, a: String, b: String?, selA: Boolean, selB: Boolean, onA: () -> Unit, onB: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("$num.", Modifier.width(34.dp), fontSize = 14.sp, fontFamily = FontFamily.Monospace, color = cs.onSurfaceVariant)
        Text(a, Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (selA) cs.primaryContainer else Color.Transparent)
            .clickable { onA() }.padding(horizontal = 8.dp, vertical = 5.dp),
            fontSize = 15.sp, fontFamily = FontFamily.Monospace, fontWeight = if (selA) FontWeight.Bold else FontWeight.Normal)
        if (b != null) Text(b, Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (selB) cs.primaryContainer else Color.Transparent)
            .clickable { onB() }.padding(horizontal = 8.dp, vertical = 5.dp),
            fontSize = 15.sp, fontFamily = FontFamily.Monospace, fontWeight = if (selB) FontWeight.Bold else FontWeight.Normal)
        else Spacer(Modifier.weight(1f))
    }
}

// ---------- Player vs moteur ----------
private fun fmtClock(ms: Int): String {
    val s = maxOf(0, ms) / 1000
    return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
}

@Composable
private fun ClockPill(glyph: String, time: String, active: Boolean, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier.clip(MaterialTheme.shapes.medium).background(if (active) cs.primaryContainer else cs.surfaceContainerHigh).padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(glyph, fontSize = 18.sp)
        Text(time, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 22.sp,
            color = if (active) cs.onPrimaryContainer else cs.onSurface)
    }
}

@Composable
fun PlayScreen() {
    val eng = remember { mutableStateOf("") }
    val prof = remember { mutableStateOf("@default") }
    val opts = remember { mutableStateOf("") }
    val imp = remember { mutableStateOf("") }
    var side by remember { mutableIntStateOf(0) }
    var flip by remember { mutableStateOf(false) }
    Play.rev // mamaky ny rev mba hamerenana ny composition
    val g = Play.game
    if (g != null) {
        TwoPane(
            left = { PlayBoardPane(flip) { flip = !flip } },
            right = { PlaySetupPane(eng, prof, opts, imp, side) { side = it } }
        )
    } else {
        ScreenColumn {
            EmptyState("Mbola tsy misy lalao. Safidio ny moteur ary tsindrio “Lalao vaovao”.", "♞")
            PlaySetupPane(eng, prof, opts, imp, side) { side = it }
        }
    }
    if (Play.pendingPromo.isNotEmpty()) {
        androidx.compose.material3.AlertDialog(onDismissRequest = { Play.pendingPromo = emptyList() }, confirmButton = {},
            title = { Text("Promotion") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("♕" to 5, "♖" to 4, "♗" to 3, "♘" to 2).forEach { (sym, p) -> Button(onClick = { Play.promote(p) }) { Text(sym, fontSize = 20.sp) } }
                }
            })
    }
}

@Composable
private fun PlayBoardPane(flip: Boolean, onFlip: () -> Unit) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Play.rev
    val g = Play.game ?: return
    val viewing = Play.viewPly >= 0
    val shown = Play.viewBoard ?: g.board
    val lastMv = if (viewing) g.moves.getOrNull(Play.viewPly - 1) else g.moves.lastOrNull()
    Panel("Lalao", glyph = "♞", collapsible = false) {
        if (Play.tc.clocked) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ClockPill("⚪", fmtClock(Play.wClock), g.board.stm == 0, Modifier.weight(1f))
            ClockPill("⚫", fmtClock(Play.bClock), g.board.stm == 1, Modifier.weight(1f))
        }
        BoardView(shown, if (Play.human == 1) !flip else flip, if (viewing) -1 else Play.selected,
            if (viewing) emptySet() else Play.targets, lastMv, onTap = { Play.tap(it) })
        val statusTxt = Play.status.ifEmpty { if (Play.thinking) "Mieritreritra... ${Play.info}" else if (g.board.stm == Play.human) "Anao ny tonga" else "" }
        if (statusTxt.isNotEmpty()) Text(statusTxt, fontWeight = FontWeight.SemiBold, color = cs.primary)
        if (viewing) Button(onClick = { Play.view(Int.MAX_VALUE) }, modifier = Modifier.fillMaxWidth()) { Text("Miverina amin'ny lalao ankehitriny") }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onFlip) { Text("⇅ Vadiho") }
            OutlinedButton(onClick = { Play.undo() }) { Text("↶ Undo") }
            OutlinedButton(onClick = { Play.resign() }) { Text("⚑ Miala") }
            OutlinedButton(onClick = {
                clip.setText(AnnotatedString(Play.pgn())); Toast.makeText(ctx, "PGN voakopia", Toast.LENGTH_SHORT).show()
            }) { Text("PGN") }
            ThemeToggle()
        }
        val sg = Play.savedId?.let { ReviewStore.get(it) }
        if (g.result != Res.ONGOING && sg != null) Button(modifier = Modifier.fillMaxWidth(), onClick = {
            Analysis.openSaved(sg)
            Nav.tab = 2   // tab Review
        }) { Text(if (sg.reviewed) "📊 Jereo ny review" else "📊 Review lalao") }
    }
    val pairs = Play.sans.chunked(2).withIndex().toList()
    if (pairs.isNotEmpty()) Panel("Hetsika", subtitle = "${Play.sans.size} ply · tsindrio mba hijery toerana", glyph = "☰", startOpen = true) {
        val focusPair = (if (viewing) Play.viewPly - 1 else Play.sans.size - 1).coerceAtLeast(0) / 2
        PagedItems(pairs, showToggle = false, pageSize = 10, spacing = 2.dp, focusIndex = focusPair) { iv, _ ->
            val i = iv.index
            val pair = iv.value
            MovePairRow(i + 1, pair[0], pair.getOrNull(1), Play.viewPly == i * 2 + 1, Play.viewPly == i * 2 + 2,
                { Play.view(i * 2 + 1) }, { Play.view(i * 2 + 2) })
        }
    }
}

@Composable
private fun PlaySetupPane(
    eng: MutableState<String>, prof: MutableState<String>, opts: MutableState<String>, imp: MutableState<String>,
    side: Int, onSide: (Int) -> Unit
) {
    val ctx = LocalContext.current
    val fresh = Play.game == null
    Panel("Mpifanandrina", subtitle = "Moteur, profil ary options", glyph = "⚙", startOpen = fresh) {
        EnginePicker("Moteur", eng)
        ProfilePicker("Profil Blind", prof, true)
        Field("Options (Nom=val;Nom2=val2)", opts)
    }
    Panel("Lalao vaovao", subtitle = "Fotoana, position fototra, sisiny", glyph = "＋", startOpen = fresh) {
        TcPicker(Nav.playTc, listOf("movetime" to "Movetime", "tc" to "Base+Inc"))
        Field("FEN na PGN (azo ahafahana)", imp)
        Caption("Ny sisinao")
        SegTabs(listOf("⚪ Fotsy", "⚫ Mainty"), side) { onSide(it) }
        Button(modifier = Modifier.fillMaxWidth(), onClick = {
            val txt = imp.value.trim()
            var initial: PgnLine? = null
            var bad = false
            if (txt.isNotEmpty()) {
                initial = if (txt.contains('[') || Regex("\\b1\\.").containsMatchIn(txt)) Pgn.movesOf(txt)
                else try { Board.fromFen(txt); PgnLine(txt, emptyList(), txt) } catch (_: Exception) { null }
                bad = initial == null
            }
            if (bad) Toast.makeText(ctx, "FEN/PGN diso", Toast.LENGTH_SHORT).show()
            else Host.spec(eng.value, opts.value, prof.value)?.let { Play.start(it, side, Nav.playTc.toTC(), initial) }
        }) { Text("▶ Lalao vaovao") }
    }
}

// ---------- Stockfish vs moteur live ----------
@Composable
fun LiveScreen() {
    val a = remember { mutableStateOf("") }
    val b = remember { mutableStateOf("stockfish") }
    val oa = remember { mutableStateOf("") }
    val ob = remember { mutableStateOf("") }
    val strength = remember { mutableStateOf("2000") }
    val pa = remember { mutableStateOf("@default") }
    val pb = remember { mutableStateOf("base") }
    val games = remember { mutableStateOf("10") }
    TwoPane(
        left = {
            Panel("Lalao mivantana", glyph = "▶", collapsible = false) {
                BoardView(Live.board, false, -1, emptySet(), Live.last, onTap = {})
                Text("⚪ ${Live.names.first}  ${Live.infoW}", fontSize = 14.sp)
                Text("⚫ ${Live.names.second}  ${Live.infoB}", fontSize = 14.sp)
                Text("${Live.status}   A: +${Live.w} =${Live.d} -${Live.l}", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                ThemeToggle()
                val lg = Live.lastId?.let { ReviewStore.get(it) }
                if (lg != null) Button(modifier = Modifier.fillMaxWidth(), onClick = {
                    Analysis.openSaved(lg)
                    Nav.tab = 2   // tab Review
                }) { Text(if (lg.reviewed) "📊 Jereo ny review (lalao farany)" else "📊 Review lalao farany") }
                if (ReviewStore.games.isNotEmpty()) OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { Nav.tab = 2 }) {
                    Text("Lalao rehetra voatahiry (${ReviewStore.games.size})")
                }
            }
            val pairs = Live.moves.chunked(2).withIndex().toList()
            if (pairs.isNotEmpty()) Panel("Hetsika", glyph = "☰", startOpen = false) {
                PagedItems(pairs, showToggle = false, pageSize = 10, spacing = 2.dp, focusIndex = pairs.size - 1) { iv, _ ->
                    val pair = iv.value
                    MovePairRow(iv.index + 1, pair[0].toString(), pair.getOrNull(1)?.toString(), false, false, {}, {})
                }
            }
        },
        right = {
            Panel("Moteur A", subtitle = "Blind (na moteur hafa)", glyph = "A", startOpen = true) {
                EnginePicker("A (moteur)", a); ProfilePicker("Profil A", pa, true); Field("Options A", oa)
            }
            Panel("Moteur B", subtitle = "Stockfish", glyph = "B", startOpen = true) {
                EnginePicker("B (Stockfish)", b); ProfilePicker("Profil B (Blind)", pb)
                StrengthPicker("Hery Stockfish (Elo)", strength); Field("Options B (fanampiny)", ob)
            }
            Panel("Fanombohana", glyph = "⏱", startOpen = true) {
                TestSettings(); Field("Isan'ny lalao", games, true)
                Caption("Ny opening rehetra dia avy amin'ny book ofisialy (ECO, ${if (OpeningBook.isReady()) OpeningBook.size().toString() else "…"} ouverture): iray isaky ny paire (mitovy ny lalao roa miova xolor), aseho ao amin'ny status. Tsy ampiasaina ny opening anatiny an'ny Blind.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !Host.running.value, onClick = {
                        val sa = Host.spec(a.value, oa.value, pa.value); val sb = Host.spec(b.value, joinOpts(ob.value, strengthOpts(strength.value)), pb.value)
                        if (sa != null && sb != null) Host.launch("Live") {
                            Tasks.live(sa, sb, games.value.toIntOrNull() ?: 1, Nav.tc.toTC())
                        }
                    }) { Text("▶ Start") }
                    if (Host.running.value) OutlinedButton(onClick = { Host.stop() }) { Text("■ Atsaharo") }
                }
            }
        }
    )
}

// ---------- Fitsapana: Pipeline / SPRT / Matrice / Calibrage ----------
class Slot { val sel = mutableStateOf(""); val opts = mutableStateOf("") }

@Composable
fun TestsScreen() {
    val sub = Nav.sub
    val names = listOf("Σ Pipeline", "≋ SPRT", "▦ Matrice", "◐ Calibrage", "☰ Tantara")
    ScreenColumn {
        SegTabs(names, sub) { Nav.sub = it }
        ResumeBanner()
        when (sub) {
            0 -> PipelineScreen()
            1 -> Panel("SPRT", subtitle = "Moteur A (vaovao) vs B (base)", glyph = "≋", collapsible = false) { SprtForm() }
            2 -> Panel("Matrice", subtitle = "Moteur maromaro mifanandrina", glyph = "▦", collapsible = false) { MatrixForm() }
            3 -> Panel("Calibrage", subtitle = "Elo vs Stockfish", glyph = "◐", collapsible = false) { CalibForm() }
            else -> HistoryScreen()
        }
        ReportPanel()
    }
}

@Composable
fun SprtForm() {
    val a = remember { mutableStateOf("") }; val b = remember { mutableStateOf("") }
    val oa = remember { mutableStateOf("") }; val ob = remember { mutableStateOf("") }
    val e0 = remember { mutableStateOf("0") }; val e1 = remember { mutableStateOf("5") }
    val al = remember { mutableStateOf("0.05") }; val be = remember { mutableStateOf("0.05") }
    val mg = remember { mutableStateOf("400") }
    val par = remember { mutableStateOf("2") }
    EnginePicker("A (vaovao)", a); ProfilePicker("Profil A", Nav.sprtA); Field("Options A", oa)
    EnginePicker("B (base)", b); ProfilePicker("Profil B", Nav.sprtB); Field("Options B", ob)
    Field("Elo0", e0); Field("Elo1", e1); Field("alpha", al); Field("beta", be)
    Field("Lalao max", mg, true)
    Field("Lalao miaraka (parallèle, 1..${ParSprt.clampWorkers(64)})", par, true); TestSettings()
    Button(modifier = Modifier.fillMaxWidth(), enabled = !Host.running.value, onClick = {
        val sa = Host.spec(a.value, oa.value, Nav.sprtA.value); val sb = Host.spec(b.value, ob.value, Nav.sprtB.value)
        if (sa != null && sb != null) {
            val job = Tasks.newSprt(sa, sb, e0.value.toDoubleOrNull() ?: 0.0, e1.value.toDoubleOrNull() ?: 5.0,
                al.value.toDoubleOrNull() ?: 0.05, be.value.toDoubleOrNull() ?: 0.05,
                mg.value.toIntOrNull() ?: 400, Nav.tc.toTC(), System.nanoTime() % 100000,
                Nav.sprtA.value, Nav.sprtB.value, ParSprt.clampWorkers(par.value.toIntOrNull() ?: 2))
            Host.launch("SPRT") { Tasks.run(job) }
        }
    }) { Text("▶ Start SPRT") }
}

@Composable
fun MatrixForm() {
    val slots = remember { mutableStateListOf(Slot(), Slot()) }
    val gp = remember { mutableStateOf("10") }
    slots.forEachIndexed { i, s -> EnginePicker("Moteur ${i + 1}", s.sel); Field("Options ${i + 1}", s.opts) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { if (slots.size < 8) slots.add(Slot()) }) { Text("+ moteur") }
        OutlinedButton(onClick = { if (slots.size > 2) slots.removeAt(slots.size - 1) }) { Text("− moteur") }
    }
    Field("Lalao isaky ny paire", gp, true); TestSettings()
    Button(modifier = Modifier.fillMaxWidth(), enabled = !Host.running.value, onClick = {
        val specs = slots.mapNotNull { Host.spec(it.sel.value, it.opts.value) }
        if (specs.size >= 2) {
            val job = Tasks.newMatrix(specs, gp.value.toIntOrNull() ?: 10, Nav.tc.toTC(), System.nanoTime() % 100000)
            Host.launch("Matrice") { Tasks.run(job) }
        }
    }) { Text("▶ Start matrice") }
}

@Composable
fun CalibForm() {
    val a = remember { mutableStateOf("") }; val s = remember { mutableStateOf("stockfish") }
    val oa = remember { mutableStateOf("") }; val os = remember { mutableStateOf("") }
    val chosen = remember { mutableStateListOf("1500", "2000", "2500") }
    val extra = remember { mutableStateOf("") }
    val gm = remember { mutableStateOf("20") }
    EnginePicker("Moteur", a); ProfilePicker("Profil", Nav.calibP); Field("Options moteur", oa)
    EnginePicker("Stockfish", s); Field("Options Stockfish (fanampiny)", os)
    LevelPicker(chosen, extra); Field("Lalao isaky ny haavo", gm, true); TestSettings()
    Caption("Opening: avy amin'ny book ofisialy ECO (${if (OpeningBook.isReady()) OpeningBook.size().toString() else "…"} ouverture), tsy aléatoire, tsy opening anatiny an'ny Blind; mitovy ny lalao roa miova xolor.")
    Button(modifier = Modifier.fillMaxWidth(), enabled = !Host.running.value, onClick = {
        val sa = Host.spec(a.value, oa.value, Nav.calibP.value); val ss = Host.spec(s.value, os.value)
        val levels = (chosen.toList() + extra.value.split(',')).mapNotNull { x ->
            val t = x.trim().lowercase()
            if (t == "max") 0 else t.toIntOrNull()
        }.distinct().sortedBy { if (it == 0) Int.MAX_VALUE else it }
        if (sa != null && ss != null && levels.isNotEmpty()) {
            val job = Tasks.newCalib(sa, ss, levels, gm.value.toIntOrNull() ?: 20, Nav.tc.toTC(), System.nanoTime() % 100000, Nav.calibP.value)
            Host.launch("Calibrage") { Tasks.run(job) }
        }
    }) { Text("▶ Start calibrage") }
}

// ---------- Moteur: import / export / delete / compile cloud ----------
@Composable
fun EnginesScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val repo = remember { mutableStateOf(prefs.getString("repo", BuildConfig.GITHUB_REPO) ?: BuildConfig.GITHUB_REPO) }
    val token = remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    val flags = remember { mutableStateOf("-O3 -std=c++17") }
    var pending by remember { mutableStateOf<Pair<mg.joro.chess.uci.EngineEntry, String>?>(null) }
    val msg = Host.importMsg

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Host.scope.launch {
            try {
                msg.value = "Mamaky..."
                when (val o = Host.store.import(uri)) {
                    is mg.joro.chess.uci.Installed -> { Host.refresh(); msg.value = "OK: ${o.entry.name}" }
                    is mg.joro.chess.uci.NeedsCompile -> {
                        prefs.edit().putString("repo", repo.value.trim()).putString("token", token.value.trim()).apply()
                        val f = CloudBuild.compile(ctx, o.file, o.name, o.name.substringBeforeLast('.'), flags.value) { st -> msg.value = st }
                        val e = Host.store.installBinary(f, o.name.substringBeforeLast('.'))
                        Host.refresh(); msg.value = "Compile + import OK: ${e.name}"
                    }
                }
            } catch (ex: Exception) { msg.value = "Diso: ${ex.message}" }
        }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val pe = pending
        if (uri != null && pe != null) Host.scope.launch {
            msg.value = try { Host.store.export(pe.first, pe.second, uri); "Export OK (${pe.second})" } catch (ex: Exception) { "Export diso: ${ex.message}" }
        }
    }
    val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "abi"

    ScreenColumn {
        Panel("Moteur voapetraka", subtitle = "${Host.engines.size} moteur · import / export / fafana", glyph = "⚙", collapsible = false) {
            Button(modifier = Modifier.fillMaxWidth(), onClick = { picker.launch(arrayOf("*/*")) }) { Text("⬆ Import: ELF · .zip · .tgz · .cpp") }
            if (msg.value.isNotEmpty()) Text(msg.value, color = MaterialTheme.colorScheme.primary)
            PagedItems(Host.engines.toList(), pageSize = UiPrefs.pageSize, emptyText = "Mbola tsy misy moteur.") { en, compact ->
                HoverCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(en.name, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, maxLines = 2)
                        if (en.builtin) Pill("integré")
                    }
                    if (!compact) Caption(en.path)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { pending = en to "zip"; saver.launch(mg.joro.chess.uci.Pack.safeName(en.name) + "-$abi.zip") }) { Text(".zip") }
                        OutlinedButton(onClick = { pending = en to "tgz"; saver.launch(mg.joro.chess.uci.Pack.safeName(en.name) + "-$abi.tgz") }) { Text(".tgz") }
                        if (!en.builtin) OutlinedButton(onClick = { Host.store.delete(en); Host.refresh() }) { Text("Fafao") }
                    }
                }
            }
        }
        Panel("Compile cloud", subtitle = "Ho an'ny source .cpp", glyph = "☁", startOpen = false) {
            Caption("Tsy misy compiler ao amin'ny finday. Ny source .cpp (na .zip/.tgz misy source) dia alefa any amin'ny GitHub repo-nao (PUBLIC), " +
                "ny workflow compile-engine.yml no mamorona ny binaire, ary ampidinin'ny app ho moteur. Mila token (Contents + Actions: read/write).")
            Field("Repo GitHub (owner/repo)", repo)
            OutlinedTextField(token.value, { x -> token.value = x }, label = { Text("Token GitHub") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Field("Flags compile", flags)
            OutlinedButton(onClick = { prefs.edit().putString("repo", repo.value.trim()).putString("token", token.value.trim()).apply(); msg.value = "Voatahiry" }) { Text("Tahiry") }
        }
    }
}

// ---------- Update version ----------
@Composable
fun UpdateScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val repo = remember { mutableStateOf(prefs.getString("repo", BuildConfig.GITHUB_REPO) ?: BuildConfig.GITHUB_REPO) }
    var msg by remember { mutableStateOf("") }
    var rel by remember { mutableStateOf<Release?>(null) }
    val scope = rememberCoroutineScope()
    ScreenColumn {
        Panel("Version", glyph = "⬇", collapsible = false) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Version ankehitriny", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                Pill("v${BuildConfig.VERSION_NAME}")
            }
            Field("Repo GitHub (owner/repo)", repo)
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                prefs.edit().putString("repo", repo.value).apply()
                msg = "Mijery..."
                scope.launch {
                    msg = try {
                        val r = Updater.latest(repo.value.trim()); rel = r
                        if (Updater.isNewer(r.tag, BuildConfig.VERSION_NAME)) "Version vaovao: ${r.tag}" else "Efa vaovao ny app (${r.tag})"
                    } catch (ex: Exception) { "Diso: ${ex.message}" }
                }
            }) { Text("Hamarino ny update") }
            if (msg.isNotEmpty()) Text(msg, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            val r = rel
            if (r != null && r.apkUrl != null && Updater.isNewer(r.tag, BuildConfig.VERSION_NAME)) {
                if (r.notes.isNotBlank()) Text(r.notes, fontSize = 14.sp)
                Button(modifier = Modifier.fillMaxWidth(), onClick = {
                    scope.launch {
                        try {
                            val f = Updater.download(ctx, r.apkUrl) { p -> msg = "Download $p%" }
                            Updater.install(ctx, f)
                        } catch (ex: Exception) { msg = "Diso: ${ex.message}" }
                    }
                }) { Text("⬇ Alaina sy apetraho ${r.tag}") }
            }
        }
        Caption("Ny update dia mitondra moteur Blind vaovao ao anatiny. Ny moteur nalaina avy any ivelany (Stockfish...) dia tsy miova.")
    }
}

// ---------- Réglages ----------
@Composable
fun SettingsScreen() {
    val sizes = listOf(4, 6, 10, 20)
    ScreenColumn {
        CrashPanel()
        Panel("Theme", subtitle = "Mahaleo tena: tsy manaraka ny light/dark an'ny finday", glyph = "◐", collapsible = false) {
            SegTabs(listOf("☾ Maizina", "☀ Mazava"), if (UiPrefs.dark) 0 else 1) { UiPrefs.updateDark(it == 0) }
            Caption("Voatahiry ao amin'ny app; tsy miova raha mivadika ny mode an'ny finday.")
        }
        Panel("Board", subtitle = "Loko ny efitra", glyph = "♞", collapsible = false) {
            SegTabs(listOf("Gris", "Marron"), Host.boardTheme.value) { UiPrefs.setBoard(it) }
        }
        Panel("Lisitra & pejy", subtitle = "Pagination sy fomba fisehoana", glyph = "☰", collapsible = false) {
            Caption("Isan'ny zavatra isaky ny pejy")
            SegTabs(sizes.map { it.toString() }, sizes.indexOf(UiPrefs.pageSize)) { UiPrefs.updatePageSize(sizes[it]) }
            Caption("Fisehoana (lisitra lava)")
            SegTabs(listOf("☰ Lisitra", "▦ Grid"), if (UiPrefs.grid) 1 else 0) { UiPrefs.updateGrid(it == 1) }
        }
        Panel("Momba ny app", glyph = "ⓘ", collapsible = false) {
            Text("Blind Chess · v${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.titleSmall)
            Caption("Moteur UCI: Blind (integré) · Stockfish (integré) · import moteur hafa.")
        }
    }
}

// ---------- safidy hery Stockfish ----------
fun strengthOpts(s: String): String = if (s == "max") "" else "UCI_LimitStrength=true;UCI_Elo=$s"
fun joinOpts(a: String, b: String): String = listOf(a, b).filter { it.isNotBlank() }.joinToString(";")

@Composable
fun StrengthPicker(label: String, sel: MutableState<String>) {
    val custom = remember { mutableStateOf("") }
    val presets = listOf("1500", "2000", "2500", "2700", "3100", "max")
    Caption(label)
    SegTabs(presets.map { if (it == "max") "Max" else it }, presets.indexOf(sel.value)) { sel.value = presets[it]; custom.value = "" }
    OutlinedTextField(
        value = custom.value,
        onValueChange = { x -> custom.value = x.filter { c -> c.isDigit() }; if (custom.value.isNotEmpty()) sel.value = custom.value },
        label = { Text("Elo hafa (1320-3190)  ·  voafidy: ${if (sel.value == "max") "Max" else sel.value}") },
        singleLine = true, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
fun LevelPicker(chosen: SnapshotStateList<String>, extra: MutableState<String>) {
    Caption("Haavon'ny Stockfish hanaovana calibrage (azo fidina maromaro)")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("1320", "1500", "1800", "2000", "2200", "2500", "2700", "3000", "3100", "max").forEach { p ->
            FilterChip(selected = p in chosen, onClick = { if (p in chosen) chosen.remove(p) else chosen.add(p) },
                label = { Text(if (p == "max") "Max" else p) })
        }
    }
    Field("Haavo hafa (virgule, ex: 2350,2900)", extra)
}

// ---------- Profils + Pipeline ----------
@Composable
fun ProfilePicker(label: String, sel: MutableState<String>, allowDefault: Boolean = false) {
    var open by remember { mutableStateOf(false) }
    val cur = if (sel.value == "@default") Profiles.get(Profiles.defaultId) else (Profiles.get(sel.value) ?: Profiles.get("base"))
    PickerBox(label, (if (sel.value == "@default") "★ default → " else "") + (cur?.name ?: "base"), open, { open = it }) {
        if (allowDefault) DropdownMenuItem(text = { Text("★ default (${Profiles.get(Profiles.defaultId)?.name ?: "base"})") },
            onClick = { sel.value = "@default"; open = false })
        Profiles.list.forEach { p ->
            DropdownMenuItem(text = { Text(p.name + if (p.id == Profiles.defaultId) " (default)" else "") },
                onClick = { sel.value = p.id; open = false })
        }
    }
}

@Composable
fun PipelineScreen() {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val baseElo = Profiles.get("base")?.elo
    Panel("Pipeline", subtitle = "1 Training → 2 SPRT → 3 Calibrage opening → 4 Update moteur → 5 Calibrage → 6 Release", glyph = "Σ", startOpen = false) {
        Text("Ny Training no mamorona ny profil isaky ny opening (provisoire). Ny SPRT dia atao ao amin'ny Training ihany (provisoire vs taloha); " +
            "raha H1 dia atao ho azy ny Calibrage opening (Blind vs Stockfish, lalao manomboka amin'ny opening + defense ao amin'ny book ofisialy; azo atao an-tanana amin'ny ◐). " +
            "Ny SPRT H1 ihany no mamaritra ny \"✔ Update moteur\" (ny calibrage dia fampahalalana), avy eo Calibrage ankapobeny. " +
            "Ho an'ny Release: Copier ny profil moteur → default_profile.txt, ary Copier profil Training nekena → default_oprofiles.txt (app/src/main/assets/) → commit → git tag vX.Y.Z → Release → Update.", fontSize = 14.sp)
    }

    // ---- 1-3: profil Training (isaky ny opening) ----
    Panel("Profil Training", subtitle = "Isaky ny opening · ${OProfiles.list.size} profil", glyph = "⚔") {
        if (OProfiles.list.any { it.active.isNotEmpty() }) OutlinedButton(onClick = {
            clip.setText(AnnotatedString(OProfiles.exportRelease()))
            Toast.makeText(ctx, "Voakopia: apetaho ao amin'ny assets/default_oprofiles.txt", Toast.LENGTH_LONG).show()
        }) { Text("📋 Copier profil Training nekena (release)") }
        PagedItems(OProfiles.list.toList(),
            emptyText = "Mbola tsy misy. Mankanesa ao amin'ny Training: mifidiana opening, mihetsika, 'Alaina ny lanja' ary 'Apply'.") { op, compact ->
            HoverCard(spacing = 3.dp) {
                Text("${op.name}  (${OProfiles.sideWord(op.side)})", style = MaterialTheme.typography.titleSmall)
                Text("1 Training: provisoire ${op.prov?.size ?: 0} lanja · nekena ${op.active.size} lanja", fontSize = 14.sp)
                Text("2 SPRT: " + (when (op.sprtOk) { true -> "✓ "; false -> "✗ "; null -> "" }) + op.sprt.ifEmpty { "-" }, fontSize = 14.sp)
                val next = when {
                    op.prov == null -> "Tsy misy provisoire → Training: 'Alaina ny lanja' + 'Apply'"
                    op.sprtOk == false -> "SPRT tsy nandalo → avereno ny Training na ✖ Delete experience"
                    op.sprtOk == null -> "Manaraka: SPRT (ao amin'ny Training)"
                    else -> "Manaraka: ✔ Update moteur (ao amin'ny Training)"
                }
                Text("→ $next", fontSize = 14.sp, color = cs.primary)
                if (op.hist.isNotEmpty() && !compact) Caption("Tantara: version taloha ${op.hist.size} (Rollback ao amin'ny Training)")
                OutlinedButton(onClick = { Nav.tab = 3 }) { Text("Misokatra ny Training") }
            }
        }
    }

    // ---- 4-5: profil moteur (base / release): Apply, Calibrage, Copier ----
    Panel("Profil moteur", subtitle = "Base / release · Apply, Calibrage, Copier", glyph = "⚙") {
        PagedItems(Profiles.list.toList()) { p, compact ->
            val isBase = p.id == "base"
            val isDef = p.id == Profiles.defaultId
            HoverCard(spacing = 3.dp) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(p.name, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    if (isDef) Pill("★ DEFAULT")
                }
                if (p.options.isNotEmpty() && !compact) Text(p.options.entries.joinToString("; ") { "${it.key}=${it.value}" }, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                if (!isBase && p.sprt.isNotEmpty()) Text("SPRT: " + (when (p.sprtOk) { true -> "✓ "; false -> "✗ "; null -> "" }) + p.sprt, fontSize = 14.sp)
                Text("Apply: ${if (isDef) "✓ default" else "-"}", fontSize = 14.sp)
                val eloTxt = p.elo?.let { e -> f1(e) + (if (!isBase && baseElo != null) "  (Δ vs base ${f1(e - baseElo)})" else "") } ?: "-"
                Text("Calibrage Elo: $eloTxt", fontSize = 14.sp)
                val next = when {
                    isBase -> "Calibrer ny base ho fampitahana"
                    !isDef -> "Manaraka: Apply"
                    p.elo == null -> "Manaraka: Calibrer"
                    else -> "Manaraka: Release (Copier → default_profile.txt → git tag)"
                }
                Text("→ $next", fontSize = 14.sp, color = cs.primary)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { Nav.calibP.value = p.id; Nav.sub = 3 }) { Text("Calibrer") }
                    Button(onClick = { Profiles.setDefault(p.id) }, enabled = !isDef) { Text("Apply") }
                    OutlinedButton(onClick = {
                        clip.setText(AnnotatedString(Profiles.lines(p)))
                        Toast.makeText(ctx, "Voakopia", Toast.LENGTH_SHORT).show()
                    }) { Text("Copier") }
                    if (!isBase && p.id != "release") OutlinedButton(onClick = { Profiles.remove(p.id) }) { Text("Fafao") }
                }
            }
        }
    }
}

// ---------- Time control + Livre d'ouvertures ----------
@Composable
fun TestSettings() {
    TcPicker(Nav.tc)
    BookPicker()
}

@Composable
fun TcPicker(t: TcState, modes: List<Pair<String, String>> = listOf("movetime" to "Movetime", "tc" to "Base+Inc", "nodes" to "Nodes", "depth" to "Depth")) {
    Caption("Time control")
    SegTabs(modes.map { it.second }, modes.indexOfFirst { it.first == t.mode.value }) { t.mode.value = modes[it].first }
    when (t.mode.value) {
        "tc" -> { Field("Base (segondra)", t.base); Field("Increment (segondra)", t.inc) }
        "nodes" -> Field("Nodes isaky ny hetsika", t.nodes, true)
        "depth" -> Field("Depth", t.depth, true)
        else -> Field("ms isaky ny hetsika", t.ms, true)
    }
}

@Composable
fun BookPicker() {
    var open by remember { mutableStateOf(false) }
    val plies = remember { mutableStateOf("8") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Host.scope.launch {
            Books.msg.value = "Mamaky..."
            Books.msg.value = try { "Livre: ${Books.import(uri, plies.value.toIntOrNull() ?: 8)} toerana" } catch (e: Exception) { "Livre diso: ${e.message}" }
        }
    }
    Caption("Livre d'ouvertures: " + (if (Books.active.isEmpty()) "book ofisialy ECO (${if (OpeningBook.isReady()) OpeningBook.size().toString() else "…"} ouverture) — Training, Live, Calibrage" else "${Books.active} (${Books.count} toerana)"))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box {
            OutlinedButton(onClick = { open = true }) { Text("Safidio ▾") }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text("(book ofisialy ECO)") }, onClick = { Books.select(""); open = false })
                Books.names.forEach { n -> DropdownMenuItem(text = { Text(n) }, onClick = { Books.select(n); open = false }) }
            }
        }
        OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import EPD/PGN") }
        if (Books.active.isNotEmpty()) OutlinedButton(onClick = { Books.delete(Books.active) }) { Text("Fafao") }
    }
    Field("Isan'ny ply alaina avy amin'ny PGN", plies, true)
    if (Books.msg.value.isNotEmpty()) Caption(Books.msg.value)
}

// ---------- Mitohy ny asa tsy vita ----------
@Composable
fun ResumeBanner() {
    val j: JSONObject? = Ckpt.pending.value
    if (j != null && !Host.running.value) {
        HoverCard(spacing = 4.dp) {
            Text("Asa tsy vita: ${Tasks.describe(j)}", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { Host.launch(Tasks.title(j)) { Tasks.run(j) } }) { Text("Tohizo") }
                OutlinedButton(onClick = { Ckpt.clear() }) { Text("Foano") }
            }
        }
    }
}

// ---------- Tantara ----------
@Composable
fun HistoryScreen() {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf<String?>(null) }
    Panel("Tantara", subtitle = "Fitsapana vita (${History.list.size})", glyph = "☰", collapsible = false) {
        PagedItems(History.list.toList(), emptyText = "Mbola tsy misy tantara. Hiseho eto ny fitsapana vita.") { e, compact ->
            HoverCard(spacing = 3.dp) {
                Text("${e.type} · ${History.date(e.time)}", style = MaterialTheme.typography.titleSmall)
                Caption(e.tc)
                Text(e.subject, fontSize = 13.sp, maxLines = if (compact) 2 else 3, overflow = TextOverflow.Ellipsis)
                Text(e.headline.lines().take(if (open == e.id) 60 else 2).joinToString("\n"), fontSize = 13.sp)
                if (open == e.id && e.table.isNotEmpty())
                    Text(e.table, fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { open = if (open == e.id) null else e.id }) { Text(if (open == e.id) "Hanidy" else "Jereo") }
                    OutlinedButton(onClick = {
                        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, History.text(e)) }
                        ctx.startActivity(Intent.createChooser(i, "Zarao"))
                    }) { Text("Zarao") }
                    OutlinedButton(onClick = { History.remove(e.id) }) { Text("Fafao") }
                }
            }
        }
        if (History.list.isNotEmpty()) OutlinedButton(onClick = { History.clear() }) { Text("Fafao rehetra") }
    }
}
