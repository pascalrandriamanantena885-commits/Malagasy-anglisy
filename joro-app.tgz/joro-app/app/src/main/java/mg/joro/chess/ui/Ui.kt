package mg.joro.chess.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import org.json.JSONObject
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import mg.joro.chess.BuildConfig
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import mg.joro.chess.match.*
import mg.joro.chess.match.Updater
import androidx.compose.runtime.snapshots.SnapshotStateList

private val TABS = listOf("Milalao", "Live", "Review", "Training", "Fitsapana", "Moteur", "Update")

@Composable
fun App() {
    val tab = Nav.tab
    Scaffold(bottomBar = {
        NavigationBar {
            TABS.forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { Nav.tab = i }, icon = { Text(listOf("♞", "▶", "◎", "⚔", "Σ", "⚙", "⬇")[i]) },
                    label = { Text(t, fontSize = 13.sp, maxLines = 1) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> PlayScreen(); 1 -> LiveScreen(); 2 -> AnalysisScreen(); 3 -> TrainingScreen(); 4 -> TestsScreen(); 5 -> EnginesScreen(); else -> UpdateScreen() }
        }
    }
}

// ---------- fampiasa iombonana ----------
@Composable
fun Field(label: String, st: MutableState<String>, num: Boolean = false) {
    OutlinedTextField(
        value = st.value, onValueChange = { st.value = it }, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = if (num) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default
    )
}

@Composable
fun EnginePicker(label: String, sel: MutableState<String>) {
    var open by remember { mutableStateOf(false) }
    val cur = Host.pick(sel.value)
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text("$label: ${cur?.name ?: "(tsy misy moteur)"} ▾") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Host.engines.forEach { e -> DropdownMenuItem(text = { Text(e.name) }, onClick = { sel.value = e.id; open = false }) }
        }
    }
}

@Composable
fun ReportPanel() {
    val r = Host.report.value
    Column(Modifier.fillMaxWidth()) {
        if (r.title.isNotEmpty()) Text(r.title, style = MaterialTheme.typography.titleMedium)
        if (r.headline.isNotEmpty()) Text(r.headline)
        if (r.table.isNotEmpty()) Text(table(r.table), fontFamily = FontFamily.Monospace, fontSize = 13.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState()))
        r.log.takeLast(12).forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 13.sp) }
        if (Host.running.value) Button(onClick = { Host.stop() }) { Text("Atsaharo") }
    }
}

@Composable
fun ThemeToggle() {
    TextButton(onClick = { Host.boardTheme.value = 1 - Host.boardTheme.value }) { Text("Loko board: ${if (Host.boardTheme.value == 0) "gris" else "marron"}") }
}

// ---------- Player vs moteur ----------
private fun fmtClock(ms: Int): String {
    val s = maxOf(0, ms) / 1000
    return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
}

@Composable
fun PlayScreen() {
    val eng = remember { mutableStateOf("") }
    val prof = remember { mutableStateOf("@default") }
    val opts = remember { mutableStateOf("") }
    val imp = remember { mutableStateOf("") }
    var side by remember { mutableIntStateOf(0) }
    var flip by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    val g = Play.game
    Play.rev // mamaky ny rev mba hamerenana ny composition
    Column(Modifier.padding(10.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (g != null) {
            val viewing = Play.viewPly >= 0
            val shown = Play.viewBoard ?: g.board
            val lastMv = if (viewing) g.moves.getOrNull(Play.viewPly - 1) else g.moves.lastOrNull()
            if (Play.tc.clocked) Text("⚪ ${fmtClock(Play.wClock)}      ⚫ ${fmtClock(Play.bClock)}", fontFamily = FontFamily.Monospace)
            BoardView(shown, if (Play.human == 1) !flip else flip, if (viewing) -1 else Play.selected,
                if (viewing) emptySet() else Play.targets, lastMv, onTap = { Play.tap(it) })
            Text(Play.status.ifEmpty { if (Play.thinking) "Mieritreritra... ${Play.info}" else if (g.board.stm == Play.human) "Anao ny tonga" else "" })
            Column(Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
                Play.sans.chunked(2).forEachIndexed { i, pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("${i + 1}.", Modifier.width(30.dp), fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                        pair.forEachIndexed { k, san ->
                            val ply = i * 2 + k + 1
                            Text(san, Modifier.clickable { Play.view(ply) }.padding(2.dp), fontSize = 14.sp, fontFamily = FontFamily.Monospace,
                                color = if (Play.viewPly == ply) MaterialTheme.colorScheme.primary else Color.Unspecified)
                        }
                    }
                }
            }
            if (viewing) Button(onClick = { Play.view(Int.MAX_VALUE) }) { Text("Miverina amin'ny lalao ankehitriny") }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { flip = !flip }) { Text("Vadiho") }
                OutlinedButton(onClick = { Play.undo() }) { Text("Undo") }
                OutlinedButton(onClick = { Play.resign() }) { Text("Miala") }
                OutlinedButton(onClick = {
                    clip.setText(AnnotatedString(Play.pgn())); Toast.makeText(ctx, "PGN voakopia", Toast.LENGTH_SHORT).show()
                }) { Text("PGN") }
                ThemeToggle()
            }
            val sg = Play.savedId?.let { ReviewStore.get(it) }
            if (g.result != Res.ONGOING && sg != null) Button(modifier = Modifier.fillMaxWidth(), onClick = {
                Analysis.openSaved(sg)
                Nav.tab = 2   // tab Review
            }) { Text(if (sg.reviewed) "📊 Jereo ny review" else "📊 Review lalao") }
        }
        EnginePicker("Moteur", eng)
        ProfilePicker("Profil JORO", prof, true)
        Field("Options (Nom=val;Nom2=val2)", opts)
        TcPicker(Nav.playTc, listOf("movetime" to "Movetime", "tc" to "Base+Inc"))
        Field("FEN na PGN (azo ahafahana)", imp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = side == 0, onClick = { side = 0 }, label = { Text("Fotsy") })
            FilterChip(selected = side == 1, onClick = { side = 1 }, label = { Text("Mainty") })
            Button(onClick = {
                val txt = imp.value.trim()
                var initial: PgnLine? = null
                var bad = false
                if (txt.isNotEmpty()) {
                    initial = if (txt.contains('[') || Regex("\\b1\\.").containsMatchIn(txt)) Pgn.movesOf(txt)
                    else try { Board.fromFen(txt); PgnLine(txt, emptyList(), txt) } catch (_: Exception) { null }
                    bad = initial == null
                }
                if (bad) Toast.makeText(ctx, "FEN/PGN diso", Toast.LENGTH_SHORT).show()
                else Host.spec(eng.value, opts.value, prof.value)?.let { Play.start(it, side, Nav.playTc.toTC(), initial) }
            }) { Text("Lalao vaovao") }
        }
    }
    if (Play.pendingPromo.isNotEmpty()) {
        AlertDialog(onDismissRequest = { Play.pendingPromo = emptyList() }, confirmButton = {},
            title = { Text("Promotion") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("♕" to 5, "♖" to 4, "♗" to 3, "♘" to 2).forEach { (sym, p) -> Button(onClick = { Play.promote(p) }) { Text(sym) } }
                }
            })
    }
}

// ---------- Stockfish vs moteur live ----------
@Composable
fun LiveScreen() {
    val a = remember { mutableStateOf("") }
    val b = remember { mutableStateOf("stockfish") }
    val oa = remember { mutableStateOf("") }
    val ob = remember { mutableStateOf("") }
    val strength = remember { mutableStateOf("2000") }
    val pa = remember { mutableStateOf("@default") }
    val pb = remember { mutableStateOf("base") }
    val ms = remember { mutableStateOf("500") }
    val games = remember { mutableStateOf("10") }
    Column(Modifier.padding(10.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        BoardView(Live.board, false, -1, emptySet(), Live.last, onTap = {})
        Text("⚪ ${Live.names.first}  ${Live.infoW}", fontSize = 14.sp)
        Text("⚫ ${Live.names.second}  ${Live.infoB}", fontSize = 14.sp)
        Text("${Live.status}   A: +${Live.w} =${Live.d} -${Live.l}")
        Text(Live.moves.chunked(2).mapIndexed { i, p -> "${i + 1}. ${p.joinToString(" ")}" }.joinToString("  "), fontSize = 13.sp, fontFamily = FontFamily.Monospace)
        ThemeToggle()
        val lg = Live.lastId?.let { ReviewStore.get(it) }
        if (lg != null) Button(modifier = Modifier.fillMaxWidth(), onClick = {
            Analysis.openSaved(lg)
            Nav.tab = 2   // tab Review
        }) { Text(if (lg.reviewed) "📊 Jereo ny review (lalao farany)" else "📊 Review lalao farany") }
        if (ReviewStore.games.isNotEmpty()) OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { Nav.tab = 2 }) {
            Text("Lalao rehetra voatahiry (${ReviewStore.games.size})")
        }
        EnginePicker("A (moteur)", a); ProfilePicker("Profil A", pa, true); Field("Options A", oa)
        EnginePicker("B (Stockfish)", b); ProfilePicker("Profil B (JORO)", pb); StrengthPicker("Hery Stockfish (Elo)", strength); Field("Options B (fanampiny)", ob)
        TestSettings(); Field("Isan'ny lalao", games, true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !Host.running.value, onClick = {
                val sa = Host.spec(a.value, oa.value, pa.value); val sb = Host.spec(b.value, joinOpts(ob.value, strengthOpts(strength.value)), pb.value)
                if (sa != null && sb != null) Host.launch("Live") {
                    Tasks.live(sa, sb, games.value.toIntOrNull() ?: 1, Nav.tc.toTC())
                }
            }) { Text("Start") }
            if (Host.running.value) OutlinedButton(onClick = { Host.stop() }) { Text("Atsaharo") }
        }
    }
}

// ---------- Fitsapana: Pipeline / SPRT / Matrice / Calibrage ----------
class Slot { val sel = mutableStateOf(""); val opts = mutableStateOf("") }
@Composable
fun TestsScreen() {
    val sub = Nav.sub
    val names = listOf("Pipeline", "SPRT", "Matrice", "Calibrage", "Tantara")
    Column(Modifier.padding(10.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            names.forEachIndexed { i, n -> FilterChip(selected = sub == i, onClick = { Nav.sub = i }, label = { Text(n) }) }
        }
        ResumeBanner()
        when (sub) { 0 -> PipelineScreen(); 1 -> SprtForm(); 2 -> MatrixForm(); 3 -> CalibForm(); else -> HistoryScreen() }
        HorizontalDivider()
        ReportPanel()
    }
}

@Composable
fun SprtForm() {
    val a = remember { mutableStateOf("") }; val b = remember { mutableStateOf("") }
    val oa = remember { mutableStateOf("") }; val ob = remember { mutableStateOf("") }
    val e0 = remember { mutableStateOf("0") }; val e1 = remember { mutableStateOf("5") }
    val al = remember { mutableStateOf("0.05") }; val be = remember { mutableStateOf("0.05") }
    val mg = remember { mutableStateOf("400") }; val ms = remember { mutableStateOf("200") }
    val par = remember { mutableStateOf("2") }
    EnginePicker("A (vaovao)", a); ProfilePicker("Profil A", Nav.sprtA); Field("Options A", oa)
    EnginePicker("B (base)", b); ProfilePicker("Profil B", Nav.sprtB); Field("Options B", ob)
    Field("Elo0", e0); Field("Elo1", e1); Field("alpha", al); Field("beta", be)
    Field("Lalao max", mg, true)
    Field("Lalao miaraka (parallèle, 1..${ParSprt.clampWorkers(64)})", par, true); TestSettings()
    Button(enabled = !Host.running.value, onClick = {
        val sa = Host.spec(a.value, oa.value, Nav.sprtA.value); val sb = Host.spec(b.value, ob.value, Nav.sprtB.value)
        if (sa != null && sb != null) {
            val job = Tasks.newSprt(sa, sb, e0.value.toDoubleOrNull() ?: 0.0, e1.value.toDoubleOrNull() ?: 5.0,
                al.value.toDoubleOrNull() ?: 0.05, be.value.toDoubleOrNull() ?: 0.05,
                mg.value.toIntOrNull() ?: 400, Nav.tc.toTC(), System.nanoTime() % 100000,
                Nav.sprtA.value, Nav.sprtB.value, ParSprt.clampWorkers(par.value.toIntOrNull() ?: 2))
            Host.launch("SPRT") { Tasks.run(job) }
        }
    }) { Text("Start SPRT") }
}

@Composable
fun MatrixForm() {
    val slots = remember { mutableStateListOf(Slot(), Slot()) }
    val gp = remember { mutableStateOf("10") }; val ms = remember { mutableStateOf("200") }
    slots.forEachIndexed { i, s -> EnginePicker("Moteur ${i + 1}", s.sel); Field("Options ${i + 1}", s.opts) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { if (slots.size < 8) slots.add(Slot()) }) { Text("+ moteur") }
        OutlinedButton(onClick = { if (slots.size > 2) slots.removeAt(slots.size - 1) }) { Text("- moteur") }
    }
    Field("Lalao isaky ny paire", gp, true); TestSettings()
    Button(enabled = !Host.running.value, onClick = {
        val specs = slots.mapNotNull { Host.spec(it.sel.value, it.opts.value) }
        if (specs.size >= 2) {
            val job = Tasks.newMatrix(specs, gp.value.toIntOrNull() ?: 10, Nav.tc.toTC(), System.nanoTime() % 100000)
            Host.launch("Matrice") { Tasks.run(job) }
        }
    }) { Text("Start matrice") }
}

@Composable
fun CalibForm() {
    val a = remember { mutableStateOf("") }; val s = remember { mutableStateOf("stockfish") }
    val oa = remember { mutableStateOf("") }; val os = remember { mutableStateOf("") }
    val chosen = remember { mutableStateListOf("1500", "2000", "2500") }
    val extra = remember { mutableStateOf("") }
    val gm = remember { mutableStateOf("20") }; val ms = remember { mutableStateOf("200") }
    EnginePicker("Moteur", a); ProfilePicker("Profil", Nav.calibP); Field("Options moteur", oa)
    EnginePicker("Stockfish", s); Field("Options Stockfish (fanampiny)", os)
    LevelPicker(chosen, extra); Field("Lalao isaky ny haavo", gm, true); TestSettings()
    Button(enabled = !Host.running.value, onClick = {
        val sa = Host.spec(a.value, oa.value, Nav.calibP.value); val ss = Host.spec(s.value, os.value)
        val levels = (chosen.toList() + extra.value.split(',')).mapNotNull { x ->
            val t = x.trim().lowercase()
            if (t == "max") 0 else t.toIntOrNull()
        }.distinct().sortedBy { if (it == 0) Int.MAX_VALUE else it }
        if (sa != null && ss != null && levels.isNotEmpty()) {
            val job = Tasks.newCalib(sa, ss, levels, gm.value.toIntOrNull() ?: 20, Nav.tc.toTC(), System.nanoTime() % 100000, Nav.calibP.value)
            Host.launch("Calibrage") { Tasks.run(job) }
        }
    }) { Text("Start calibrage") }
}

// ---------- Moteur: import / export / delete / compile cloud ----------
@Composable
fun EnginesScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val repo = remember { mutableStateOf(prefs.getString("repo", BuildConfig.GITHUB_REPO) ?: BuildConfig.GITHUB_REPO) }
    val token = remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    val flags = remember { mutableStateOf("-O3 -std=c++17") }
    var pending by remember { mutableStateOf<Pair<mg.joro.chess.uci.EngineEntry, String>?>(null) }
    val msg = Host.importMsg

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Host.scope.launch {
            try {
                msg.value = "Mamaky..."
                when (val o = Host.store.import(uri)) {
                    is mg.joro.chess.uci.Installed -> { Host.refresh(); msg.value = "OK: ${o.entry.name}" }
                    is mg.joro.chess.uci.NeedsCompile -> {
                        prefs.edit().putString("repo", repo.value.trim()).putString("token", token.value.trim()).apply()
                        val f = CloudBuild.compile(ctx, o.file, o.name, o.name.substringBeforeLast('.'), flags.value) { st -> msg.value = st }
                        val e = Host.store.installBinary(f, o.name.substringBeforeLast('.'))
                        Host.refresh(); msg.value = "Compile + import OK: ${e.name}"
                    }
                }
            } catch (ex: Exception) { msg.value = "Diso: ${ex.message}" }
        }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val pe = pending
        if (uri != null && pe != null) Host.scope.launch {
            msg.value = try { Host.store.export(pe.first, pe.second, uri); "Export OK (${pe.second})" } catch (ex: Exception) { "Export diso: ${ex.message}" }
        }
    }
    val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "abi"

    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import: ELF · .zip · .tgz · .cpp") }
        if (msg.value.isNotEmpty()) Text(msg.value)
        Host.engines.forEach { en ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(en.name, style = MaterialTheme.typography.titleSmall)
                    Text(en.path, fontSize = 13.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { pending = en to "zip"; saver.launch(mg.joro.chess.uci.Pack.safeName(en.name) + "-$abi.zip") }) { Text("Export .zip") }
                        OutlinedButton(onClick = { pending = en to "tgz"; saver.launch(mg.joro.chess.uci.Pack.safeName(en.name) + "-$abi.tgz") }) { Text("Export .tgz") }
                        if (en.builtin) Text("integré", Modifier.padding(8.dp), fontSize = 14.sp)
                        else OutlinedButton(onClick = { Host.store.delete(en); Host.refresh() }) { Text("Fafao") }
                    }
                }
            }
        }
        HorizontalDivider()
        Text("Compile cloud (ho an'ny source .cpp)", style = MaterialTheme.typography.titleSmall)
        Text("Tsy misy compiler ao amin'ny finday. Ny source .cpp (na .zip/.tgz misy source) dia alefa any amin'ny GitHub repo-nao (PUBLIC), " +
            "ny workflow compile-engine.yml no mamorona ny binaire, ary ampidinin'ny app ho moteur. Mila token (Contents + Actions: read/write).", fontSize = 13.sp)
        Field("Repo GitHub (owner/repo)", repo)
        OutlinedTextField(token.value, { x -> token.value = x }, label = { Text("Token GitHub") }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Field("Flags compile", flags)
        OutlinedButton(onClick = { prefs.edit().putString("repo", repo.value.trim()).putString("token", token.value.trim()).apply(); msg.value = "Voatahiry" }) { Text("Tahiry") }
    }
}

// ---------- Update version ----------
@Composable
fun UpdateScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("app", 0) }
    val repo = remember { mutableStateOf(prefs.getString("repo", BuildConfig.GITHUB_REPO) ?: BuildConfig.GITHUB_REPO) }
    var msg by remember { mutableStateOf("") }
    var rel by remember { mutableStateOf<Release?>(null) }
    val scope = rememberCoroutineScope()
    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Version ankehitriny: ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.titleMedium)
        Field("Repo GitHub (owner/repo)", repo)
        Button(onClick = {
            prefs.edit().putString("repo", repo.value).apply()
            msg = "Mijery..."
            scope.launch {
                msg = try {
                    val r = Updater.latest(repo.value.trim()); rel = r
                    if (Updater.isNewer(r.tag, BuildConfig.VERSION_NAME)) "Version vaovao: ${r.tag}" else "Efa vaovao ny app (${r.tag})"
                } catch (ex: Exception) { "Diso: ${ex.message}" }
            }
        }) { Text("Hamarino ny update") }
        Text(msg)
        val r = rel
        if (r != null && r.apkUrl != null && Updater.isNewer(r.tag, BuildConfig.VERSION_NAME)) {
            if (r.notes.isNotBlank()) Text(r.notes, fontSize = 14.sp)
            Button(onClick = {
                scope.launch {
                    try {
                        val f = Updater.download(ctx, r.apkUrl) { p -> msg = "Download $p%" }
                        Updater.install(ctx, f)
                    } catch (ex: Exception) { msg = "Diso: ${ex.message}" }
                }
            }) { Text("Alaina sy apetraho ${r.tag}") }
        }
        Text("Ny update dia mitondra moteur JORO vaovao ao anatiny. Ny moteur nalaina avy any ivelany (Stockfish...) dia tsy miova.", fontSize = 13.sp)
    }
}

// ---------- safidy hery Stockfish ----------
fun strengthOpts(s: String): String = if (s == "max") "" else "UCI_LimitStrength=true;UCI_Elo=$s"
fun joinOpts(a: String, b: String): String = listOf(a, b).filter { it.isNotBlank() }.joinToString(";")

@Composable
fun StrengthPicker(label: String, sel: MutableState<String>) {
    val custom = remember { mutableStateOf("") }
    Text(label, fontSize = 14.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("1500", "2000", "2500", "2700", "3100", "max").forEach { p ->
            FilterChip(selected = sel.value == p, onClick = { sel.value = p; custom.value = "" },
                label = { Text(if (p == "max") "Max" else p) })
        }
    }
    OutlinedTextField(
        value = custom.value,
        onValueChange = { x -> custom.value = x.filter { c -> c.isDigit() }; if (custom.value.isNotEmpty()) sel.value = custom.value },
        label = { Text("Elo hafa (1320-3190)  ·  voafidy: ${if (sel.value == "max") "Max" else sel.value}") },
        singleLine = true, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
fun LevelPicker(chosen: SnapshotStateList<String>, extra: MutableState<String>) {
    Text("Haavon'ny Stockfish hanaovana calibrage (azo fidina maromaro)", fontSize = 14.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("1320", "1500", "1800", "2000", "2200", "2500", "2700", "3000", "3100", "max").forEach { p ->
            FilterChip(selected = p in chosen, onClick = { if (p in chosen) chosen.remove(p) else chosen.add(p) },
                label = { Text(if (p == "max") "Max" else p) })
        }
    }
    Field("Haavo hafa (virgule, ex: 2350,2900)", extra)
}

// ---------- Profils + Pipeline ----------
@Composable
fun ProfilePicker(label: String, sel: MutableState<String>, allowDefault: Boolean = false) {
    var open by remember { mutableStateOf(false) }
    val cur = if (sel.value == "@default") Profiles.get(Profiles.defaultId) else (Profiles.get(sel.value) ?: Profiles.get("base"))
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: " + (if (sel.value == "@default") "★ default → " else "") + (cur?.name ?: "base") + " ▾")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (allowDefault) DropdownMenuItem(text = { Text("★ default (${Profiles.get(Profiles.defaultId)?.name ?: "base"})") },
                onClick = { sel.value = "@default"; open = false })
            Profiles.list.forEach { p ->
                DropdownMenuItem(text = { Text(p.name + if (p.id == Profiles.defaultId) " (default)" else "") },
                    onClick = { sel.value = p.id; open = false })
            }
        }
    }
}

@Composable
fun PipelineScreen() {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    val baseElo = Profiles.get("base")?.elo
    Text("1 Training → 2 SPRT → 3 Update moteur → 4 Calibrage → 5 Release", style = MaterialTheme.typography.titleMedium)
    Text("Ny Training no mamorona ny profil isaky ny opening (provisoire). Ny SPRT dia atao ao amin'ny Training ihany (provisoire vs taloha); " +
        "raha H1 ekena dia \"✔ Update moteur\", avy eo Calibrage. " +
        "Ho an'ny Release: Copier ny profil moteur → default_profile.txt, ary Copier profil Training nekena → default_oprofiles.txt (app/src/main/assets/) → commit → git tag vX.Y.Z → Release → Update.", fontSize = 14.sp)

    // ---- 1-3: profil Training (isaky ny opening) ----
    Text("Profil Training (isaky ny opening)", style = MaterialTheme.typography.titleSmall)
    if (OProfiles.list.isEmpty()) Text("Mbola tsy misy. Mankanesa ao amin'ny Training: mifidiana opening, mihetsika, 'Alaina ny lanja' ary 'Apply'.", fontSize = 14.sp)
    if (OProfiles.list.any { it.active.isNotEmpty() }) OutlinedButton(onClick = {
        clip.setText(AnnotatedString(OProfiles.exportRelease()))
        Toast.makeText(ctx, "Voakopia: apetaho ao amin'ny assets/default_oprofiles.txt", Toast.LENGTH_LONG).show()
    }) { Text("📋 Copier profil Training nekena (release)") }
    OProfiles.list.forEach { op ->
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("${op.name}  (${OProfiles.sideWord(op.side)})", style = MaterialTheme.typography.titleSmall)
                Text("1 Training: provisoire ${op.prov?.size ?: 0} lanja · nekena ${op.active.size} lanja", fontSize = 14.sp)
                Text("2 SPRT: " + (when (op.sprtOk) { true -> "✓ "; false -> "✗ "; null -> "" }) + op.sprt.ifEmpty { "-" }, fontSize = 14.sp)
                val next = when {
                    op.prov == null -> "Tsy misy provisoire → Training: 'Alaina ny lanja' + 'Apply'"
                    op.sprtOk == false -> "SPRT tsy nandalo → avereno ny Training na ✖ Delete experience"
                    op.sprtOk == null -> "Manaraka: SPRT (ao amin'ny Training)"
                    else -> "Manaraka: ✔ Update moteur (ao amin'ny Training)"
                }
                Text("→ $next", fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                if (op.hist.isNotEmpty()) Text("Tantara: version taloha ${op.hist.size} (Rollback ao amin'ny Training)", fontSize = 14.sp)
                OutlinedButton(onClick = { Nav.tab = 3 }) { Text("Misokatra ny Training") }
            }
        }
    }

    // ---- 4-5: profil moteur (base / release): Apply, Calibrage, Copier ----
    HorizontalDivider()
    Text("Profil moteur (base / release)", style = MaterialTheme.typography.titleSmall)
    Profiles.list.forEach { p ->
        val isBase = p.id == "base"
        val isDef = p.id == Profiles.defaultId
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(p.name + if (isDef) "  ★ DEFAULT" else "", style = MaterialTheme.typography.titleSmall)
                if (p.options.isNotEmpty()) Text(p.options.entries.joinToString("; ") { "${it.key}=${it.value}" }, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                if (!isBase && p.sprt.isNotEmpty()) Text("SPRT: " + (when (p.sprtOk) { true -> "✓ "; false -> "✗ "; null -> "" }) + p.sprt, fontSize = 14.sp)
                Text("Apply: ${if (isDef) "✓ default" else "-"}", fontSize = 14.sp)
                val eloTxt = p.elo?.let { e -> f1(e) + (if (!isBase && baseElo != null) "  (Δ vs base ${f1(e - baseElo)})" else "") } ?: "-"
                Text("Calibrage Elo: $eloTxt", fontSize = 14.sp)
                val next = when {
                    isBase -> "Calibrer ny base ho fampitahana"
                    !isDef -> "Manaraka: Apply"
                    p.elo == null -> "Manaraka: Calibrer"
                    else -> "Manaraka: Release (Copier → default_profile.txt → git tag)"
                }
                Text("→ $next", fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { Nav.calibP.value = p.id; Nav.sub = 3 }) { Text("Calibrer") }
                    Button(onClick = { Profiles.setDefault(p.id) }, enabled = !isDef) { Text("Apply") }
                    OutlinedButton(onClick = {
                        clip.setText(AnnotatedString(Profiles.lines(p)))
                        Toast.makeText(ctx, "Voakopia", Toast.LENGTH_SHORT).show()
                    }) { Text("Copier") }
                    if (!isBase && p.id != "release") OutlinedButton(onClick = { Profiles.remove(p.id) }) { Text("Fafao") }
                }
            }
        }
    }
}

// ---------- Time control + Livre d'ouvertures ----------
@Composable
fun TestSettings() {
    TcPicker(Nav.tc)
    BookPicker()
}

@Composable
fun TcPicker(t: TcState, modes: List<Pair<String, String>> = listOf("movetime" to "Movetime", "tc" to "Base+Inc", "nodes" to "Nodes", "depth" to "Depth")) {
    Text("Time control", fontSize = 14.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        modes.forEach { (k, n) ->
            FilterChip(selected = t.mode.value == k, onClick = { t.mode.value = k }, label = { Text(n) })
        }
    }
    when (t.mode.value) {
        "tc" -> { Field("Base (segondra)", t.base); Field("Increment (segondra)", t.inc) }
        "nodes" -> Field("Nodes isaky ny hetsika", t.nodes, true)
        "depth" -> Field("Depth", t.depth, true)
        else -> Field("ms isaky ny hetsika", t.ms, true)
    }
}

@Composable
fun BookPicker() {
    var open by remember { mutableStateOf(false) }
    val plies = remember { mutableStateOf("8") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Host.scope.launch {
            Books.msg.value = "Mamaky..."
            Books.msg.value = try { "Livre: ${Books.import(uri, plies.value.toIntOrNull() ?: 8)} toerana" } catch (e: Exception) { "Livre diso: ${e.message}" }
        }
    }
    Text("Livre d'ouvertures: " + (if (Books.active.isEmpty()) "aléatoire (4 ply)" else "${Books.active} (${Books.count} toerana)"), fontSize = 14.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box {
            OutlinedButton(onClick = { open = true }) { Text("Safidio ▾") }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text("(aléatoire)") }, onClick = { Books.select(""); open = false })
                Books.names.forEach { n -> DropdownMenuItem(text = { Text(n) }, onClick = { Books.select(n); open = false }) }
            }
        }
        OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import EPD/PGN") }
        if (Books.active.isNotEmpty()) OutlinedButton(onClick = { Books.delete(Books.active) }) { Text("Fafao") }
    }
    Field("Isan'ny ply alaina avy amin'ny PGN", plies, true)
    if (Books.msg.value.isNotEmpty()) Text(Books.msg.value, fontSize = 13.sp)
}

// ---------- Mitohy ny asa tsy vita ----------
@Composable
fun ResumeBanner() {
    val j: JSONObject? = Ckpt.pending.value
    if (j != null && !Host.running.value) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Asa tsy vita: ${Tasks.describe(j)}", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { Host.launch(Tasks.title(j)) { Tasks.run(j) } }) { Text("Tohizo") }
                    OutlinedButton(onClick = { Ckpt.clear() }) { Text("Foano") }
                }
            }
        }
    }
}

// ---------- Tantara ----------
@Composable
fun HistoryScreen() {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf<String?>(null) }
    if (History.list.isEmpty()) Text("Mbola tsy misy tantara. Hiseho eto ny fitsapana vita.")
    History.list.forEach { e ->
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("${e.type} · ${History.date(e.time)} · ${e.tc}", style = MaterialTheme.typography.titleSmall)
                Text(e.subject, fontSize = 13.sp)
                Text(e.headline.lines().take(if (open == e.id) 60 else 2).joinToString("\n"), fontSize = 13.sp)
                if (open == e.id && e.table.isNotEmpty())
                    Text(e.table, fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { open = if (open == e.id) null else e.id }) { Text(if (open == e.id) "Hanidy" else "Jereo") }
                    OutlinedButton(onClick = {
                        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, History.text(e)) }
                        ctx.startActivity(Intent.createChooser(i, "Zarao"))
                    }) { Text("Zarao") }
                    OutlinedButton(onClick = { History.remove(e.id) }) { Text("Fafao") }
                }
            }
        }
    }
    if (History.list.isNotEmpty()) OutlinedButton(onClick = { History.clear() }) { Text("Fafao rehetra") }
}
