package mg.joro.chess

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log crash: manoratra ao amin'ny filesDir/crash.txt ny hadisoana rehetra tsy voasambotra (thread rehetra + coroutine),
 * ary asehoana ao amin'ny app (dialog + Réglages) rehefa misokatra indray.
 */
object CrashLog {
    var text by mutableStateOf("")       // log voatahiry (farany)
        private set
    var showDialog by mutableStateOf(false)
    private var file: File? = null
    private const val MAX = 30_000

    fun init(ctx: Context) {
        val f = File(ctx.filesDir, "crash.txt")
        file = f
        text = try { if (f.exists()) f.readText() else "" } catch (_: Throwable) { "" }
        showDialog = text.isNotEmpty()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            write("CRASH (thread ${t.name})", e)
            prev?.uncaughtException(t, e)
        }
    }

    /** Soraty ao amin'ny rakitra (azo antsoina avy amin'ny thread rehetra) */
    @Synchronized
    fun write(title: String, e: Throwable) {
        try {
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val entry = "[$stamp] v${BuildConfig.VERSION_NAME} · $title\n$sw\n"
            val old = try { file?.takeIf { it.exists() }?.readText() ?: "" } catch (_: Throwable) { "" }
            val all = (entry + old).take(MAX)
            file?.writeText(all)
        } catch (_: Throwable) {
        }
    }

    fun clear() {
        try { file?.delete() } catch (_: Throwable) { }
        text = ""
        showDialog = false
    }
}
