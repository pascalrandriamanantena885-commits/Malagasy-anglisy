package mg.joro.chess.match

import android.content.Context
import android.content.Intent
import android.os.PowerManager
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import mg.joro.chess.KeepAliveService
import mg.joro.chess.uci.EngineEntry
import mg.joro.chess.uci.EngineStore

data class Report(
    val title: String = "", val headline: String = "",
    val table: List<List<String>> = emptyList(), val log: List<String> = emptyList()
)

/** Singleton: mitazona ny asa (fitsapana) na dia miova tab aza, ary mijanona ao amin'ny foreground service */
object Host {
    lateinit var ctx: Context
    lateinit var store: EngineStore
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val engines = mutableStateListOf<EngineEntry>()
    val report = mutableStateOf(Report())
    val running = mutableStateOf(false)
    val importMsg = mutableStateOf("")
    val boardTheme = mutableStateOf(0) // 0 = gray, 1 = brown
    private var job: Job? = null
    private val logBuf = ArrayList<String>()
    private var wake: PowerManager.WakeLock? = null

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        store = EngineStore(ctx)
        Profiles.init(ctx)
        Books.init(ctx)
        Ckpt.init(ctx)
        History.init(ctx)
        ReviewStore.init(ctx)
        RatingCalib.init(ctx)
        refresh()
    }

    fun refresh() {
        val l = store.list()
        engines.clear(); engines.addAll(l)
    }

    fun pick(id: String): EngineEntry? = engines.firstOrNull { it.id == id } ?: engines.firstOrNull()

    /** profId = profil fototra (SPSA/SPRT...) ; useDefault = ampiasaina ny profil default (apply) ho an'ny JORO integré */
    fun spec(id: String, opts: String, profId: String? = null, useDefault: Boolean = false): EngineSpec? {
        val e = pick(id) ?: return null
        val isJoro = e.id == "builtin" || e.name.contains("joro", ignoreCase = true)
        val pid = if (profId == "@default") (if (isJoro) Profiles.defaultId else null)
                  else profId ?: if (useDefault && e.id == "builtin") Profiles.defaultId else null
        val prof = pid?.let { Profiles.get(it) }
        val user = parseOpts(opts)
        val tag = if (prof != null && prof.id != "base") "{${prof.name}}" else ""
        val extra = if (user.isEmpty()) "" else " [" + user.entries.joinToString(",") { it.key + "=" + it.value } + "]"
        return EngineSpec(e.path, e.name + tag + extra, (prof?.options ?: emptyMap()) + user)
    }

    fun log(s: String) {
        synchronized(logBuf) { logBuf.add(s); if (logBuf.size > 300) logBuf.removeAt(0) }
    }

    fun post(title: String, headline: String, table: List<List<String>> = emptyList()) {
        val l = synchronized(logBuf) { logBuf.takeLast(40).toList() }
        report.value = Report(title, headline, table, l)
    }

    fun launch(title: String, block: suspend () -> Unit) {
        if (running.value) return
        running.value = true
        synchronized(logBuf) { logBuf.clear() }
        post(title, "Mandeha...")
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, KeepAliveService::class.java))
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "joro:task").also { it.acquire(12 * 3600 * 1000L) }
        } catch (_: Exception) {
        }
        job = scope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                log("Atsaharina.")
                throw e
            } catch (e: Throwable) {
                post(title, "Erreur: ${e.message}")
                Notifier.notify("$title: asa diso", e.message ?: "")
            } finally {
                running.value = false
                try { wake?.release() } catch (_: Exception) { }
                ctx.stopService(Intent(ctx, KeepAliveService::class.java))
            }
        }
    }

    fun stop() { job?.cancel() }
}

fun table(rows: List<List<String>>): String {
    if (rows.isEmpty()) return ""
    val n = rows.maxOf { it.size }
    val w = IntArray(n) { c -> rows.maxOf { r -> r.getOrNull(c)?.length ?: 0 } }
    return rows.joinToString("\n") { r -> r.mapIndexed { i, s -> s.padEnd(w[i]) }.joinToString(" | ") }
}
