package mg.joro.chess.ui

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

/**
 * Theme "Blind": mahaleo tena (tsy manaraka ny light/dark an'ny finday), voafidy ao amin'ny Réglages (UiPrefs.dark).
 * Loko contrast avo + accent maitso.
 */
private val BlindLight: ColorScheme = lightColorScheme(
    primary = Color(0xFF0E7A52), onPrimary = Color.White,
    primaryContainer = Color(0xFFC8F2DE), onPrimaryContainer = Color(0xFF00311E),
    secondary = Color(0xFF3C4F70), onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCE6F8), onSecondaryContainer = Color(0xFF0E1D38),
    tertiary = Color(0xFF8A5300), onTertiary = Color.White,
    background = Color(0xFFF3F5F8), onBackground = Color(0xFF101318),
    surface = Color(0xFFF3F5F8), onSurface = Color(0xFF101318),
    surfaceVariant = Color(0xFFE6EAF0), onSurfaceVariant = Color(0xFF3F4752),
    surfaceTint = Color(0xFF0E7A52),
    outline = Color(0xFF6F7988), outlineVariant = Color(0xFFD3D9E2),
    error = Color(0xFFB3261E), onError = Color.White,
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFFAFBFC),
    surfaceContainer = Color(0xFFFFFFFF), surfaceContainerHigh = Color(0xFFEEF1F5), surfaceContainerHighest = Color(0xFFE5E9EF)
)

private val BlindDark: ColorScheme = darkColorScheme(
    primary = Color(0xFF5EE0A0), onPrimary = Color(0xFF00311B),
    primaryContainer = Color(0xFF12503A), onPrimaryContainer = Color(0xFFC9F7DF),
    secondary = Color(0xFFA9BEE0), onSecondary = Color(0xFF14233A),
    secondaryContainer = Color(0xFF2A3F63), onSecondaryContainer = Color(0xFFDCE6F8),
    tertiary = Color(0xFFFFC56B), onTertiary = Color(0xFF3A2400),
    background = Color(0xFF0E1014), onBackground = Color(0xFFEDEFF3),
    surface = Color(0xFF0E1014), onSurface = Color(0xFFEDEFF3),
    surfaceVariant = Color(0xFF262C34), onSurfaceVariant = Color(0xFFBBC2CD),
    surfaceTint = Color(0xFF5EE0A0),
    outline = Color(0xFF7C8695), outlineVariant = Color(0xFF2E353F),
    error = Color(0xFFFF8A80), onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
    surfaceContainerLowest = Color(0xFF0A0C0F), surfaceContainerLow = Color(0xFF13161B),
    surfaceContainer = Color(0xFF171B21), surfaceContainerHigh = Color(0xFF1E232B), surfaceContainerHighest = Color(0xFF262C35)
)

/** Police lehibe kokoa sy matevina kokoa (hita tsara amin'ny finday) */
private val BlindTypography = Typography(
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)
)

private val BlindShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun BlindTheme(content: @Composable () -> Unit) {
    val dark = UiPrefs.dark
    val scheme = if (dark) BlindDark else BlindLight
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                w.statusBarColor = scheme.background.toArgb()
                w.navigationBarColor = scheme.surfaceContainerLow.toArgb()
                val c = WindowCompat.getInsetsController(w, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(colorScheme = scheme, typography = BlindTypography, shapes = BlindShapes) {
        // Surface = fototra + loko soratra (onBackground) ho an'ny Text rehetra tsy misy loko voafaritra
        Surface(color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground) { content() }
    }
}

/** Loko sokajy (Best, Good, Inaccuracy...) ho soratra: manjavona amin'ny fonosana mazava raha tsy atao manjombona */
@Composable
@ReadOnlyComposable
fun rd(argb: Long): Color {
    val c = Color(argb)
    return if (UiPrefs.dark) lerp(c, Color.White, 0.18f) else lerp(c, Color.Black, 0.50f)
}
