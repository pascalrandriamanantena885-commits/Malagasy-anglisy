package mg.joro.chess.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Loko contrast avo: ny soratra dia mazava foana na light na dark mode (manaraka ny finday). */
private val JoroLight: ColorScheme = lightColorScheme(
    primary = Color(0xFF0B4FB3), onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF), onPrimaryContainer = Color(0xFF001A41),
    secondary = Color(0xFF2F3E57), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD6E4FF), onSecondaryContainer = Color(0xFF001A41),
    tertiary = Color(0xFF6B3F00), onTertiary = Color.White,
    background = Color(0xFFFFFFFF), onBackground = Color(0xFF0D0F12),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF0D0F12),
    surfaceVariant = Color(0xFFE3E8F0), onSurfaceVariant = Color(0xFF22262D),
    surfaceTint = Color(0xFF0B4FB3),
    outline = Color(0xFF4A5260), outlineVariant = Color(0xFF9AA3B0),
    error = Color(0xFFB00020), onError = Color.White,
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF5F7FB),
    surfaceContainer = Color(0xFFEFF2F8), surfaceContainerHigh = Color(0xFFE8ECF4), surfaceContainerHighest = Color(0xFFE1E6F0)
)

private val JoroDark: ColorScheme = darkColorScheme(
    primary = Color(0xFFA9C8FF), onPrimary = Color(0xFF00264F),
    primaryContainer = Color(0xFF0F4A94), onPrimaryContainer = Color(0xFFE6EEFF),
    secondary = Color(0xFFC3D2EC), onSecondary = Color(0xFF14233A),
    secondaryContainer = Color(0xFF2D4670), onSecondaryContainer = Color(0xFFE6EEFF),
    tertiary = Color(0xFFFFC77D), onTertiary = Color(0xFF3A2400),
    background = Color(0xFF0F1114), onBackground = Color(0xFFF7F8FA),
    surface = Color(0xFF0F1114), onSurface = Color(0xFFF7F8FA),
    surfaceVariant = Color(0xFF2B3038), onSurfaceVariant = Color(0xFFE6E9EF),
    surfaceTint = Color(0xFFA9C8FF),
    outline = Color(0xFFA3ACB9), outlineVariant = Color(0xFF5A6370),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
    surfaceContainerLowest = Color(0xFF0A0C0E), surfaceContainerLow = Color(0xFF15181C),
    surfaceContainer = Color(0xFF1B1F24), surfaceContainerHigh = Color(0xFF23282F), surfaceContainerHighest = Color(0xFF2B3139)
)

/** Police lehibe kokoa sy matevina kokoa (hita tsara amin'ny finday) */
private val JoroTypography = Typography(
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun JoroTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (dark) JoroDark else JoroLight, typography = JoroTypography) {
        // Surface = fototra + loko soratra (onBackground) ho an'ny Text rehetra tsy misy loko voafaritra
        Surface(color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground) { content() }
    }
}

/** Loko sokajy (Best, Good, Inaccuracy...) ho soratra: manjavona amin'ny fonosana fotsy raha tsy atao manjombona */
@Composable
@ReadOnlyComposable
fun rd(argb: Long): Color {
    val c = Color(argb)
    return if (isSystemInDarkTheme()) lerp(c, Color.White, 0.18f) else lerp(c, Color.Black, 0.50f)
}
