package mg.joro.chess.match

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** Set paramètre voatahiry (base / release). Dingana: Training (OProfiles) -> SPRT (sprt/sprtOk) -> Apply (defaultId) -> Calibrage (elo) */
data class Profile(
    val id: String, val name: String, val options: Map<String, String>,
    val parent: String = "", val sprt: String = "",
    val sprtOk: Boolean? = null, val elo: Double? = null, val note: String = ""
)

object Nav {
    var tab by mutableIntStateOf(0)
    var sub by mutableIntStateOf(0)       // 0 Pipeline 1 SPRT 2 Matrice 3 Calibrage 4 Tantara
    val sprtA = mutableStateOf("base")
    val sprtB = mutableStateOf("base")
    val calibP = mutableStateOf("base")
    val tc = TcState()
    val playTc = TcState().also { it.ms.value = "1000" }
}

/** Time control iombonana ho an'ny fitsapana rehetra */
class TcState {
    val mode = mutableStateOf("movetime")
    val ms = mutableStateOf("200")
    val base = mutableStateOf("10")
    val inc = mutableStateOf("0.1")
    val nodes = mutableStateOf("100000")
    val depth = mutableStateOf("8")
    fun toTC() = TC(
        ms.value.toIntOrNull() ?: 200, mode.value,
        ((base.value.toDoubleOrNull() ?: 10.0) * 1000).toInt(), ((inc.value.toDoubleOrNull() ?: 0.1) * 1000).toInt(),
        nodes.value.toLongOrNull() ?: 100000L, depth.value.toIntOrNull() ?: 8
    )
}

object Profiles {
    val list = mutableStateListOf<Profile>()
    var defaultId by mutableStateOf("base")
    private var prefs: SharedPreferences? = null

    fun parseLines(t: String): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (l in t.lines()) {
            val s = l.trim()
            if (s.isEmpty() || s.startsWith("#")) continue
            val i = s.indexOf('=')
            if (i > 0) m[s.substring(0, i).trim()] = s.substring(i + 1).trim()
        }
        return m
    }

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)
        prefs = p
        list.clear()
        val arr = JSONArray(p.getString("list", "[]"))
        for (i in 0 until arr.length()) list.add(fromJson(arr.getJSONObject(i)))
        if (list.none { it.id == "base" }) list.add(0, Profile("base", "base", emptyMap(), note = "moteur tsy voatsindry"))
        val txt = try { ctx.assets.open("default_profile.txt").bufferedReader().readText() } catch (e: Exception) { "" }
        val o = parseLines(txt)
        if (o.isNotEmpty()) {
            val old = get("release")
            if (old == null) list.add(Profile("release", "release", o, note = "avy amin'ny APK"))
            else update("release") { it.copy(options = o) }
        }
        defaultId = p.getString("default", null) ?: if (get("release") != null) "release" else "base"
        if (get(defaultId) == null) defaultId = "base"
        save()
    }

    fun get(id: String): Profile? = list.firstOrNull { it.id == id }
    fun optionsOf(id: String): Map<String, String> = get(id)?.options ?: emptyMap()
    fun add(p: Profile) { list.add(p); save() }
    fun update(id: String, f: (Profile) -> Profile) {
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) { list[i] = f(list[i]); save() }
    }
    fun remove(id: String) {
        if (id == "base" || id == "release") return
        list.removeAll { it.id == id }
        if (defaultId == id) setDefault("base")
        save()
    }
    fun setDefault(id: String) { defaultId = id; prefs?.edit()?.putString("default", id)?.apply() }
    fun lines(p: Profile): String = p.options.entries.joinToString("\n") { "${it.key}=${it.value}" }

    private fun save() {
        val arr = JSONArray()
        for (p in list) {
            val j = JSONObject().put("id", p.id).put("name", p.name).put("opts", JSONObject(p.options))
                .put("parent", p.parent).put("sprt", p.sprt).put("note", p.note)
            p.sprtOk?.let { j.put("ok", it) }
            p.elo?.let { j.put("elo", it) }
            arr.put(j)
        }
        prefs?.edit()?.putString("list", arr.toString())?.apply()
    }

    private fun fromJson(j: JSONObject): Profile {
        val o = LinkedHashMap<String, String>()
        val oj = j.optJSONObject("opts")
        if (oj != null) for (k in oj.keys()) o[k] = oj.getString(k)
        return Profile(j.getString("id"), j.getString("name"), o, j.optString("parent"),
            j.optString("sprt"), if (j.has("ok")) j.getBoolean("ok") else null,
            if (j.has("elo")) j.getDouble("elo") else null, j.optString("note"))
    }
}
