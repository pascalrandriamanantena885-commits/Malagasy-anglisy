package mg.joro.chess.match

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Game
import mg.joro.chess.chess.Res

/** Lalao: olona vs moteur (horloge, undo, promotion, FEN/PGN, lisitry ny hetsika azo tsindrina) */
object Play {
    var game by mutableStateOf<Game?>(null)
    var rev by mutableIntStateOf(0)
    var human by mutableIntStateOf(0)
    var info by mutableStateOf("")
    var status by mutableStateOf("")
    var thinking by mutableStateOf(false)
    var selected by mutableIntStateOf(-1)
    var targets by mutableStateOf(setOf<Int>())
    var pendingPromo by mutableStateOf(listOf<Int>())
    val sans = mutableStateListOf<String>()
    var viewPly by mutableIntStateOf(-1)          // -1 = lalao ankehitriny
    var viewBoard by mutableStateOf<Board?>(null)
    var wClock by mutableIntStateOf(0)
    var bClock by mutableIntStateOf(0)
    var tc by mutableStateOf(TC())
    var names by mutableStateOf(Pair("", ""))
    var savedId by mutableStateOf<String?>(null)   // lalao vita voatahiry (ho an'ny Review)
    private var player: Player? = null
    private var job: Job? = null
    private var ticker: Job? = null
    private var lastTick = 0L

    fun stop() {
        job?.cancel(); ticker?.cancel(); player?.close(); player = null; thinking = false
    }

    fun start(spec: EngineSpec, humanColor: Int, tc: TC, initial: PgnLine? = null) {
        stop()
        human = humanColor; this.tc = tc; savedId = null
        selected = -1; targets = emptySet(); pendingPromo = emptyList(); viewPly = -1; viewBoard = null
        info = ""; status = "Manomboka..."
        names = if (humanColor == 0) Pair("Anao", spec.label) else Pair(spec.label, "Anao")
        job = Host.scope.launch {
            try {
                val p = Player(spec)
                p.open()
                p.eng.newGame()
                player = p
                val g = Game(initial?.startFen ?: Board.START)
                sans.clear()
                if (initial != null) for (u in initial.moves) {
                    val m = g.board.parseMove(u) ?: break
                    sans.add(g.board.san(m)); g.play(m)
                }
                game = g
                wClock = tc.base; bClock = tc.base
                lastTick = System.nanoTime()
                rev++
                status = ""
                startTicker()
                engineTurn()
            } catch (e: Exception) {
                status = "Erreur: ${e.message}"
            }
        }
    }

    private fun startTicker() {
        ticker?.cancel()
        if (!tc.clocked) return
        ticker = Host.scope.launch {
            while (true) {
                delay(100)
                val g = game ?: continue
                if (g.result != Res.ONGOING) continue
                val now = System.nanoTime()
                val dt = ((now - lastTick) / 1_000_000L).toInt()
                lastTick = now
                if (g.board.stm == 0) wClock -= dt else bClock -= dt
                if (wClock <= 0) { g.end(Res.BLACK, "temps"); rev++; finish() }
                else if (bClock <= 0) { g.end(Res.WHITE, "temps"); rev++; finish() }
            }
        }
    }

    private fun commit(m: Int) {
        val g = game ?: return
        val mover = g.board.stm
        sans.add(g.board.san(m))
        g.play(m)
        if (tc.clocked) { if (mover == 0) wClock += tc.inc else bClock += tc.inc }
        lastTick = System.nanoTime()
        viewPly = -1; viewBoard = null
        rev++
        finish()
    }

    private suspend fun engineTurn() {
        val g = game ?: return
        val p = player ?: return
        if (g.result != Res.ONGOING || g.board.stm == human) { finish(); return }
        thinking = true
        val clock = if (g.board.stm == 0) wClock else bClock
        val r = p.eng.go(g.startFen, g.moves, tc.goArgs(wClock, bClock), tc.timeout(clock)) { info = it.text() }
        thinking = false
        if (g.result != Res.ONGOING) return
        val m = r.move?.let { g.board.parseMove(it) }
        if (m == null) { status = "Ny moteur dia tsy namaly tsara (${r.status})"; return }
        commit(m)
    }

    @Synchronized
    private fun finish() {
        val g = game ?: return
        if (g.result == Res.ONGOING) return
        status = g.text()
        if (savedId == null && g.moves.isNotEmpty())
            savedId = ReviewStore.addGame("Milalao", names.first, names.second, g.text(), g.result, g.startFen, g.moves.toList(), human == 1).id
    }

    fun resign() {
        game?.let { if (it.result == Res.ONGOING) { it.end(if (human == 0) Res.BLACK else Res.WHITE, "abandon"); rev++; finish() } }
    }

    private fun rebuild(startFen: String, moves: List<String>): Game {
        val g = Game(startFen)
        for (u in moves) { val m = g.board.parseMove(u) ?: break; g.play(m) }
        return g
    }

    /** Mamerina hetsika hatramin'ny mandra-pahatonga ny anao */
    fun undo() {
        val g = game ?: return
        if (thinking || g.moves.isEmpty()) return
        var n = g.moves.size - 1
        var ng = rebuild(g.startFen, g.moves.take(n))
        while (n > 0 && ng.board.stm != human) { n--; ng = rebuild(g.startFen, g.moves.take(n)) }
        game = ng
        while (sans.size > n) sans.removeAt(sans.size - 1)
        selected = -1; targets = emptySet(); pendingPromo = emptyList(); viewPly = -1; viewBoard = null; status = ""; savedId = null
        if (tc.clocked) { if (wClock < 5000) wClock = 5000; if (bClock < 5000) bClock = 5000 }
        lastTick = System.nanoTime()
        rev++
        if (ng.board.stm != human && ng.result == Res.ONGOING) job = Host.scope.launch { engineTurn() }
    }

    /** Jereo ny toerana aorian'ny `ply` hetsika (>= isa = miverina amin'ny ankehitriny) */
    fun view(ply: Int) {
        val g = game ?: return
        if (ply >= g.moves.size) { viewPly = -1; viewBoard = null; return }
        var b = Board.fromFen(g.startFen)
        for (u in g.moves.take(ply)) { val m = b.parseMove(u) ?: break; b = b.play(m) }
        viewBoard = b; viewPly = ply; selected = -1; targets = emptySet()
    }

    fun pgn(): String {
        val g = game ?: return ""
        return Pgn.build(g.startFen, g.moves, names.first, names.second, g.result, g.reason)
    }

    private fun playHuman(m: Int) {
        selected = -1; targets = emptySet(); pendingPromo = emptyList()
        commit(m)
        job = Host.scope.launch { engineTurn() }
    }

    fun promote(p: Int) {
        val m = pendingPromo.firstOrNull { Board.promo(it) == p } ?: return
        playHuman(m)
    }

    fun tap(s: Int) {
        val g = game ?: return
        if (g.result != Res.ONGOING || thinking || g.board.stm != human || viewPly >= 0) return
        val b = g.board
        val legal = b.legalMoves()
        if (selected >= 0) {
            val c = legal.filter { Board.from(it) == selected && Board.to(it) == s }
            if (c.size > 1) { pendingPromo = c; return }
            if (c.size == 1) { playHuman(c[0]); return }
        }
        val p = b.sq[s]
        if (p != 0 && (p shr 3) == human) {
            selected = s
            targets = legal.filter { Board.from(it) == s }.map { Board.to(it) }.toSet()
        } else { selected = -1; targets = emptySet() }
    }
}
