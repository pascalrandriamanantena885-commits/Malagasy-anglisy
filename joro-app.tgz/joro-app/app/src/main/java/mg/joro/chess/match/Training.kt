package mg.joro.chess.match

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Game
import mg.joro.chess.chess.Res

/** Andalana soso-kevitra: azo atao on/off sy ovaina ny lanja vaovao */
class PropRow(val p: Proposal) {
    var nw by mutableIntStateOf(p.new)
    var on by mutableStateOf(true)
}

/** Tanjona: defense hofafana (case + karazana pièce + isan'ny pièce karazany ao amin'ny toerana nanombohan'ny tanjona) */
class Mission(val sq: Int, val pc: Char, val color: Int, val startMoves: List<String>, val startCnt: Int, val startEta: Int)

/**
 * Fampiofanana opening: lalao an-tanana / moteur / Stockfish move par move, statistique (evaltrace) isaky ny position,
 * fianarana avy amin'ny fandresena farany, profil provisoire, SPRT (opening ihany) ary Update / Delete experience.
 */
object Training {
    var game by mutableStateOf<Game?>(null)
    var rev by mutableIntStateOf(0)
    var statRev by mutableIntStateOf(0)
    var startFen by mutableStateOf(Board.START)
    var startName by mutableStateOf("")
    var trained by mutableIntStateOf(0)          // sisiny ampiofanina: 0 fotsy, 1 mainty
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var info by mutableStateOf("")
    var selected by mutableIntStateOf(-1)
    var targets by mutableStateOf(setOf<Int>())
    var pendingPromo by mutableStateOf(listOf<Int>())
    var cur by mutableStateOf<Trace?>(null)
    var searchStat by mutableStateOf<Map<String, Long>>(emptyMap())
    var learnMsg by mutableStateOf("")
    val sans = mutableStateListOf<String>()
    val rows = mutableStateListOf<PropRow>()
    val moteurMs = mutableStateOf("1000")
    val rate = mutableStateOf("1.0")

    // ---------- Ghost / Race view, fanapahan-kevitra (decision) ary tanjona (mission) ----------
    var mode by mutableIntStateOf(0)              // 0 Normal, 1 Ghost, 2 Race
    var viewRev by mutableIntStateOf(0)
    var ghost by mutableStateOf<GhostView?>(null)
    var race by mutableStateOf<RaceView?>(null)
    var power by mutableStateOf<PowerView?>(null)
    // fanamboarana SPRT (iombonana amin'ny "Apply" sy ny bokotra ▶ SPRT)
    val sprtElo0 = mutableStateOf("0")
    val sprtElo1 = mutableStateOf("5")
    val sprtMax = mutableStateOf("200")
    val sprtWorkers = mutableStateOf("2")          // isan'ny lalao miaraka (parallèle)
    var autoSprt by mutableStateOf(true)           // alefa ho azy ny SPRT aorian'ny "Apply (provisoire)"
    var powerSel by mutableIntStateOf(-1)          // case an'ny pièce voafidy ao amin'ny Power view
    var ghostSide by mutableIntStateOf(0)         // sisiny mpanafika (Ghost view)
    var ghostKing by mutableIntStateOf(-1)        // toerana king what-if (-1 = ny tena izy)
    var kingSel by mutableStateOf(false)
    var ghostHide by mutableStateOf(false)        // hanafina ny defense (board ghost)
    var showHeat by mutableStateOf(false)
    var raceSide by mutableIntStateOf(0)
    var planSel by mutableIntStateOf(0)
    var decision by mutableIntStateOf(0)          // 0 auto, 1 care, 2 letgo, 3 take
    var viewMsg by mutableStateOf("")
    var mission by mutableStateOf<Mission?>(null)
    private var forkPly = -1

    private val traces = java.util.concurrent.ConcurrentHashMap<Int, Trace>()
    private var params: Map<String, ParamInfo> = emptyMap()
    private var blind: Player? = null
    private var sf: Player? = null
    private val lock = Mutex()
    private var job: Job? = null
    private var won = false

    fun pid(): String = OProfiles.idOf(startName, trained)
    private fun sg(): Int = if (trained == 0) 1 else -1

    /** Salan'ny feature (araka ny sisiny ampiofanina) amin'ny toerana rehetra efa nilalaovana */
    fun mean(name: String): Double {
        var s = 0.0
        var n = 0
        for ((ply, t) in traces) {
            if (ply < 1) continue
            n++
            val f = t.feats[name]
            if (f != null && f.active) s += sg() * f.net
        }
        return if (n == 0) 0.0 else s / n
    }

    fun isNew(name: String): Boolean {
        val seen: Set<String> = OProfiles.get(pid())?.seen ?: emptySet()
        return seen.isNotEmpty() && !seen.contains(name)
    }

    private fun posCmd(fen: String, moves: List<String>): String =
        "position fen $fen" + (if (moves.isNotEmpty()) " moves " + moves.joinToString(" ") else "")

    private fun closePlayers() {
        try { blind?.close() } catch (_: Exception) { }
        try { sf?.close() } catch (_: Exception) { }
        blind = null; sf = null
    }

    fun stop() {
        job?.cancel()
        closePlayers()
        busy = false
    }

    fun begin(fen: String, name: String, side: Int) {
        stop()
        val g = try { Game(fen) } catch (e: Exception) { status = "FEN diso"; return }
        startFen = fen; startName = name; trained = side
        traces.clear(); rows.clear(); sans.clear()
        learnMsg = ""; cur = null; searchStat = emptyMap(); won = false; info = ""
        mode = 0; ghost = null; race = null; ghostKing = -1; kingSel = false; ghostHide = false; showHeat = false
        mission = null; viewMsg = ""; decision = 0; forkPly = -1; ghostSide = side; raceSide = side; planSel = 0
        selected = -1; targets = emptySet(); pendingPromo = emptyList()
        game = g
        rev++
        status = "Manomboka ny moteur..."
        job = Host.scope.launch {
            try {
                lock.withLock { ensureBlind() }
                status = ""
                refreshStats()
            } catch (e: Exception) {
                status = "Erreur: ${e.message}"
            }
        }
    }

    // ---------- moteur ----------
    private suspend fun ensureBlind(): Player {
        val have = blind
        if (have != null) return have
        val spec = Host.spec("builtin", "Opening=true;Book=false;PowerOn=1", "@default") ?: throw IllegalStateException("Tsy misy moteur Blind")
        val p = Player(spec)
        p.open()
        if (params.isEmpty()) params = TraceParse.params(p.eng.collect(listOf("params")))
        p.eng.newGame()
        blind = p
        return p
    }

    private suspend fun ensureSf(): Player {
        val have = sf
        if (have != null) return have
        val spec = Host.spec("stockfish", "") ?: throw IllegalStateException("Tsy misy Stockfish")
        val p = Player(spec)
        p.open()
        sf = p
        return p
    }

    private suspend fun refreshStats() {
        val g = game ?: return
        val ply = g.moves.size
        val lines = lock.withLock {
            val p = ensureBlind()
            p.eng.collect(listOf(posCmd(g.startFen, g.moves.toList()), "evaltrace"))
        }
        val t = TraceParse.trace(lines)
        if (t != null && game === g && g.moves.size == ply) {
            traces[ply] = t
            cur = t
        }
        statRev++
    }

    /** which: 0 = moteur Blind, 1 = Stockfish (limit strength). Hetsika iray ihany (tsy continu). */
    fun engineMove(which: Int) {
        val g = game ?: return
        if (busy || g.result != Res.ONGOING) return
        busy = true
        selected = -1; targets = emptySet(); pendingPromo = emptyList()
        status = ""
        job = Host.scope.launch {
            try {
                val ms = (moteurMs.value.toIntOrNull() ?: 1000).coerceIn(10, 60000)
                val moves = g.moves.toList()
                var best: String? = null
                var stats: Map<String, Long>? = null
                if (which == 0) {
                    lock.withLock {
                        val p = ensureBlind()
                        sendGuidance(p, g.board.stm == trained)
                        val r = p.eng.go(g.startFen, moves, "movetime $ms", ms + 10_000L) { info = "Blind " + it.text() }
                        best = r.move
                        stats = TraceParse.stats(p.eng.collect(listOf("searchstats")))
                    }
                } else {
                    // Stockfish ao amin'ny Training dia hery MAX foana (tsy voafetra)
                    val o: Map<String, String> = mapOf("UCI_LimitStrength" to "false")
                    lock.withLock {
                        val p = ensureSf()
                        p.setAll(o)
                        val r = p.eng.go(g.startFen, moves, "movetime $ms", ms + 10_000L) { info = "SF " + it.text() }
                        best = r.move
                    }
                }
                val m = best?.let { g.board.parseMove(it) }
                if (m == null || game !== g) {
                    status = "Tsy nahavita hetsika ny moteur"
                } else {
                    if (stats != null) searchStat = stats!!
                    play(m)
                }
            } catch (e: Exception) {
                status = "Erreur: ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    // ---------- olona (Manuel) ----------
    fun tap(s: Int) {
        val g = game ?: return
        if (g.result != Res.ONGOING || busy) return
        val b = g.board
        val legal = b.legalMoves()
        if (selected >= 0) {
            val c = legal.filter { Board.from(it) == selected && Board.to(it) == s }
            if (c.size > 1) { pendingPromo = c; return }
            if (c.size == 1) { play(c[0]); return }
        }
        val p = b.sq[s]
        if (p != 0 && (p shr 3) == b.stm) {
            selected = s
            targets = legal.filter { Board.from(it) == s }.map { Board.to(it) }.toSet()
        } else {
            selected = -1; targets = emptySet()
        }
    }

    fun promote(p: Int) {
        val m = pendingPromo.firstOrNull { Board.promo(it) == p } ?: return
        play(m)
    }

    private fun play(m: Int) {
        val g = game ?: return
        selected = -1; targets = emptySet(); pendingPromo = emptyList()
        sans.add(g.board.san(m))
        g.play(m)
        rev++
        checkEnd(g)
        if (mode != 0) refreshView()
        job = Host.scope.launch {
            try { refreshStats() } catch (e: Exception) { status = "Erreur: ${e.message}" }
        }
    }

    private fun checkEnd(g: Game) {
        if (g.result == Res.ONGOING) { status = ""; return }
        val tw = (g.result == Res.WHITE && trained == 0) || (g.result == Res.BLACK && trained == 1)
        won = tw
        status = g.text() + (if (tw) " — fandresena ✔" else if (g.result == Res.DRAW) " — nul" else " — resy ✗ (Undo na avereno)")
    }

    /** Ekena ho fandresena ny toerana ankehitriny (ohatra rehefa mazava fa resy tanteraka ny mpifanandrina) */
    fun markWin() {
        val g = game ?: return
        if (busy || g.result != Res.ONGOING) return
        g.end(if (trained == 0) Res.WHITE else Res.BLACK, "fandresena (nekena)")
        rev++
        checkEnd(g)
    }

    fun undo() {
        val g = game ?: return
        if (busy || g.moves.isEmpty()) return
        val keep = g.moves.take(g.moves.size - 1)
        val ng = Game(g.startFen)
        for (u in keep) {
            val m = ng.board.parseMove(u) ?: break
            ng.play(m)
        }
        game = ng
        while (sans.size > keep.size) sans.removeAt(sans.size - 1)
        traces.remove(keep.size + 1)
        selected = -1; targets = emptySet(); pendingPromo = emptyList()
        won = false; rows.clear(); learnMsg = ""
        rev++
        checkEnd(ng)
        cur = traces[keep.size]
        if (mode != 0) {
            if (forkPly > keep.size) forkPly = keep.size
            ghostKing = -1; kingSel = false
            refreshView()
        }
        if (cur == null) {
            job = Host.scope.launch {
                try { refreshStats() } catch (e: Exception) { status = "Erreur: ${e.message}" }
            }
        } else {
            statRev++
        }
    }

    // ---------- Ghost / Race view ----------
    private fun nm(s: Int): String = ViewParse.sqName(s)
    private fun pieceCode(pc: Char, color: Int): Int = (color shl 3) + ("PNBRQK".indexOf(pc) + 1)
    private fun countOf(b: Board, pc: Char, color: Int): Int {
        val code = pieceCode(pc, color)
        var n = 0
        for (v in b.sq) if (v == code) n++
        return n
    }

    /** Sokafana ny view (Ghost = 1, Race = 2). Ny hetsika rehetra aorian'izay dia sandbox hatramin'ny Apply na Annuler. */
    fun openView(m: Int) {
        val g = game ?: return
        if (busy) return
        if (mode == 0) forkPly = g.moves.size
        mode = m
        ghostKing = -1; kingSel = false; planSel = 0; powerSel = -1
        viewMsg = ""
        refreshView()
    }

    /** Apply: tazonina ao amin'ny lalao ny hetsika natao tao amin'ny sandbox; mijanona ny fanapahan-kevitra sy ny tanjona. */
    fun applyView() {
        if (mode == 0) return
        mode = 0; forkPly = -1; ghost = null; race = null; power = null; ghostKing = -1; kingSel = false
        viewMsg = "Nampiharina ao amin'ny lalao."
        viewRev++
    }

    /** Annuler: miverina amin'ny toerana nisokafan'ny view (foanana ny hetsika sandbox) */
    fun cancelView() {
        val g = game ?: return
        if (mode == 0 || busy) return
        val keep = g.moves.take(forkPly.coerceIn(0, g.moves.size))
        val ng = Game(g.startFen)
        for (u in keep) {
            val m = ng.board.parseMove(u) ?: break
            ng.play(m)
        }
        game = ng
        while (sans.size > keep.size) sans.removeAt(sans.size - 1)
        for (ply in keep.size + 1..g.moves.size) traces.remove(ply)
        mode = 0; forkPly = -1; ghost = null; race = null; power = null; ghostKing = -1; kingSel = false
        selected = -1; targets = emptySet(); pendingPromo = emptyList(); won = false; rows.clear(); learnMsg = ""
        viewMsg = "Nofoanana ny hetsika sandbox."
        rev++
        checkEnd(ng)
        cur = traces[keep.size]
        if (cur == null) {
            job = Host.scope.launch { try { refreshStats() } catch (e: Exception) { status = "Erreur: ${e.message}" } }
        } else {
            statRev++
        }
    }

    fun chooseGhostSide(s: Int) { ghostSide = s; ghostKing = -1; kingSel = false; refreshView() }
    fun chooseRaceSide(s: Int) { raceSide = s; planSel = 0; viewRev++ }
    fun toggleHide() { ghostHide = !ghostHide; kingSel = false; viewRev++ }
    fun toggleHeat() { showHeat = !showHeat; refreshView() }
    fun resetGhostKing() { ghostKing = -1; kingSel = false; refreshView() }

    /** Tsindrio ny king mpanohitra, avy eo ny case iray: what-if (board ghost ihany) */
    fun ghostTap(s: Int) {
        val v = ghost ?: return
        val curK = if (ghostKing >= 0) ghostKing else v.realKing
        if (!kingSel) {
            if (s == curK) kingSel = true
            return
        }
        kingSel = false
        if (s == curK) return
        ghostKing = if (s == v.realKing) -1 else s
        refreshView()
    }

    fun refreshView() {
        val g = game ?: return
        val m = mode
        if (m == 0) return
        Host.scope.launch {
            try {
                val moves = g.moves.toList()
                val cmds = ArrayList<String>()
                cmds.add(posCmd(g.startFen, moves))
                if (m == 1) {
                    var c = "ghostview " + (if (ghostSide == 0) "w" else "b")
                    if (ghostKing >= 0) c += " king " + nm(ghostKing)
                    if (showHeat) c += " heat"
                    cmds.add(c)
                } else if (m == 2) {
                    cmds.add("raceview")
                } else {
                    cmds.add("powerview")
                }
                val lines = lock.withLock {
                    val p = ensureBlind()
                    p.eng.collect(cmds)
                }
                if (game === g && g.moves.size == moves.size && mode == m) {
                    if (m == 1) {
                        ghost = ViewParse.ghost(lines)
                        if (ghost == null) viewMsg = "Tsy azo ny Ghost view (case tsy mety?)" else viewMsg = ""
                    } else if (m == 2) {
                        race = ViewParse.race(lines)
                    } else {
                        power = ViewParse.power(lines)
                    }
                    viewRev++
                }
            } catch (e: Exception) {
                viewMsg = "Erreur: ${e.message}"
            }
        }
    }

    // ---------- fanapahan-kevitra (decision) ----------
    fun decisionName(d: Int): String = when (d) { 1 -> "care"; 2 -> "letgo"; 3 -> "take"; else -> "auto" }

    fun chooseDecision(d: Int) {
        decision = d
        viewMsg = when (d) {
            1 -> "CARE: mitandrina ny ataka mpanohitra."
            2 -> "LET IT GO: avela handeha ny ataka mpanohitra, mitohy ny ataka ho ahy."
            3 -> "LET IT TAKE: avela haka ny pièce ahy (sacrifice) mba hahazoana ny ataka."
            else -> "AUTO: ny moteur ihany no mamaritra."
        }
    }

    /** Alefa alohan'ny `go`: fanapahan-kevitra + tanjona ho an'ny hetsika ataon'ny sisiny ampiofanina (ny hafa: auto) */
    private suspend fun sendGuidance(p: Player, mine: Boolean) {
        if (mine) {
            p.eng.send("decision " + decisionName(decision) + " " + (if (trained == 0) "w" else "b"))
            val ms = mission
            if (ms != null) {
                p.eng.send(posCmd(startFen, ms.startMoves))
                p.eng.send("target " + nm(ms.sq))
            } else {
                p.eng.send("target off")
            }
        } else {
            p.eng.send("decision auto")
            p.eng.send("target off")
        }
    }

    // ---------- soso-kevitra avy amin'ny Race ----------
    private fun decisionCode(n: String): Int = when (n) { "care" -> 1; "letgo" -> 2; "take" -> 3; else -> 0 }

    /** Fanapahan-kevitra naroson'ny moteur ho an'ny sisiny ampiofanina (-1 raha tsy misy Race view) */
    fun suggestedCode(): Int {
        val rv = race ?: return -1
        val sg = rv.suggest[trained] ?: return -1
        return decisionCode(sg.first)
    }

    fun applySuggestion() {
        val c = suggestedCode()
        if (c < 0) { viewMsg = "Tsy misy soso-kevitra (sokafy ny Race view)."; return }
        chooseDecision(c)
    }

    /** Defense mora indrindra hofafana: fanalana mora + power kely (+ laharana ambony raha ao amin'ny top 3 an'ny ETA) */
    fun easiestTarget(defs: List<DefInfo>): DefInfo? {
        var best: DefInfo? = null
        var bestKey = Int.MAX_VALUE
        for (d in defs) {
            val key = d.cost * 100 + (if (d.pw >= 0) d.pw else 50) - (if (d.top) 15 else 0)
            if (key < bestKey) { bestKey = key; best = d }
        }
        return best
    }

    fun autoTarget(attacker: Int) {
        val defs: List<DefInfo> = if (mode == 2) (race?.sides?.firstOrNull { it.side == attacker }?.defs ?: emptyList()) else (ghost?.defs ?: emptyList())
        val d = easiestTarget(defs)
        if (d == null) { viewMsg = "Tsy misy defense hofafana."; return }
        setTarget(d, attacker)
    }

    // ---------- tanjona: fanalana defense -----------
    fun setTarget(d: DefInfo, attacker: Int) {
        val g = game ?: return
        if (attacker != trained) { viewMsg = "Ny tanjona dia ho an'ny sisiny ampiofanina: safidio azy ho mpanafika."; return }
        val enemy = attacker xor 1
        val eta0 = if (mode == 2) (race?.sides?.firstOrNull { it.side == attacker }?.eta ?: 40) else (ghost?.eta ?: 40)
        mission = Mission(d.sq, d.pc, enemy, g.moves.toList(), countOf(g.board, d.pc, enemy), eta0)
        viewMsg = "Tanjona: ${d.pc}${nm(d.sq)}. Alefaso ny Moteur ▶ (na Manuel / SF)."
    }

    fun clearTarget() { mission = null; viewMsg = "Voafafa ny tanjona." }

    fun missionDone(): Boolean {
        val ms = mission ?: return false
        val g = game ?: return false
        return countOf(g.board, ms.pc, ms.color) < ms.startCnt
    }

    // ---------- fisehoana (board, overlay) ----------
    /** Board ghost: miala ny pièce mpanohitra rehetra afa-tsy ny king (azo afindra: what-if) */
    fun ghostBoard(): Board {
        val g = game!!
        val b = g.board
        val arr = b.sq.copyOf()
        val enemy = ghostSide xor 1
        var kingAt = -1
        for (i in 0..63) {
            val v = arr[i]
            if (v == 0 || (v shr 3) != enemy) continue
            if ((v and 7) == 6) kingAt = i else arr[i] = 0
        }
        if (ghostKing >= 0 && kingAt >= 0 && arr[ghostKing] == 0) {
            arr[ghostKing] = arr[kingAt]
            arr[kingAt] = 0
        }
        return Board(arr, b.stm, 0, -1, 0, 1)
    }

    private fun kingZone(b: Board, color: Int): List<Int> {
        val code = (color shl 3) + 6
        var k = -1
        for (i in 0..63) if (b.sq[i] == code) k = i
        if (k < 0) return emptyList()
        val out = ArrayList<Int>()
        for (dr in -1..1) for (df in -1..1) {
            val r = k / 8 + dr
            val f = k % 8 + df
            if (r in 0..7 && f in 0..7) out.add(r * 8 + f)
        }
        return out
    }

    /** Loko eo ambony case: zone, ghost cover, real cover, blocked, free, heatmap (ARGB) */
    fun overlay(): Map<Int, Long> {
        val m = HashMap<Int, Long>()
        val g = game ?: return m
        if (mode == 1) {
            val v = ghost ?: return m
            for (s in v.zone) m[s] = 0x33B0BEC5L
            for (s in v.blocked) m[s] = 0x66FFB300L
            for (s in v.free) m[s] = 0x66FF5252L
            for (s in v.gcov) m[s] = 0x667C4DFFL
            for (s in v.rcov) m[s] = 0x6600E676L
            if (showHeat && v.heat.isNotEmpty()) {
                var mx = 1
                for (sc in v.heat.values) if (sc > mx) mx = sc
                for ((s, sc) in v.heat) {
                    val a = 0x20 + (0x90 * sc / mx)
                    m[s] = (a.toLong() shl 24) or 0xFF5252L
                }
            }
        } else if (mode == 3) {
            val pv = power ?: return m
            val sel = pv.pieces.firstOrNull { it.sq == powerSel }
            if (sel != null) {
                for (s in sel.dutySq) m[s] = 0x44FFB300L
                for (s in sel.xrSq) m[s] = 0x663D5AFEL
                for (s in sel.libSq) m[s] = 0x6600E676L
            }
        } else if (mode == 2) {
            val rv = race ?: return m
            val enemy = raceSide xor 1
            for (s in kingZone(g.board, enemy)) m[s] = 0x33B0BEC5L
            val rs = rv.sides.firstOrNull { it.side == raceSide }
            if (rs != null) for (d in rs.defs) m[d.sq] = if (d.cost == 1) 0x6600E676L else if (d.cost == 2) 0x66FFB300L else 0x66FF5252L
        }
        return m
    }

    /** Peratra manodidina pièce: future (mavo), tanjona (mena), plan voafidy (mavo) */
    fun rings(): Map<Int, Long> {
        val m = HashMap<Int, Long>()
        if (mode == 1) {
            val v = ghost
            if (v != null) for (f in v.future) m[f.second] = 0xFFFFD54FL
        } else if (mode == 3) {
            val pv = power
            if (pv != null) {
                for (pp in pv.pieces) {
                    if (pp.pc == 'K') continue
                    if (pp.power < 33) m[pp.sq] = 0xAAFF5252L else if (pp.power >= 66) m[pp.sq] = 0x8800E676L
                }
                if (powerSel >= 0) m[powerSel] = 0xFFFFD54FL
            }
        } else if (mode == 2) {
            val rv = race
            val rs = rv?.sides?.firstOrNull { it.side == raceSide }
            if (rs != null && planSel in rs.plans.indices) for (pp in rs.plans[planSel].pieces) m[pp.sq] = 0xFFFFD54FL
        }
        val ms = mission
        if (ms != null) m[ms.sq] = 0xFFFF1744L
        return m
    }

    // ---------- fianarana avy amin'ny fandresena farany ----------
    fun learn() {
        val g = game ?: return
        if (busy) return
        if (g.result == Res.ONGOING || !won) { learnMsg = "Mila lalao vita amin'ny fandresena aloha (na tsindrio 'Fandresena')."; return }
        busy = true
        learnMsg = "Mandrefy ny toerana rehetra..."
        job = Host.scope.launch {
            try {
                val moves = g.moves.toList()
                for (ply in 1..moves.size) {
                    if (traces[ply] == null) {
                        val lines = lock.withLock {
                            val p = ensureBlind()
                            p.eng.collect(listOf(posCmd(g.startFen, moves.take(ply)), "evaltrace"))
                        }
                        val t = TraceParse.trace(lines)
                        if (t != null) traces[ply] = t
                    }
                }
                val items = ArrayList<Pair<Trace, Int>>()
                for (ply in 1..moves.size) {
                    val t = traces[ply]
                    if (t != null) items.add(Pair(t, sg()))
                }
                val op = OProfiles.get(pid())
                val curOv: Map<String, Int> = op?.prov ?: op?.active ?: emptyMap()
                val seen: Set<String> = op?.seen ?: emptySet()
                val props = Learn.propose(items, params, curOv, seen, rate.value.toDoubleOrNull() ?: 1.0)
                rows.clear()
                for (p in props) rows.add(PropRow(p))
                learnMsg = "${items.size} toerana · ${props.size} lanja soso-kevitra" +
                    if (props.isEmpty()) " (tsy nisy fiovana mazava; andramo lalao hafa)" else ""
                statRev++
            } catch (e: Exception) {
                learnMsg = "Erreur: ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    /** Apply provisoire: mitahiry profil provisoire (mbola tsy update moteur) */
    fun applyProvisional(tc: TC? = null): String {
        val id = pid()
        val old = OProfiles.get(id)
        val ov = LinkedHashMap<String, Int>()
        val base: Map<String, Int> = old?.prov ?: old?.active ?: emptyMap()
        ov.putAll(base)
        var n = 0
        for (r in rows) {
            if (r.on && r.nw != r.p.old) { ov[r.p.name] = r.nw; n++ }
        }
        if (n == 0) return "Tsy misy fiovana nofidina."
        var usesPower = false
        for (r in rows) if (r.on && r.nw != r.p.old && r.p.group == "power") usesPower = true
        if (usesPower) ov["PowerOn"] = 1          // ny lanja Piece Power dia tsy mihetsika raha tsy PowerOn=1
        val seen = LinkedHashSet<String>()
        if (old != null) seen.addAll(old.seen)
        for (t in traces.values) for ((k, f) in t.feats) if (f.active) seen.add(k)
        val np = (old ?: OpProfile(id, startName, startFen, trained))
            .copy(name = startName, fen = startFen, side = trained, prov = ov, seen = seen, sprt = "", sprtOk = null)
        OProfiles.put(np)
        val saved = "Profil provisoire '$id' voatahiry ($n lanja)."
        if (!autoSprt || tc == null) return "$saved Alefaso ny SPRT."
        return if (startSprt(id, tc)) "$saved SPRT natomboka ho azy." else "$saved Asa hafa mbola mandeha: alefaso ny SPRT rehefa vita."
    }

    /** SPRT amin'ny fanamboarana ankehitriny (Elo0/Elo1/max/miaraka). false raha mbola misy asa mandeha (na tsy misy provisoire). */
    fun startSprt(id: String, tc: TC): Boolean {
        if (Host.running.value) return false
        if (OProfiles.get(id)?.prov == null) return false
        runSprt(id, sprtElo0.value.toDoubleOrNull() ?: 0.0, sprtElo1.value.toDoubleOrNull() ?: 5.0,
            (sprtMax.value.toIntOrNull() ?: 200).coerceAtLeast(2), tc, sprtWorkers.value.toIntOrNull() ?: 2)
        return true
    }

    // ---------- SPRT (opening ihany): provisoire vs taloha — parallèle ----------
    private class Duo(val a: Player, val b: Player)

    fun runSprt(id: String, elo0: Double, elo1: Double, maxGames: Int, tc: TC, workers: Int = 2) {
        val op = OProfiles.get(id) ?: return
        val prov = op.prov ?: return
        val nW = ParSprt.clampWorkers(workers)
        Host.launch("SPRT opening: ${op.name}") {
            val baseSpec = Host.spec("builtin", "Opening=true;Book=false", "@default") ?: throw IllegalStateException("Tsy misy moteur Blind")
            val key = "oprof:$id"
            val a = baseSpec.copy(label = "Blind{${op.name} vaovao}", options = baseSpec.options + (key to OProfiles.args(op, prov)))
            val bOpts: Map<String, String> =
                if (op.active.isEmpty()) baseSpec.options - key else baseSpec.options + (key to OProfiles.args(op, op.active))
            val b = baseSpec.copy(label = "Blind{${op.name} taloha}", options = bOpts)
            val conts = OpeningBook.continuations(op.fen)
            val (lo, hi) = Stats.llrBounds(0.05, 0.05)
            val title = "SPRT ${op.name} [$elo0, $elo1] · ${tc.text()} · $nW miaraka"
            val out = ParSprt.run<Duo>(
                nW, maxGames, SprtCounts(), elo0, elo1, lo, hi,
                open = { val d = Duo(Player(a), Player(b)); try { d.a.open(); d.b.open() } catch (e: Throwable) { d.a.close(); d.b.close(); throw e }; d },
                close = { it.a.close(); it.b.close() },
                play = { duo, g ->
                    val aWhite = g % 2 == 0
                    val pre = conts[(g / 2) % conts.size]
                    val o = if (aWhite) playGame(duo.a.eng, duo.b.eng, op.fen, tc, prefix = pre)
                            else playGame(duo.b.eng, duo.a.eng, op.fen, tc, prefix = pre)
                    Pair(if (aWhite) o.score else 1 - o.score, "${pre.joinToString(" ")} ${o.reason}")
                },
                onProgress = { cn, g, llr, reason ->
                    Host.log("#${g + 1} $reason")
                    Host.post(title, "${a.label}\nvs ${b.label}\nlalao ${cn.g}  +${cn.w} =${cn.d} -${cn.l}\nElo ${f1(Stats.elo(cn.w, cn.d, cn.l))} ± ${f1(Stats.err95(cn.w, cn.d, cn.l))}\nLLR ${f2(llr)}  [${f2(lo)} ; ${f2(hi)}]")
                }
            )
            val cn = out.counts
            val txt = "${if (out.ok == true) "H1" else if (out.ok == false) "H0" else "?"} · Elo ${f1(Stats.elo(cn.w, cn.d, cn.l))} ± ${f1(Stats.err95(cn.w, cn.d, cn.l))} · ${cn.g} lalao · ${tc.text()}"
            val cur2 = OProfiles.get(id)
            // fiarovana: raha niova ny provisoire teo am-pandehanana ny SPRT (Apply vaovao / Delete) dia tsy ampiharina ny valiny taloha
            if (cur2 != null && cur2.prov == prov) OProfiles.put(cur2.copy(sprt = txt, sprtOk = out.ok, games = cur2.games + cn.g))
            Host.post(title, "VITA: ${out.verdict}\nlalao ${cn.g}  +${cn.w} =${cn.d} -${cn.l}\nElo ${f1(Stats.elo(cn.w, cn.d, cn.l))} ± ${f1(Stats.err95(cn.w, cn.d, cn.l))}\nLLR ${f2(Stats.llr(cn.w, cn.d, cn.l, elo0, elo1))}" +
                if (cur2 == null || cur2.prov != prov) "\n(Niova ny provisoire: tsy voatahiry ny valiny)" else "")
            Notifier.notify("SPRT ${op.name} vita", out.verdict)
        }
    }
}
