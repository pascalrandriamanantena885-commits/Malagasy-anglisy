package mg.joro.chess.match

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Isa W/D/L (A POV) + isan'ny lalao vita */
data class SprtCounts(val w: Int = 0, val d: Int = 0, val l: Int = 0) {
    val g get() = w + d + l
    fun add(sa: Double): SprtCounts = if (sa == 1.0) copy(w = w + 1) else if (sa == 0.0) copy(l = l + 1) else copy(d = d + 1)
}

class SprtOutcome(val counts: SprtCounts, val verdict: String, val ok: Boolean?)

/**
 * SPRT parallèle: `workers` lalao miaraka. Ny worker tsirairay dia manana "resource" manokana (ohatra: Player A + Player B),
 * mangalatra laharana lalao (`g`) avy amin'ny counter iombonana, ary mamerina (sa = isa A POV, antony). Ny valiny dia raisina
 * araka ny filaharan'ny fahavitany; rehefa tonga any amin'ny sisin'ny LLR (H1/H0) dia foanana avy hatrany ny lalao mbola mandeha
 * (tsy raisina ny valiny, mba tsy hisy fiovana aorian'ny fanapahan-kevitra).
 * - `start` = valiny efa nitahiry (checkpoint); ny lalao vaovao dia manomboka amin'ny laharana `start.g`.
 * - `onProgress` miantso ao anatin'ny mutex (tsy miaraka), isaky ny lalao vita.
 */
object ParSprt {
    suspend fun <W> run(
        workers: Int, maxGames: Int, start: SprtCounts, elo0: Double, elo1: Double, lo: Double, hi: Double,
        open: suspend () -> W, close: (W) -> Unit,
        play: suspend (W, Int) -> Pair<Double, String>,
        onProgress: (SprtCounts, Int, Double, String) -> Unit = { _, _, _, _ -> }
    ): SprtOutcome = coroutineScope {
        val n = workers.coerceAtLeast(1)
        val mu = Mutex()
        var counts = start
        var next = start.g
        var finished = false
        var verdict = "Tsy vita (max lalao)"
        var ok: Boolean? = null
        val decided = CompletableDeferred<Unit>()
        val jobs = ArrayList<Job>()
        for (k in 0 until n) {
            jobs.add(launch(Dispatchers.Default) {
                val res = open()
                try {
                    while (true) {
                        val g = mu.withLock { if (finished || next >= maxGames) -1 else next++ }
                        if (g < 0) break
                        val (sa, reason) = play(res, g)
                        mu.withLock {
                            if (!finished) {
                                counts = counts.add(sa)
                                val llr = Stats.llr(counts.w, counts.d, counts.l, elo0, elo1)
                                onProgress(counts, g, llr, reason)
                                if (llr >= hi) { finished = true; ok = true; verdict = "H1 ekena (vaovao tsara kokoa)" }
                                else if (llr <= lo) { finished = true; ok = false; verdict = "H0 ekena (tsy tsara kokoa)" }
                                if (finished) decided.complete(Unit)
                            }
                        }
                    }
                } finally {
                    close(res)
                }
            })
        }
        val watcher = launch { decided.await(); jobs.forEach { it.cancel() } }
        jobs.joinAll()
        watcher.cancel()
        SprtOutcome(counts, verdict, ok)
    }

    /** Isan'ny worker azo ampiasaina: 1..max(1, cores/2) (moteur A + B isaky ny worker) */
    fun clampWorkers(requested: Int): Int {
        val cores = Runtime.getRuntime().availableProcessors()
        return requested.coerceIn(1, maxOf(1, cores / 2))
    }
}
