package mg.joro.chess.match

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import mg.joro.chess.uci.Info
import mg.joro.chess.uci.UciEngine
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt

/** Sokajin'ny hetsika (toa an'ny chess.com) */
enum class MC(val label: String, val sym: String, val color: Long, val pgn: String) {
    BRILLIANT("Brilliant", "!!", 0xFF1BACA6, "!!"),
    GREAT("Great", "!", 0xFF5C8BB0, "!"),
    BEST("Best", "★", 0xFF81B64C, ""),
    EXCELLENT("Excellent", "✔", 0xFF96BC4B, ""),
    GOOD("Good", "✓", 0xFFA3B18A, ""),
    BOOK("Book", "📖", 0xFFA88865, ""),
    FORCED("Forced", "→", 0xFF8B8987, ""),
    INACCURACY("Inaccuracy", "?!", 0xFFF7C631, "?!"),
    MISTAKE("Mistake", "?", 0xFFE58F2A, "?"),
    MISS("Miss", "✗", 0xFFEE6B55, "?!"),
    BLUNDER("Blunder", "??", 0xFFCA3431, "??")
}

/** Fampiasa madio (azo andramana tsy misy moteur) */
object Rv {
    const val MATE = 10000

    fun win(cp: Int): Double = 1.0 / (1.0 + exp(-0.00368208 * cp))

    /** SEE: tombony azon'ny mpisambotra (att) raha misambotra `target`; def = mpiaro */
    fun swap(target: Int, att: List<Int>, def: List<Int>): Int {
        if (att.isEmpty()) return 0
        return max(0, target - swap(att[0], def, att.drop(1)))
    }

    private val VAL = intArrayOf(0, 1, 3, 3, 5, 9, 100)

    /** Sorona sombin-javatra (N/B/R/Q) izay mety hohaza amin'ny fanakalozana */
    fun isSacrifice(before: Board, move: Int, after: Board): Boolean {
        val from = Board.from(move); val to = Board.to(move)
        val piece = before.sq[from] and 7
        if (piece == 1 || piece == 6) return false
        val mover = before.stm
        val captured = VAL[before.sq[to] and 7]
        val theirs = after.attackerValues(to, 1 - mover).sorted()
        val mine = after.attackerValues(to, mover).sorted()
        return swap(VAL[piece], theirs, mine) - captured >= 2
    }

    fun classify(isBest: Boolean, loss: Double, wBefore: Double, wAfter: Double, secondGap: Double?, sacrifice: Boolean, oppErr: Boolean): MC {
        val brilliant = sacrifice && wBefore < 0.85 && wAfter >= 0.45
        if (isBest || loss < 0.005) {
            if (brilliant) return MC.BRILLIANT
            if (secondGap != null && secondGap >= 0.15 && wBefore <= 0.95) return MC.GREAT
            return MC.BEST
        }
        if (loss <= 0.02) return if (brilliant) MC.BRILLIANT else MC.EXCELLENT
        if (loss <= 0.05) return MC.GOOD
        if (loss >= 0.10 && loss < 0.30 && oppErr && wBefore >= 0.6) return MC.MISS
        if (loss <= 0.10) return MC.INACCURACY
        if (loss <= 0.20) return MC.MISTAKE
        return MC.BLUNDER
    }

    fun accuracy(wBest: Double, wAfter: Double, isBest: Boolean): Double =
        if (isBest) 100.0 else (103.1668 * exp(-0.04354 * (wBest * 100 - wAfter * 100)) - 3.1669).coerceIn(0.0, 100.0)

    fun sideAccuracy(a: List<Double>): Double {
        if (a.isEmpty()) return 0.0
        val mean = a.average()
        val harm = a.size / a.sumOf { 1.0 / max(it, 1.0) }
        return (mean + harm) / 2
    }

    /** Fanombanana Elo avy amin'ny ACPL (cp very salan'isa) — tsy marina tanteraka */
    fun baseRating(acpl: Double): Double = 3100.0 * exp(-0.01 * acpl)
    fun ratingFromAcpl(acpl: Double): Int = baseRating(acpl).roundToInt().coerceIn(100, 3100)

    fun score(i: Info): Int {
        val m = i.mate
        if (m != null) return if (m > 0) MATE - 10 * m else -(MATE - 10 * -m)
        return i.cp ?: 0
    }
}

class MoveReview(
    val san: String, val uci: String, val cls: MC, val bestSan: String?, val loss: Double,
    val bestUci: String? = null, val opening: String = "", val bestLine: String = ""
)

class Review(
    val boards: List<Board>, val moves: List<MoveReview>, val uciMoves: List<String>, val curve: List<Double>,
    val acc: DoubleArray, val rating: IntArray, val counts: List<Map<MC, Int>>,
    val startFen: String, val white: String, val black: String, val result: String, val res: Res, val engine: String,
    val cpW: List<Int> = emptyList(), val opening: String = "", val acpl: DoubleArray = DoubleArray(2)
)

internal class PosEval(val cp1: Int, val best: String?, val cp2: Int?, val terminal: Boolean, val pv: String = "")

internal class Evaluated(val boards: List<Board>, val used: List<String>, val ev: List<PosEval>)

/** Famerenana ("Retry"): hadisoana azo averina, ary fanaraha-maso ny valiny */
object Retry {
    enum class Verdict { BEST, PLAYED, OTHER }

    val BAD = setOf(MC.INACCURACY, MC.MISTAKE, MC.MISS, MC.BLUNDER)

    /** Index (0-based) ny hetsika diso azo averina; side 0 = Fotsy, 1 = Mainty, 2 = roa */
    fun targets(r: Review, side: Int): List<Int> =
        r.moves.indices.filter { i ->
            val m = r.moves[i]
            m.cls in BAD && m.bestUci != null && (side == 2 || r.boards[i].stm == side)
        }

    fun judge(mv: MoveReview, uci: String): Verdict =
        if (uci == mv.bestUci) Verdict.BEST else if (uci == mv.uci) Verdict.PLAYED else Verdict.OTHER
}

object Analysis {
    var running by mutableStateOf(false)
    var done by mutableIntStateOf(0)
    var total by mutableIntStateOf(0)
    var error by mutableStateOf("")
    var review by mutableStateOf<Review?>(null)
    var viewPly by mutableIntStateOf(0)
    var flip by mutableStateOf(false)
    var retryMode by mutableStateOf(false)
    val msText = mutableStateOf("400")
    private var job: Job? = null

    fun cancel() { job?.cancel() }

    /** Calibrage Game Rating (asa lava, aseho ao amin'ny tab Fitsapana ihany koa) */
    fun startCalibration() {
        if (running || Host.running.value) return
        val ms = msText.value.toIntOrNull()?.coerceIn(50, 10000) ?: 400
        Host.launch("Calibrage Game Rating") { RatingCalib.calibrate(ms) }
    }

    /** Mamoha review voatahiry, na manomboka fanadihadiana raha mbola tsy misy */
    fun openSaved(g: SavedGame) {
        if (running) return
        val r = ReviewStore.loadReview(g.id)
        if (r != null) { error = ""; review = r; viewPly = 0; flip = g.flip; retryMode = false; return }
        start(g.startFen, g.moves, g.white, g.black, g.res, g.resultText, g.id, g.flip)
    }

    fun start(
        startFen: String, moves: List<String>, white: String, black: String, res: Res, resultText: String,
        gameId: String? = null, flipBoard: Boolean = false
    ) {
        if (running) return
        flip = flipBoard; retryMode = false
        val ms = msText.value.toIntOrNull()?.coerceIn(50, 10000) ?: 400
        running = true; error = ""; review = null; done = 0; total = 0; viewPly = 0
        job = Host.scope.launch {
            var eng: UciEngine? = null
            try {
                val entry = Host.engines.firstOrNull { it.id == "stockfish" } ?: Host.engines.firstOrNull { it.id == "builtin" }
                    ?: throw IllegalStateException("Tsy misy moteur hanaovana analyse")
                eng = UciEngine(entry.path)
                eng.start()
                if (eng.has("Hash")) eng.setOption("Hash", "32")
                if (eng.has("Threads")) eng.setOption("Threads", "1")
                if (eng.has("UCI_LimitStrength")) eng.setOption("UCI_LimitStrength", "false")
                val multi = eng.has("MultiPV")
                if (multi) eng.setOption("MultiPV", "2")
                eng.ready(); eng.newGame()

                val g = evaluate(eng, startFen, moves, ms) { d, t -> done = d; total = t }
                done = total
                val built = build(startFen, g.used, g.boards, g.ev, white, black, res, resultText, entry.name)
                review = built
                if (gameId != null) ReviewStore.saveReview(gameId, built)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Analyse diso: ${e.message}"
            } finally {
                eng?.close()
                running = false
            }
        }
    }

    internal suspend fun evaluate(
        eng: UciEngine, startFen: String, moves: List<String>, ms: Int, progress: (Int, Int) -> Unit = { _, _ -> }
    ): Evaluated {
        val boards = ArrayList<Board>()
        var b = Board.fromFen(startFen)
        boards.add(b)
        val used = ArrayList<String>()
        for (u in moves) { val m = b.parseMove(u) ?: break; b = b.play(m); boards.add(b); used.add(u) }
        val ev = ArrayList<PosEval>()
        for (i in 0..used.size) {
            progress(i, used.size + 1)
            ev.add(evalPos(eng, startFen, used.take(i), boards[i], ms))
        }
        return Evaluated(boards, used, ev)
    }

    /** Andalana PV (UCI) -> SAN misy isa: "1.e4 e5 2.Nf3" */
    fun pvSan(b: Board, pv: String, max: Int = 8): String {
        var cur = b
        val out = ArrayList<String>()
        for (u in pv.split(" ").filter { it.isNotEmpty() }.take(max)) {
            val m = cur.parseMove(u) ?: break
            val prefix = if (cur.stm == 0) "${cur.full}." else if (out.isEmpty()) "${cur.full}..." else ""
            out.add(prefix + cur.san(m))
            cur = cur.play(m)
        }
        return out.joinToString(" ")
    }

    private suspend fun evalPos(eng: UciEngine, startFen: String, moves: List<String>, board: Board, ms: Int): PosEval {
        if (board.legalMoves().isEmpty()) return PosEval(if (board.inCheck()) -Rv.MATE else 0, null, null, true)
        val lines = HashMap<Int, Info>()
        val r = eng.go(startFen, moves, "movetime $ms", ms + 8000L) { info ->
            val cur = lines[info.multipv]
            if (cur == null || info.depth >= cur.depth) lines[info.multipv] = info
        }
        if (r.status != "ok") throw IllegalStateException("moteur: ${r.status}")
        val l1 = lines[1] ?: r.info
        val best = r.move ?: l1?.pv?.split(" ")?.firstOrNull()
        return PosEval(l1?.let { Rv.score(it) } ?: 0, best, lines[2]?.let { Rv.score(it) }, false, l1?.pv ?: "")
    }

    internal fun build(
        startFen: String, uci: List<String>, boards: List<Board>, ev: List<PosEval>,
        white: String, black: String, res: Res, rtext: String, engine: String
    ): Review {
        val n = uci.size
        val rev = ArrayList<MoveReview>()
        val losses = ArrayList<Double>()
        val accs = listOf(ArrayList<Double>(), ArrayList<Double>())
        val cpl = listOf(ArrayList<Double>(), ArrayList<Double>())
        val counts = listOf(HashMap<MC, Int>(), HashMap<MC, Int>())
        var bookOn = true
        var curOpening = ""
        for (i in 0 until n) {
            val b0 = boards[i]; val b1 = boards[i + 1]
            val mover = b0.stm
            val e0 = ev[i]; val e1 = ev[i + 1]
            val played = uci[i]
            val m = b0.parseMove(played) ?: continue
            val bestCp = e0.cp1
            val afterCp = if (e1.terminal) (if (b1.inCheck()) Rv.MATE else 0) else -e1.cp1
            val isBest = played == e0.best
            val forced = b0.legalMoves().size == 1
            val key = b1.key()
            val book = bookOn && OpeningBook.isBook(key)
            if (!book) bookOn = false else OpeningBook.name(key)?.let { curOpening = it.label() }
            val wBest = Rv.win(bestCp); val wAfter = Rv.win(afterCp)
            val loss = if (isBest || book || forced) 0.0 else max(0.0, wBest - wAfter)
            val gap = e0.cp2?.let { wBest - Rv.win(it) }
            val sac = Rv.isSacrifice(b0, m, b1)
            val oppErr = i > 0 && losses[i - 1] >= 0.10
            val cls = if (book) MC.BOOK else if (forced) MC.FORCED else Rv.classify(isBest, loss, wBest, wAfter, gap, sac, oppErr)
            losses.add(loss)
            val bestSan = if (!isBest && !book && !forced && e0.best != null) b0.parseMove(e0.best)?.let { b0.san(it) } else null
            val line = if (!forced && e0.pv.isNotEmpty()) pvSan(b0, e0.pv) else ""
            rev.add(MoveReview(b0.san(m), played, cls, bestSan, loss, if (isBest || book || forced) null else e0.best,
                if (book) curOpening else "", line))
            if (!forced) {   // hetsika voatery: tsy ampidirina amin'ny accuracy/ACPL
                accs[mover].add(Rv.accuracy(wBest, wAfter, isBest || book))
                cpl[mover].add(if (isBest || book) 0.0 else max(0, bestCp.coerceIn(-1000, 1000) - afterCp.coerceIn(-1000, 1000)).toDouble())
            }
            counts[mover][cls] = (counts[mover][cls] ?: 0) + 1
        }
        val cpWs = (0..n).map { i ->
            val e = ev[i]; val b = boards[i]
            if (e.terminal) (if (b.inCheck()) (if (b.stm == 0) -Rv.MATE else Rv.MATE) else 0) else (if (b.stm == 0) e.cp1 else -e.cp1)
        }
        val curve = cpWs.map { Rv.win(it) }
        val acc = doubleArrayOf(Rv.sideAccuracy(accs[0]), Rv.sideAccuracy(accs[1]))
        val acplArr = DoubleArray(2) { c -> if (cpl[c].isEmpty()) 0.0 else cpl[c].average() }
        val rating = IntArray(2) { c -> if (cpl[c].isEmpty()) 0 else RatingCalib.rating(acplArr[c]) }
        return Review(boards.take(rev.size + 1), rev, uci.take(rev.size), curve.take(rev.size + 1), acc, rating, counts,
            startFen, white, black, rtext, res, engine, cpWs.take(rev.size + 1), curOpening, acplArr)
    }
}
