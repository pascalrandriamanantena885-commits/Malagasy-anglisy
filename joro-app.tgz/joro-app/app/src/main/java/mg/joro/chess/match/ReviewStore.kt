package mg.joro.chess.match

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/** Lalao vita voatahiry (Milalao / Live) + review raha efa nodinihina */
data class SavedGame(
    val id: String, val time: Long, val source: String, val white: String, val black: String,
    val resultText: String, val res: Res, val startFen: String, val moves: List<String>, val flip: Boolean,
    val reviewed: Boolean = false, val accW: Double = 0.0, val accB: Double = 0.0, val ratW: Int = 0, val ratB: Int = 0
)

object ReviewStore {
    val games = mutableStateListOf<SavedGame>()
    private var dir: File? = null
    private val seq = AtomicLong()
    private const val MAX = 60

    fun init(ctx: Context) {
        val d = File(ctx.filesDir, "games")
        d.mkdirs()
        dir = d
        games.clear()
        val list = ArrayList<SavedGame>()
        d.listFiles()?.forEach { f ->
            if (f.name.endsWith(".json")) {
                try { list.add(parseGame(JSONObject(f.readText()))) } catch (_: Exception) { }
            }
        }
        games.addAll(list.sortedByDescending { it.time })
    }

    fun get(id: String): SavedGame? = games.firstOrNull { it.id == id }

    fun addGame(
        source: String, white: String, black: String, resultText: String, res: Res,
        startFen: String, moves: List<String>, flip: Boolean
    ): SavedGame {
        val now = System.currentTimeMillis()
        val g = SavedGame("${now}_${seq.incrementAndGet()}", now, source, white, black, resultText, res, startFen, moves, flip)
        writeFile(g.id, gameJson(g))
        games.add(0, g)
        while (games.size > MAX) {
            val old = games.removeAt(games.size - 1)
            fileOf(old.id)?.delete()
        }
        return g
    }

    fun saveReview(id: String, r: Review) {
        val idx = games.indexOfFirst { it.id == id }
        if (idx < 0) return
        val g = games[idx]
        writeFile(id, gameJson(g).put("review", reviewJson(r)))
        games[idx] = g.copy(reviewed = true, accW = r.acc[0], accB = r.acc[1], ratW = r.rating[0], ratB = r.rating[1])
    }

    fun loadReview(id: String): Review? {
        val g = get(id) ?: return null
        if (!g.reviewed) return null
        val f = fileOf(id) ?: return null
        return try {
            val o = JSONObject(f.readText())
            if (o.has("review")) reviewFromJson(g, o.getJSONObject("review")) else null
        } catch (_: Exception) { null }
    }

    fun remove(id: String) {
        games.removeAll { it.id == id }
        fileOf(id)?.delete()
    }

    fun clear() {
        for (g in games) fileOf(g.id)?.delete()
        games.clear()
    }

    // ---------- fitahirizana ----------
    private fun fileOf(id: String): File? = dir?.let { File(it, "$id.json") }

    private fun writeFile(id: String, o: JSONObject) {
        try { fileOf(id)?.writeText(o.toString()) } catch (_: Exception) { }
    }

    private fun gameJson(g: SavedGame): JSONObject = JSONObject()
        .put("id", g.id).put("time", g.time).put("source", g.source)
        .put("white", g.white).put("black", g.black).put("resultText", g.resultText)
        .put("res", g.res.name).put("startFen", g.startFen)
        .put("moves", JSONArray(g.moves)).put("flip", g.flip)

    private fun parseGame(o: JSONObject): SavedGame {
        val mv = o.getJSONArray("moves")
        val moves = (0 until mv.length()).map { mv.getString(it) }
        val rv = o.optJSONObject("review")
        val acc = rv?.optJSONArray("acc")
        val rat = rv?.optJSONArray("rating")
        return SavedGame(
            o.getString("id"), o.getLong("time"), o.getString("source"), o.getString("white"), o.getString("black"),
            o.getString("resultText"), Res.valueOf(o.getString("res")), o.getString("startFen"), moves, o.optBoolean("flip", false),
            rv != null, acc?.optDouble(0, 0.0) ?: 0.0, acc?.optDouble(1, 0.0) ?: 0.0, rat?.optInt(0, 0) ?: 0, rat?.optInt(1, 0) ?: 0
        )
    }

    fun reviewJson(r: Review): JSONObject {
        val mv = JSONArray()
        for (m in r.moves) {
            val o = JSONObject().put("san", m.san).put("uci", m.uci).put("cls", m.cls.name)
                .put("loss", m.loss).put("opening", m.opening).put("bestLine", m.bestLine)
            if (m.bestSan != null) o.put("bestSan", m.bestSan)
            if (m.bestUci != null) o.put("bestUci", m.bestUci)
            mv.put(o)
        }
        val cp = JSONArray()
        for (c in r.cpW) cp.put(c)
        val acc = JSONArray().put(r.acc[0]).put(r.acc[1])
        val rat = JSONArray().put(r.rating[0]).put(r.rating[1])
        return JSONObject().put("engine", r.engine).put("opening", r.opening)
            .put("acc", acc).put("rating", rat).put("cpW", cp).put("moves", mv)
    }

    fun reviewFromJson(g: SavedGame, o: JSONObject): Review {
        var b = Board.fromFen(g.startFen)
        val boards = ArrayList<Board>()
        boards.add(b)
        val arr = o.getJSONArray("moves")
        val moves = ArrayList<MoveReview>()
        val uci = ArrayList<String>()
        val counts = listOf(HashMap<MC, Int>(), HashMap<MC, Int>())
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val u = m.getString("uci")
            val mi = b.parseMove(u) ?: break
            val cls = MC.valueOf(m.getString("cls"))
            counts[b.stm][cls] = (counts[b.stm][cls] ?: 0) + 1
            b = b.play(mi)
            boards.add(b)
            moves.add(MoveReview(
                m.getString("san"), u, cls,
                if (m.has("bestSan")) m.getString("bestSan") else null,
                m.getDouble("loss"),
                if (m.has("bestUci")) m.getString("bestUci") else null,
                m.optString("opening", ""), m.optString("bestLine", "")
            ))
            uci.add(u)
        }
        val cpa = o.getJSONArray("cpW")
        val cpW = (0 until minOf(cpa.length(), moves.size + 1)).map { cpa.getInt(it) }
        val acc = o.getJSONArray("acc")
        val rat = o.getJSONArray("rating")
        return Review(
            boards, moves, uci, cpW.map { Rv.win(it) },
            doubleArrayOf(acc.getDouble(0), acc.getDouble(1)), intArrayOf(rat.getInt(0), rat.getInt(1)), counts,
            g.startFen, g.white, g.black, g.resultText, g.res, o.optString("engine", ""), cpW, o.optString("opening", "")
        )
    }
}
