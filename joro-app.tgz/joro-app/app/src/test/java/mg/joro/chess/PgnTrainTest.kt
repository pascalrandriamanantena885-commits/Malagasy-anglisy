package mg.joro.chess

import mg.joro.chess.chess.Board
import mg.joro.chess.match.Feat
import mg.joro.chess.match.Learn
import mg.joro.chess.match.LearnSums
import mg.joro.chess.match.ParamInfo
import mg.joro.chess.match.Pgn
import mg.joro.chess.match.PgnTrain
import mg.joro.chess.match.Trace
import java.io.BufferedReader
import java.io.StringReader
import org.junit.Assert.assertEquals
import org.junit.Test

/** Ny app no mijery ny opening ao amin'ny PGN ary ny mpandresy no sisiny ampiofanina */
class PgnTrainTest {
    private val pgn = """
[Event "a"]
[Result "1-0"]

1. e4 e5 2. f4 exf4 3. Nf3 g5 4. h4 g4 5. Ne5 1-0

[Event "b"]
[Result "0-1"]

1. e4 e5 2. f4 exf4 3. Nf3 d6 0-1

[Event "c"]
[Result "1-0"]

1. d4 d5 2. c4 1-0

[Event "d"]
[Result "1/2-1/2"]

1. e4 e5 2. f4 exf4 3. Nf3 1/2-1/2

[Event "e"]
[Result "1-0"]

1. e4 e5 2. f4 exf4 3. Bc4 1-0
"""

    private fun key(san: String) = Board.fromFen(Pgn.movesOf(san).endFen).key()

    // book kely: King's Gambit (3 ply), King's Gambit Accepted (4 ply), ...: Knight Gambit (5 ply)
    private val names = mapOf(
        key("e4 e5 f4") to "King's Gambit",
        key("e4 e5 f4 exf4") to "King's Gambit Accepted",
        key("e4 e5 f4 exf4 Nf3") to "King's Gambit Accepted: Knight Gambit"
    )
    private val nameOf: (String) -> String? = { names[it] }

    @Test fun parsesGamesAndResults() {
        val g = PgnTrain.parse(pgn)
        assertEquals(5, g.size)
        assertEquals(listOf("1-0", "0-1", "1-0", "1/2-1/2", "1-0"), g.map { it.result })
        assertEquals(0, PgnTrain.winner("1-0"))
        assertEquals(1, PgnTrain.winner("0-1"))
        assertEquals(-1, PgnTrain.winner("1/2-1/2"))
        assertEquals(-1, PgnTrain.winner("*"))
    }

    @Test fun findsOpeningAndWinnerAutomatically() {
        val r = PgnTrain.group(PgnTrain.parse(pgn), nameOf, minGames = 1)
        assertEquals(5, r.total)
        assertEquals(4, r.decisive)      // d = nul
        assertEquals(1, r.unnamed)       // c (d4 d5 c4) tsy ao amin'ny book
        assertEquals(2, r.groups.size)
        val w = r.groups.first { it.side == 0 }
        val b = r.groups.first { it.side == 1 }
        // a sy e = fotsy nandresy, fianakaviana "King's Gambit Accepted", toerana fohy indrindra = aorian'ny exf4
        assertEquals("King's Gambit Accepted", w.name)
        assertEquals(Pgn.movesOf("e4 e5 f4 exf4").endFen, w.fen)
        assertEquals(2, w.games)
        assertEquals(setOf(listOf("g1f3", "g7g5", "h2h4", "g5g4", "f3e5"), listOf("f1c4")), w.lines.toSet())
        assertEquals("King's Gambit Accepted", b.name)
        assertEquals(listOf(listOf("g1f3", "d7d6")), b.lines)
    }

    @Test fun minGamesFiltersSmallOpenings() {
        val r = PgnTrain.group(PgnTrain.parse(pgn), nameOf, minGames = 2)
        assertEquals(1, r.groups.size)
        assertEquals(0, r.groups[0].side)
        assertEquals(1, r.small)         // ny mainty (lalao 1 ihany)
    }

    @Test fun capsPliesAndGamesAndOpenings() {
        val r = PgnTrain.group(PgnTrain.parse(pgn), nameOf, maxPlies = 2, minGames = 1, perOpening = 1)
        val w = r.groups.first { it.side == 0 }
        assertEquals(2, w.games)
        assertEquals(1, w.lines.size)
        assertEquals(true, w.lines[0].size <= 2)
        assertEquals(1, PgnTrain.group(PgnTrain.parse(pgn), nameOf, minGames = 1, maxOpenings = 1).groups.size)
    }

    @Test fun familyName() {
        assertEquals("Sicilian Defense", PgnTrain.family("Sicilian Defense: Najdorf Variation"))
        assertEquals("Ruy Lopez", PgnTrain.family("Ruy Lopez"))
    }

    @Test fun packRoundTrip() {
        for (u in listOf("e2e4", "g1f3", "a7a8q", "h2g1n", "e1g1", "b7b8r", "c2c1b")) {
            assertEquals(u, PgnTrain.unpack(PgnTrain.pack(u)))
        }
    }

    @Test fun streamHandlesBomAndNoEventTag() {
        val txt = "\uFEFF[White \"x\"]\n[Result \"1-0\"]\n\n1. e4 e5 1-0\n\n[White \"y\"]\n[Result \"0-1\"]\n\n1. d4 d5 0-1\n"
        val got = ArrayList<String>()
        PgnTrain.stream(BufferedReader(StringReader(txt))) { got.add(it.result + ":" + it.moves.size) }
        assertEquals(listOf("1-0:2", "0-1:2"), got)
    }

    @Test fun streamingGrouperEqualsBatch() {
        val gp = PgnTrain.Grouper(nameOf)
        PgnTrain.stream(BufferedReader(StringReader(pgn))) { gp.add(it) }
        val a = gp.result()
        val b = PgnTrain.group(PgnTrain.parse(pgn), nameOf)
        assertEquals(b.groups.size, a.groups.size)
        assertEquals(b.total, a.total)
        assertEquals(b.groups.map { it.games }, a.groups.map { it.games })
    }

    @Test fun runningSumsEqualItemList() {
        fun tr(net: Double) = Trace(0, emptyMap(), mapOf("Foo" to Feat(net, 0.0, true), "Off" to Feat(9.0, 0.0, false)), "t")
        val params = mapOf("Foo" to ParamInfo("Foo", 10, 10, 0, 100, "pawns", 1), "Off" to ParamInfo("Off", 10, 10, 0, 100, "pawns", 1))
        val items = listOf(Pair(tr(2.0), 1), Pair(tr(1.0), -1), Pair(tr(3.0), 1))
        val acc = LearnSums()
        for ((t, g) in items) acc.add(t, g)
        val a = Learn.propose(items, params, emptyMap(), emptySet(), 1.0)
        val b = Learn.propose(acc, params, emptyMap(), emptySet(), 1.0)
        assertEquals(a.map { Triple(it.name, it.old, it.new) }, b.map { Triple(it.name, it.old, it.new) })
        assertEquals(3, acc.n)
    }
}
