package mg.joro.chess

import mg.joro.chess.match.OpProfile
import mg.joro.chess.match.OpText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

/** Fanamarinana ny export/import release an'ny profil opening sy ny fampitahana version (Rollback) */
class OpTextTest {
    private val fen = "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1"

    @Test fun lineRoundTrip() {
        val p = OpProfile("e4_w", "Sicilian Defense", fen, 0, active = linkedMapOf("PowerW" to 120, "KingSafetyW" to -5))
        val l = OpText.line(p)
        assertEquals("oprof add e4_w side w fen $fen set PowerW 120 KingSafetyW -5 # name=Sicilian Defense", l)
        val q = OpText.parseLine(l)!!
        assertEquals("e4_w", q.id); assertEquals("Sicilian Defense", q.name); assertEquals(fen, q.fen); assertEquals(0, q.side)
        assertEquals(p.active, q.active)
    }

    @Test fun sidesAndNoName() {
        val q = OpText.parseLine("oprof add x_b side b fen $fen set A 1")!!
        assertEquals(1, q.side); assertEquals("x_b", q.name)
        assertEquals(-1, OpText.parseLine("oprof add x side both fen $fen set A 1")!!.side)
    }

    @Test fun ignoresBadLines() {
        assertNull(OpText.parseLine(""))
        assertNull(OpText.parseLine("# comment"))
        assertNull(OpText.parseLine("oprof add x side w fen $fen set A"))        // lanja tsy misy value
        assertNull(OpText.parseLine("oprof add x side w fen $fen set A notnum"))
        assertNotNull(OpText.parseLine("  oprof add x side w fen $fen set A 1  "))
    }

    @Test fun diff() {
        assertEquals("mitovy", OpText.diff(mapOf("A" to 1), mapOf("A" to 1)))
        assertEquals("A 5→3, B -→9", OpText.diff(linkedMapOf("A" to 5), linkedMapOf("A" to 3, "B" to 9)))
        assertEquals("A 5→-", OpText.diff(mapOf("A" to 5), emptyMap()))
    }
}
