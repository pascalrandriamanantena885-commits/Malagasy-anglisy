package mg.joro.chess

import mg.joro.chess.chess.Board
import mg.joro.chess.chess.Res
import mg.joro.chess.match.Analysis
import mg.joro.chess.match.MC
import mg.joro.chess.match.OpeningBook
import mg.joro.chess.match.PosEval
import mg.joro.chess.match.RatingCalib
import mg.joro.chess.match.Retry
import mg.joro.chess.match.Rv
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class RvTest {
    @Test fun winSymmetry() {
        assertEquals(0.5, Rv.win(0), 1e-9)
        assertEquals(1.0, Rv.win(300) + Rv.win(-300), 1e-9)
    }

    @Test fun swapBasic() {
        assertEquals(3, Rv.swap(3, listOf(1), emptyList()))
        assertEquals(0, Rv.swap(3, listOf(3), listOf(1)))
        assertEquals(0, Rv.swap(3, emptyList(), listOf(1)))
    }

    @Test fun classifyBestFamily() {
        assertEquals(MC.BEST, Rv.classify(true, 0.0, 0.5, 0.5, null, false, false))
        assertEquals(MC.GREAT, Rv.classify(true, 0.0, 0.5, 0.5, 0.2, false, false))
        assertEquals(MC.BEST, Rv.classify(true, 0.0, 0.97, 0.97, 0.3, false, false))
        assertEquals(MC.BRILLIANT, Rv.classify(true, 0.0, 0.5, 0.55, null, true, false))
        assertEquals(MC.BEST, Rv.classify(true, 0.0, 0.9, 0.9, null, true, false))
        assertEquals(MC.BEST, Rv.classify(false, 0.004, 0.5, 0.5, null, false, false))
    }

    @Test fun classifyThresholds() {
        assertEquals(MC.EXCELLENT, Rv.classify(false, 0.01, 0.5, 0.49, null, false, false))
        assertEquals(MC.GOOD, Rv.classify(false, 0.03, 0.5, 0.47, null, false, false))
        assertEquals(MC.INACCURACY, Rv.classify(false, 0.07, 0.5, 0.43, null, false, false))
        assertEquals(MC.MISTAKE, Rv.classify(false, 0.15, 0.5, 0.35, null, false, false))
        assertEquals(MC.BLUNDER, Rv.classify(false, 0.25, 0.5, 0.25, null, false, false))
    }

    @Test fun classifyMiss() {
        assertEquals(MC.MISS, Rv.classify(false, 0.15, 0.7, 0.55, null, false, true))
        assertEquals(MC.MISTAKE, Rv.classify(false, 0.15, 0.5, 0.35, null, false, true))
        assertEquals(MC.MISTAKE, Rv.classify(false, 0.15, 0.7, 0.55, null, false, false))
        assertEquals(MC.BLUNDER, Rv.classify(false, 0.35, 0.8, 0.45, null, false, true))
    }

    @Test fun accuracy() {
        assertEquals(100.0, Rv.accuracy(0.5, 0.1, true), 0.0)
        assertTrue(Rv.accuracy(0.5, 0.5, false) > 99.0)
        assertTrue(Rv.accuracy(0.8, 0.3, false) < Rv.accuracy(0.8, 0.7, false))
        assertEquals(0.0, Rv.accuracy(1.0, 0.0, false), 1e-9)
        assertEquals(0.0, Rv.sideAccuracy(emptyList()), 0.0)
        assertEquals(100.0, Rv.sideAccuracy(listOf(100.0, 100.0)), 1e-9)
    }

    @Test fun ratingFromAcpl() {
        assertEquals(3100, Rv.ratingFromAcpl(0.0))
        assertTrue(Rv.ratingFromAcpl(10.0) > Rv.ratingFromAcpl(50.0))
        assertTrue(Rv.ratingFromAcpl(50.0) > Rv.ratingFromAcpl(100.0))
        assertEquals(100, Rv.ratingFromAcpl(100000.0))
    }
}

class OpeningBookTest {
    private fun keyAfter(vararg sans: String): String {
        var b = Board.fromFen(Board.START)
        for (s in sans) b = b.play(b.parseSan(s)!!)
        return b.key()
    }

    @Test fun smallTable() {
        val n = OpeningBook.load("A00\tTest\t1. e4 e5 2. Nf3\nbad line\nX\tBroken\t1. e4 e4\n")
        assertEquals(1, n)
        assertEquals(2, OpeningBook.skipped)
        assertTrue(OpeningBook.isBook(keyAfter("e4")))
        assertTrue(OpeningBook.isBook(keyAfter("e4", "e5", "Nf3")))
        assertFalse(OpeningBook.isBook(keyAfter("d4")))
        assertEquals("A00 · Test", OpeningBook.name(keyAfter("e4", "e5", "Nf3"))!!.label())
        assertNull(OpeningBook.name(keyAfter("e4")))
    }

    @Test fun realFileHasNoBrokenLines() {
        val f = listOf(File("src/main/assets/openings.tsv"), File("app/src/main/assets/openings.tsv")).first { it.exists() }
        val n = OpeningBook.load(f.readText())
        assertEquals(0, OpeningBook.skipped)
        assertTrue(n > 150)
        assertEquals("C60 · Ruy Lopez", OpeningBook.name(keyAfter("e4", "e5", "Nf3", "Nc6", "Bb5"))!!.label())
        assertEquals("B20 · Sicilian Defense", OpeningBook.name(keyAfter("e4", "c5"))!!.label())
        assertFalse(OpeningBook.isBook(keyAfter("a4", "h5", "Ra3")))
    }
}

class AnalysisBuildTest {
    private fun boardsOf(moves: List<String>): List<Board> {
        var b = Board.fromFen(Board.START)
        val out = arrayListOf(b)
        for (u in moves) { b = b.play(b.parseMove(u)!!); out.add(b) }
        return out
    }

    /** 1. f3 e5 2. g4 Qh4# — mistake, best, blunder, best */
    @Test fun foolsMate() {
        OpeningBook.load("")
        val moves = listOf("f2f3", "e7e5", "g2g4", "d8h4")
        val ev = listOf(
            PosEval(20, "e2e4", 10, false),
            PosEval(150, "e7e5", null, false),
            PosEval(-150, "e2e4", null, false, "e2e4 d7d5"),
            PosEval(900, "d8h4", null, false),
            PosEval(-Rv.MATE, null, null, true)
        )
        val r = Analysis.build(Board.START, moves, boardsOf(moves), ev, "W", "B", Res.BLACK, "0-1", "test")
        assertEquals(listOf(MC.MISTAKE, MC.BEST, MC.BLUNDER, MC.BEST), r.moves.map { it.cls })
        assertEquals(1, r.counts[0][MC.MISTAKE] ?: 0)
        assertEquals(1, r.counts[0][MC.BLUNDER] ?: 0)
        assertEquals(2, r.counts[1][MC.BEST] ?: 0)
        assertEquals("e4", r.moves[2].bestSan)
        assertEquals("e2e4", r.moves[2].bestUci)
        assertNull(r.moves[1].bestUci)
        assertEquals("2.e4 d5", r.moves[2].bestLine)
        assertEquals("", r.moves[0].bestLine)
        assertEquals(listOf(0, 2), Retry.targets(r, 2))
        assertEquals(listOf(0, 2), Retry.targets(r, 0))
        assertEquals(emptyList<Int>(), Retry.targets(r, 1))
        assertEquals(Retry.Verdict.BEST, Retry.judge(r.moves[2], "e2e4"))
        assertEquals(Retry.Verdict.PLAYED, Retry.judge(r.moves[2], "g2g4"))
        assertEquals(Retry.Verdict.OTHER, Retry.judge(r.moves[2], "a2a3"))
        assertTrue(r.acc[0] < r.acc[1])
        assertEquals(100.0, r.acc[1], 1e-6)
        assertTrue(r.rating[0] < r.rating[1])
        assertEquals(5, r.curve.size)
        assertEquals(5, r.cpW.size)
        assertEquals(-Rv.MATE, r.cpW[4])
        assertEquals("", r.opening)
    }

    @Test fun bookMovesAreBook() {
        OpeningBook.load("C60\tRuy Lopez\t1. e4 e5 2. Nf3 Nc6 3. Bb5\n")
        val moves = listOf("e2e4", "e7e5", "g1f3", "b8c6", "f1b5")
        val ev = List(6) { PosEval(0, "a1a1", null, false) }
        val r = Analysis.build(Board.START, moves, boardsOf(moves), ev, "W", "B", Res.DRAW, "1/2-1/2", "test")
        assertTrue(r.moves.all { it.cls == MC.BOOK })
        assertEquals("C60 · Ruy Lopez", r.opening)
        assertEquals("C60 · Ruy Lopez", r.moves.last().opening)
        assertEquals("", r.moves.first().opening)
        assertEquals(100.0, r.acc[0], 1e-6)
    }

    @Test fun leavingBookStopsBook() {
        OpeningBook.load("C20\tKing's Pawn Game\t1. e4 e5\n")
        val moves = listOf("e2e4", "e7e5", "a2a3")
        val ev = List(4) { PosEval(0, "e2e4", null, false) }
        val r = Analysis.build(Board.START, moves, boardsOf(moves), ev, "W", "B", Res.DRAW, "1/2-1/2", "test")
        assertEquals(MC.BOOK, r.moves[0].cls)
        assertEquals(MC.BOOK, r.moves[1].cls)
        assertTrue(r.moves[2].cls != MC.BOOK)
        assertEquals("C20 · King's Pawn Game", r.opening)
    }
}

class ForcedAndPvTest {
    @Test fun forcedMove() {
        OpeningBook.load("")
        val fen = "7k/8/8/8/8/8/6q1/7K w - - 0 1"
        val b0 = Board.fromFen(fen)
        assertEquals(1, b0.legalMoves().size)
        val b1 = b0.play(b0.parseMove("h1g2")!!)
        val ev = listOf(PosEval(0, "h1g2", null, false), PosEval(0, null, null, false))
        val r = Analysis.build(fen, listOf("h1g2"), listOf(b0, b1), ev, "W", "B", Res.DRAW, "1/2-1/2", "t")
        assertEquals(MC.FORCED, r.moves[0].cls)
        assertEquals(1, r.counts[0][MC.FORCED] ?: 0)
        assertEquals(0.0, r.acc[0], 0.0)
        assertEquals(0, r.rating[0])
        assertNull(r.moves[0].bestUci)
    }

    @Test fun pvSan() {
        val s = Board.fromFen(Board.START)
        assertEquals("1.e4 e5 2.Nf3", Analysis.pvSan(s, "e2e4 e7e5 g1f3"))
        val a = s.play(s.parseMove("e2e4")!!)
        assertEquals("1...e5 2.Nf3", Analysis.pvSan(a, "e7e5 g1f3"))
        assertEquals("1.e4", Analysis.pvSan(s, "e2e4 e2e4"))
        assertEquals("1.e4 e5", Analysis.pvSan(s, "e2e4 e7e5 g1f3", 2))
    }
}

class RatingCalibTest {
    @Test fun interpolation() {
        try {
            RatingCalib.set(listOf(Pair(60.0, 1800.0), Pair(20.0, 2600.0), Pair(120.0, 1200.0)))
            assertEquals(2600, RatingCalib.rating(20.0))
            assertEquals(2200, RatingCalib.rating(40.0))
            assertEquals(1500, RatingCalib.rating(90.0))
            assertEquals(1200, RatingCalib.rating(120.0))
            assertTrue(RatingCalib.rating(0.0) in 2600..3200)
            assertTrue(RatingCalib.rating(200.0) < 1200)
            assertTrue(RatingCalib.rating(10.0) > RatingCalib.rating(30.0))
        } finally {
            RatingCalib.reset()
        }
    }

    @Test fun normalizeIsMonotone() {
        val n = RatingCalib.normalize(listOf(Pair(20.0, 2000.0), Pair(40.0, 2200.0)))
        assertEquals(2000.0, n[1].second, 0.0)
    }

    @Test fun defaultWithoutPoints() {
        RatingCalib.reset()
        assertEquals(Rv.ratingFromAcpl(30.0), RatingCalib.rating(30.0))
    }

    @Test fun parseSkipsBadEntries() {
        assertEquals(listOf(Pair(1.5, 2000.0)), RatingCalib.parse("1.5:2000.0,bad"))
    }
}
