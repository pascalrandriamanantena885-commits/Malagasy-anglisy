package mg.joro.chess

import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import mg.joro.chess.match.OpProfile
import mg.joro.chess.match.OpText
import mg.joro.chess.match.ParSprt
import mg.joro.chess.match.SprtCounts
import mg.joro.chess.match.Stats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger

/** SPRT parallèle (resource sandoka, tsy mila moteur) + fiarovana Update moteur */
class ParSprtTest {
    private val bounds = Stats.llrBounds(0.05, 0.05)

    @Test fun countsAdd() {
        val c = SprtCounts().add(1.0).add(0.0).add(0.5).add(1.0)
        assertEquals(2, c.w); assertEquals(1, c.l); assertEquals(1, c.d); assertEquals(4, c.g)
    }

    @Test fun h1WhenAAlwaysWins() = runBlocking {
        val opened = AtomicInteger(0); val closed = AtomicInteger(0)
        val out = ParSprt.run<Any>(
            3, 1000, SprtCounts(), 0.0, 5.0, bounds.first, bounds.second,
            open = { opened.incrementAndGet(); Any() }, close = { closed.incrementAndGet() },
            play = { _, _ -> delay(1); Pair(1.0, "win") }
        )
        assertEquals(true, out.ok)
        assertTrue(out.verdict.startsWith("H1"))
        assertTrue(opened.get() >= 1)
        assertEquals(opened.get(), closed.get())     // resource rehetra nosokafana dia nikatona
        assertTrue(out.counts.g < 1000)
    }

    @Test fun h0WhenALoses() = runBlocking {
        val out = ParSprt.run<Any>(
            2, 1000, SprtCounts(), 0.0, 5.0, bounds.first, bounds.second,
            open = { Any() }, close = { }, play = { _, _ -> delay(1); Pair(0.0, "loss") }
        )
        assertEquals(false, out.ok)
        assertTrue(out.verdict.startsWith("H0"))
    }

    @Test fun maxGamesStopsWithoutVerdict() = runBlocking {
        // tsy mandeha ny SPRT raha draw foana: miato amin'ny max
        val out = ParSprt.run<Any>(
            4, 20, SprtCounts(), 0.0, 5.0, bounds.first, bounds.second,
            open = { Any() }, close = { }, play = { _, _ -> Pair(0.5, "draw") }
        )
        assertNull(out.ok)
        assertEquals(20, out.counts.g)         // tsy mihoatra ny max na dia miaraka aza
    }

    @Test fun eachGameIndexUsedOnce() = runBlocking {
        val seen = java.util.Collections.synchronizedList(ArrayList<Int>())
        ParSprt.run<Any>(
            4, 30, SprtCounts(), 0.0, 5.0, bounds.first, bounds.second,
            open = { Any() }, close = { }, play = { _, g -> seen.add(g); delay(1); Pair(0.5, "draw") }
        )
        assertEquals(30, seen.size)
        assertEquals((0 until 30).toList(), seen.sorted())
    }

    @Test fun resumesFromCheckpoint() = runBlocking {
        val seen = java.util.Collections.synchronizedList(ArrayList<Int>())
        val out = ParSprt.run<Any>(
            2, 12, SprtCounts(2, 2, 2), 0.0, 5.0, bounds.first, bounds.second,
            open = { Any() }, close = { }, play = { _, g -> seen.add(g); Pair(0.5, "draw") }
        )
        assertEquals((6 until 12).toList(), seen.sorted())   // manomboka amin'ny laharana 6
        assertEquals(12, out.counts.g)
    }

    @Test fun decidedGamesAreCancelled() = runBlocking {
        // A resy foana vetivety; ny lalao lava (worker hafa) dia tsy tiana hiandry ny faran'ny fotoana
        val t0 = System.currentTimeMillis()
        val out = ParSprt.run<Any>(
            2, 1000, SprtCounts(), 0.0, 5.0, bounds.first, bounds.second,
            open = { Any() }, close = { },
            play = { _, g -> if (g % 2 == 1) { delay(60_000); Pair(0.5, "slow") } else Pair(1.0, "fast") }
        )
        assertEquals(true, out.ok)
        assertTrue(System.currentTimeMillis() - t0 < 10_000)
    }

    @Test fun updateOnlyAfterH1() {
        val fen = "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1"
        val base = OpProfile("e4_w", "x", fen, 0, active = mapOf("A" to 1))
        assertFalse(OpText.canAccept(base))                                                    // tsy misy provisoire
        assertFalse(OpText.canAccept(base.copy(prov = mapOf("A" to 2))))                       // SPRT tsy mbola natao
        assertFalse(OpText.canAccept(base.copy(prov = mapOf("A" to 2), sprtOk = false)))       // H0
        assertTrue(OpText.canAccept(base.copy(prov = mapOf("A" to 2), sprtOk = true)))         // H1
    }

    @Test fun clampWorkers() {
        assertTrue(ParSprt.clampWorkers(0) >= 1)
        assertTrue(ParSprt.clampWorkers(1000) <= maxOf(1, Runtime.getRuntime().availableProcessors() / 2))
    }
}
