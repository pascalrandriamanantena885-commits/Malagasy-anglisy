package mg.joro.chess

import mg.joro.chess.match.ViewParse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Parse an'ny `ghostview` / `raceview` (output tena izy avy amin'ny moteur 1.2) */
class ViewParseTest {
    private val ghost = listOf(
        "ghostview side w king h8 real_king g8 score 42 tempo 2 cost 0",
        "parts rcov12 12 cost6 0 pattern 15.4 check 15",
        "cover ghost 1 real 1 blocked 1 free 1",
        "zone g7,h7,g8",
        "gcov h7",
        "rcov h7",
        "blocked g7",
        "free g8",
        "future pval 15.4 idx 15 pieces Pd4,Qh3",
        "eta 10 committed 2 d01 0 defense_cost 8 escapes 1",
        "def f6 N w 2 cost 3 att 0 prot 3 top 1 by -",
        "def f8 R w 3 cost 3 att 0 prot 2 top 0 by g1,h3",
        "shield g7 cost 2",
        "shield h7 cost 1",
        "heat b1 94 2 1",
        "heat h8 42 2 0"
    )

    private val race = listOf(
        "raceview side w eta 14 committed 2 d01 0 defense_cost 12 escapes 1",
        "plan 1 eta 14 pieces Bd3:0*,Qh3:0*",
        "plan 2 eta 15 pieces Rf1:1,Qh3:0*",
        "def f6 N w 2 cost 3 att 0 prot 3 top 1 by -",
        "shield f7 cost 2",
        "raceview side b eta 16 committed 0 d01 2 defense_cost 12 escapes 1",
        "plan 1 eta 16 pieces Rf8:1,Qe7:1",
        "def f3 N w 2 cost 3 att 0 prot 2 top 1 by -",
        "race eta_w 14 eta_b 16 term_white_pov 8 stm w",
        "verdict w care 0.30 care",
        "verdict b care 1.00 care"
    )

    @Test fun squareNames() {
        assertEquals(0, ViewParse.sq("a1"))
        assertEquals(63, ViewParse.sq("h8"))
        assertEquals(-1, ViewParse.sq("z9"))
        assertEquals("h8", ViewParse.sqName(63))
        assertEquals("e4", ViewParse.sqName(28))
    }

    @Test fun parsesGhost() {
        val v = ViewParse.ghost(ghost)!!
        assertEquals(0, v.side)
        assertEquals(ViewParse.sq("h8"), v.king)
        assertEquals(ViewParse.sq("g8"), v.realKing)
        assertEquals(42, v.score)
        assertEquals(2, v.tempo)
        assertEquals(12, v.rcov12)
        assertEquals(15, v.check)
        assertEquals(15.4, v.pattern, 1e-9)
        assertEquals(3, v.zone.size)
        assertEquals(listOf(ViewParse.sq("h7")), v.gcov)
        assertEquals(listOf(ViewParse.sq("g7")), v.blocked)
        assertEquals(listOf(ViewParse.sq("g8")), v.free)
        assertEquals(listOf(Pair('P', ViewParse.sq("d4")), Pair('Q', ViewParse.sq("h3"))), v.future)
        assertEquals(10, v.eta)
        assertEquals(2, v.committed)
        assertEquals(8, v.defCost)
        assertEquals(1, v.escapes)
        assertEquals(2, v.defs.size)
        assertEquals('N', v.defs[0].pc)
        assertTrue(v.defs[0].top)
        assertTrue(v.defs[0].by.isEmpty())
        assertFalse(v.defs[1].top)
        assertEquals(listOf(ViewParse.sq("g1"), ViewParse.sq("h3")), v.defs[1].by)
        assertEquals(listOf(Pair(ViewParse.sq("g7"), 2), Pair(ViewParse.sq("h7"), 1)), v.shields)
        // heat: ny case voadona (attacked = 1) dia tsy ao
        assertEquals(mapOf(ViewParse.sq("h8") to 42), v.heat)
    }

    @Test fun ghostErrorAndEmpty() {
        assertNull(ViewParse.ghost(listOf("ghostview error king-square-occupied")))
        assertNull(ViewParse.ghost(emptyList()))
    }

    @Test fun parsesRace() {
        val r = ViewParse.race(race)!!
        assertEquals(2, r.sides.size)
        assertEquals(14, r.etaW)
        assertEquals(16, r.etaB)
        assertEquals(8, r.term)
        assertEquals(0, r.stm)
        val w = r.sides[0]
        assertEquals(0, w.side)
        assertEquals(14, w.eta)
        assertEquals(2, w.committed)
        assertEquals(12, w.defCost)
        assertEquals(2, w.plans.size)
        assertEquals(14, w.plans[0].eta)
        assertEquals('B', w.plans[0].pieces[0].pc)
        assertEquals(ViewParse.sq("d3"), w.plans[0].pieces[0].sq)
        assertEquals(0, w.plans[0].pieces[0].d)
        assertTrue(w.plans[0].pieces[0].committed)
        assertEquals('R', w.plans[1].pieces[0].pc)
        assertEquals(1, w.plans[1].pieces[0].d)
        assertFalse(w.plans[1].pieces[0].committed)
        assertEquals(1, w.defs.size)
        assertEquals(1, w.shields.size)
        assertEquals("care", w.verdict)
        assertEquals(0.30, w.care, 1e-9)
        val b = r.sides[1]
        assertEquals(1, b.side)
        assertEquals(1, b.plans.size)
        assertEquals(1.0, b.care, 1e-9)
        assertEquals(1, b.defs.size)
    }

    @Test fun raceEmpty() {
        assertNull(ViewParse.race(listOf("bestmove e2e4")))
        assertNotNull(ViewParse.race(race))
    }

    private val power = listOf(
        "powerview stm w on 0 term_white_pov 25",
        "side w avg 56 n 7 weakest Ra1 strongest Nf3",
        "side b avg 44 n 6 weakest Bc8 strongest Qe7",
        "piece w B d3 power 76 lib 63 pot 78 safe 100 duty 75 mob 7 smob 4 open 2 lock 0 tags strong libsq b1,c2,e2,h7 xrsq b5,a6 dutysq f1,h7",
        "piece w Q h3 power 59 lib 31 pot 33 safe 100 duty 100 mob 8 smob 2 open 0 lock 1 tags selfblock libsq g3,h4 xrsq h1 dutysq g2,h2,h7,h8",
        "piece w K g1 power 48 lib 25 pot 25 safe 100 duty 0 mob 1 smob 1 open 0 lock 0 tags cramped libsq h1 xrsq - dutysq -",
        "piece b B c8 power 30 lib 10 pot 20 safe 100 duty 5 mob 1 smob 1 open 1 lock 2 tags weak,locked libsq - xrsq - dutysq -"
    )

    @Test fun parsesPower() {
        val v = ViewParse.power(power)!!
        assertEquals(0, v.stm)
        assertFalse(v.on)
        assertEquals(25, v.term)
        assertEquals(2, v.sides.size)
        assertEquals(56, v.sides[0].avg)
        assertEquals(7, v.sides[0].n)
        assertEquals("Ra1", v.sides[0].weakest)
        assertEquals(4, v.pieces.size)
        val b = v.pieces[0]
        assertEquals(0, b.side)
        assertEquals('B', b.pc)
        assertEquals(ViewParse.sq("d3"), b.sq)
        assertEquals(76, b.power)
        assertEquals(63, b.lib)
        assertEquals(78, b.pot)
        assertEquals(75, b.duty)
        assertEquals(7, b.mob)
        assertEquals(4, b.smob)
        assertEquals(2, b.open)
        assertEquals(listOf("strong"), b.tags)
        assertEquals(listOf("b1", "c2", "e2", "h7").map { ViewParse.sq(it) }, b.libSq)
        assertEquals(listOf("b5", "a6").map { ViewParse.sq(it) }, b.xrSq)
        assertEquals(listOf("selfblock"), v.pieces[1].tags)
        assertEquals('K', v.pieces[2].pc)
        assertTrue(v.pieces[2].xrSq.isEmpty())
        val weak = v.pieces[3]
        assertEquals(1, weak.side)
        assertEquals(listOf("weak", "locked"), weak.tags)
        assertTrue(weak.libSq.isEmpty())
    }

    @Test fun powerEmpty() {
        assertNull(ViewParse.power(listOf("end")))
    }

    @Test fun parsesRaceFuturesFirstSuggest() {
        val extra = race.toMutableList()
        extra.add("gfuture w score 33 tempo 2 pval 15.4 pieces Pc4,Qh3")
        extra.add("gfuture b score 13 tempo 2 pval 13.5 pieces Pd5,Qe7")
        extra.add("first w margin 2.5")
        extra.add("suggest w letgo margin 2.5")
        extra.add("suggest b care margin -2.5")
        val r = ViewParse.race(extra)!!
        assertEquals(2, r.futures.size)
        assertEquals(0, r.futures[0].side)
        assertEquals(33, r.futures[0].score)
        assertEquals(15.4, r.futures[0].pval, 1e-9)
        assertEquals(listOf(Pair('P', ViewParse.sq("c4")), Pair('Q', ViewParse.sq("h3"))), r.futures[0].pieces)
        assertEquals("w", r.first)
        assertEquals(2.5, r.margin, 1e-9)
        assertEquals("letgo", r.suggest[0]!!.first)
        assertEquals("care", r.suggest[1]!!.first)
        assertEquals(-2.5, r.suggest[1]!!.second, 1e-9)
        // tsy misy andalana vaovao -> default
        val plain = ViewParse.race(race)!!
        assertEquals("none", plain.first)
        assertTrue(plain.suggest.isEmpty())
    }

    @Test fun defenderPower() {
        val v = ViewParse.ghost(ghost + listOf("def e7 Q w 5 cost 3 att 0 prot 0 top 1 pw 68 by -"))!!
        assertEquals(-1, v.defs[0].pw)               // andalana taloha tsy misy pw
        assertEquals(68, v.defs.last().pw)
        assertEquals('Q', v.defs.last().pc)
    }
}
