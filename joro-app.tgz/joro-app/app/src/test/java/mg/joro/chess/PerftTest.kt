package mg.joro.chess

import mg.joro.chess.chess.Board
import org.junit.Assert.assertEquals
import org.junit.Test

class PerftTest {
    @Test fun startpos() { assertEquals(8902L, Board.fromFen(Board.START).perft(3)) }
    @Test fun kiwipete() {
        val b = Board.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1")
        assertEquals(2039L, b.perft(2))
    }
    @Test fun endgameEp() {
        assertEquals(2812L, Board.fromFen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1").perft(3))
    }
    @Test fun promos() {
        assertEquals(9467L, Board.fromFen("r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1").perft(3))
    }
}
