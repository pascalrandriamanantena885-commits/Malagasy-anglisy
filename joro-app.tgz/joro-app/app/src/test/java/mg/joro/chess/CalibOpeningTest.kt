package mg.joro.chess

import mg.joro.chess.chess.Board
import mg.joro.chess.match.OpCalib
import mg.joro.chess.match.OpProfile
import mg.joro.chess.match.OpText
import mg.joro.chess.match.OpeningBook
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Book ofisialy ho an'ny Live / Calibrage (tsy aléatoire) ary calibrage opening ao amin'ny profil */
class OfficialBookTest {
    private fun afterSan(vararg sans: String): String {
        var b = Board.fromFen(Board.START)
        for (s in sans) b = b.play(b.parseSan(s)!!)
        return b.toFen()
    }

    private fun loadReal() { OpeningBook.load(AssetBook.text()) }

    @Test fun pickIsDeterministicLegalAndVaried() {
        loadReal()
        val seen = HashSet<String>()
        for (seed in 0L..300L) {
            val l = OpeningBook.pick(seed)!!
            assertEquals(l.ucis, OpeningBook.pick(seed)!!.ucis)          // seed iray = ouverture iray (paire xolor)
            var b = Board.fromFen(Board.START)
            for (u in l.ucis) b = b.play(b.parseMove(u)!!)               // hetsika rehetra ara-dalàna
            assertEquals(l.fen, b.toFen())
            assertTrue(b.legalMoves().isNotEmpty())
            seen.add(l.ucis.joinToString(" "))
        }
        assertTrue("tsy ampy ny karazana: ${seen.size}", seen.size > 200)
    }

    @Test fun searchFindsByNameAndEco() {
        loadReal()
        assertTrue(OpeningBook.search("sicilian", 5).isNotEmpty())
        assertTrue(OpeningBook.search("B20", 5).all { it.eco.contains("B20") || it.name.lowercase().contains("b20") })
        assertTrue(OpeningBook.search("zzzzqq", 5).isEmpty())
        assertTrue(OpeningBook.search("   ", 5).isEmpty())
        val l = OpeningBook.search("ruy lopez", 1).first()
        assertTrue(l.san.isNotEmpty() && !l.san.contains("1."))
    }

    @Test fun emptyBookGivesNull() {
        OpeningBook.load("")
        assertNull(OpeningBook.pick(1))
    }

    @Test fun lichessHeaderAndDuplicates() {
        val n = OpeningBook.load("eco\tname\tpgn\nA00\tT\t1. e4 e5\nA00\tT again\t1. e4 e5\n")
        assertEquals(1, n)
        assertEquals(0, OpeningBook.skipped)
    }

    @Test fun continuationsUseBookLines() {
        OpeningBook.load("A00\tX\t1. e4 e5 2. Nf3\nA01\tY\t1. e4 c5\nA02\tZ\t1. d4 d5\n")
        assertEquals(listOf(listOf("e7e5", "g1f3"), listOf("c7c5")), OpeningBook.continuations(afterSan("e4")))
        assertEquals(3, OpeningBook.continuations(Board.START).size)
        assertEquals(listOf(emptyList<String>()), OpeningBook.continuations(afterSan("a3")))
    }
}

class OpCalibTextTest {
    private val fen = "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1"

    @Test fun acceptMovesCalibToActiveAndStillNeedsH1() {
        val c = OpCalib(2013.0, "2013 · SF 1500/2000 · 10 lalao/haavo · 200ms/coup", 1L, true)
        val p = OpProfile("e4_w", "e4", fen, 0, active = mapOf("A" to 1), prov = mapOf("A" to 2),
            sprt = "H1", sprtOk = true, calibProv = c)
        val q = OpText.accepted(p, 5L)!!
        assertEquals(mapOf("A" to 2), q.active)
        assertNull(q.prov); assertNull(q.calibProv)
        assertEquals(2013.0, q.calibActive!!.elo, 0.0)
        assertFalse(q.calibActive!!.ofProv)
        assertEquals(1, q.hist.size)
        // FIAROVANA: tsy misy Update raha tsy H1, na dia misy calibrage aza
        assertNull(OpText.accepted(p.copy(sprtOk = false), 5L))
        assertNull(OpText.accepted(p.copy(sprtOk = null), 5L))
    }

    @Test fun acceptWithoutCalibClearsStaleActiveCalib() {
        val old = OpCalib(1900.0, "x", 1L, false)
        val p = OpProfile("e4_w", "e4", fen, 0, active = mapOf("A" to 1), prov = mapOf("A" to 2),
            sprtOk = true, calibActive = old)
        assertNull(OpText.accepted(p, 5L)!!.calibActive)
    }

    @Test fun calibLineShowsDelta() {
        val p = OpProfile("a", "a", fen, 0, calibProv = OpCalib(2013.0, "P", 1L, true), calibActive = OpCalib(2001.0, "N", 1L, false))
        val t = OpText.calibLine(p)
        assertTrue(t, t.contains("Δ +12"))
        assertTrue(t, t.contains("Provisoire: P") && t.contains("Nekena: N"))
        assertEquals("", OpText.calibLine(OpProfile("b", "b", fen, 0)))
    }

    @Test fun levelsParsing() {
        assertEquals(listOf(1500, 2000, 2500), OpText.parseLevels(""))
        assertEquals(listOf(1500, 2000, 2500), OpText.parseLevels("abc, 5, 99999"))
        assertEquals(listOf(1400, 1800, 2200), OpText.parseLevels("2200, 1400;1800 1400"))
        assertNotNull(OpText.parseLevels("1320"))
    }
}
