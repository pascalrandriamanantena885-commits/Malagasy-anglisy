package mg.joro.chess

import mg.joro.chess.chess.Board
import mg.joro.chess.match.Books
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class SanTest {
    @Test fun sanRoundTrip() {
        val b = Board.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1")
        for (m in b.legalMoves()) assertEquals(m, b.parseSan(b.san(m)))
    }
    @Test fun pgnBook() {
        val pgn = "[Event \"x\"]\n\n1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 1-0\n\n[Event \"y\"]\n\n1. d4 d5 2. c4 e6 1/2-1/2\n"
        assertEquals(2, Books.parsePgn(pgn, 4).size)
    }
    @Test fun epdBook() {
        val l = Books.parseEpd("rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1 ; id \"a\"\n")
        assertEquals(1, l.size)
        assertNotNull(l[0])
    }
}

class PgnTest {
    @org.junit.Test fun roundTrip() {
        val line = mg.joro.chess.match.Pgn.movesOf("[Event \"x\"]\n\n1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 *")!!
        org.junit.Assert.assertEquals(6, line.moves.size)
        val pgn = mg.joro.chess.match.Pgn.build(line.startFen, line.moves, "A", "B", mg.joro.chess.chess.Res.DRAW)
        val back = mg.joro.chess.match.Pgn.movesOf(pgn)!!
        org.junit.Assert.assertEquals(line.moves, back.moves)
    }
}

class AnalysisHelpersTest {
    @org.junit.Test fun winCurve() {
        org.junit.Assert.assertEquals(0.5, mg.joro.chess.match.Rv.win(0), 1e-9)
        org.junit.Assert.assertTrue(mg.joro.chess.match.Rv.win(300) > 0.7)
    }
    @org.junit.Test fun swapAndAttackers() {
        org.junit.Assert.assertEquals(5, mg.joro.chess.match.Rv.swap(5, listOf(1), emptyList()))
        val b = mg.joro.chess.chess.Board.fromFen("4k3/8/8/3p4/4P3/8/8/4K3 w - - 0 1")
        org.junit.Assert.assertEquals(listOf(1), b.attackerValues(mg.joro.chess.chess.Board.sqOf("d5"), 0))
    }
    @org.junit.Test fun classify() {
        val R = mg.joro.chess.match.Rv; val M = mg.joro.chess.match.MC
        org.junit.Assert.assertEquals(M.BLUNDER, R.classify(false, 0.4, 0.8, 0.4, null, false, false))
        org.junit.Assert.assertEquals(M.BEST, R.classify(true, 0.0, 0.5, 0.5, null, false, false))
        org.junit.Assert.assertEquals(M.GREAT, R.classify(true, 0.0, 0.5, 0.5, 0.3, false, false))
        org.junit.Assert.assertEquals(M.BRILLIANT, R.classify(true, 0.0, 0.5, 0.55, null, true, false))
        org.junit.Assert.assertEquals(M.MISS, R.classify(false, 0.15, 0.7, 0.55, null, false, true))
        org.junit.Assert.assertEquals(M.INACCURACY, R.classify(false, 0.07, 0.5, 0.43, null, false, false))
    }
}
