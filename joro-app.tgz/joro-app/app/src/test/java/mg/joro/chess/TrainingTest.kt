package mg.joro.chess

import mg.joro.chess.match.Learn
import mg.joro.chess.match.TraceParse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Fanamarinana ny parse an'ny evaltrace/params/searchstats (format tena izy avy amin'ny moteur v0.8) sy ny lojika fianarana */
class TrainingTest {
    private val sample = listOf(
        "evaltrace stm w eval_white -96 eval_stm -96 eg 0 opening_active 1 profile none",
        "group Material+PST -112.0",
        "group Opening 18.0",
        "feat PawnDoubled 1.00 12.0 1",
        "feat OpCenterPawn 1.00 14.0 1",
        "feat OpCastled -1.00 -20.0 0"
    )
    private val params = TraceParse.params(
        listOf("param PawnDoubled 12 12 0 40 pos 1", "param NullBase 2 2 0 6 search 1", "param OpCastled 20 20 0 80 opening 1")
    )

    @Test fun parsesTrace() {
        val t = TraceParse.trace(sample)!!
        assertEquals(-96, t.evalWhite)
        assertEquals("none", t.profile)
        assertEquals(18.0, t.groups["Opening"]!!, 1e-9)
        assertEquals(3, t.feats.size)
        assertTrue(t.feats["PawnDoubled"]!!.active)
        assertFalse(t.feats["OpCastled"]!!.active)
    }

    @Test fun parsesNothing() {
        assertNull(TraceParse.trace(listOf("bestmove e2e4")))
    }

    @Test fun parsesParamsAndStats() {
        assertEquals(3, params.size)
        assertEquals("search", params["NullBase"]!!.group)
        assertEquals(40, params["PawnDoubled"]!!.hi)
        val s = TraceParse.stats(listOf("stats nodes_q 10 null_try 4 null_cut 3"))
        assertEquals(3L, s["null_cut"])
        assertEquals(10L, s["nodes_q"])
    }

    @Test fun winnerFeatureIncreases() {
        val tr = TraceParse.trace(sample)!!
        val p = Learn.propose(listOf(Pair(tr, 1)), params, emptyMap(), emptySet(), 1.0)
        // OpCenterPawn tsy ao amin'ny params -> adino; OpCastled tsy active -> adino
        assertEquals(1, p.size)
        assertEquals("PawnDoubled", p[0].name)
        assertTrue(p[0].new > 12)
        assertFalse(p[0].isNew)   // fampiofanana voalohany: tsy misy ★
    }

    @Test fun blackTrainedFlipsSign() {
        val tr = TraceParse.trace(sample)!!
        val p = Learn.propose(listOf(Pair(tr, -1)), params, emptyMap(), emptySet(), 1.0)
        assertEquals(1, p.size)
        assertTrue(p[0].new < 12)
    }

    @Test fun newFeatureIsTakenEvenIfSmall() {
        val tiny = TraceParse.trace(listOf("evaltrace stm w eval_white 0 eval_stm 0 eg 0 opening_active 0 profile none", "feat PawnDoubled 0.05 0.6 1"))!!
        val none = Learn.propose(listOf(Pair(tiny, 1)), params, emptyMap(), emptySet(), 1.0)
        assertTrue(none.isEmpty())                                  // kely loatra, tsy vaovao
        val p = Learn.propose(listOf(Pair(tiny, 1)), params, emptyMap(), setOf("Other"), 1.0)
        assertEquals(1, p.size)
        assertTrue(p[0].isNew)
        assertEquals(13, p[0].new)
    }

    @Test fun respectsBounds() {
        val tr = TraceParse.trace(listOf("evaltrace stm w eval_white 0 eval_stm 0 eg 0 opening_active 1 profile none", "feat PawnDoubled 5.00 60.0 1"))!!
        val p = Learn.propose(listOf(Pair(tr, 1)), params, mapOf("PawnDoubled" to 40), emptySet(), 1.0)
        assertTrue(p.isEmpty())                                     // efa eo amin'ny fetra ambony (40)
    }

    @Test fun zeroDefaultParamGetsRealStep() {
        // PinPenalty manomboka amin'ny 0: ny dingana tsy tokony ho 1 fotsiny (hi/5 = 20 -> 0.25*20 = 5)
        val tr = TraceParse.trace(listOf("evaltrace stm w eval_white 10 eval_stm 10 eg 0 opening_active 0 profile none", "feat PinPenalty 2.00 0.0 1"))!!
        val pp = TraceParse.params(listOf("param PinPenalty 0 0 0 100 power 1"))
        val p = Learn.propose(listOf(Pair(tr, 1)), pp, emptyMap(), emptySet(), 1.0)
        assertEquals(1, p.size)
        assertEquals(5, p[0].new)
        // mean < 0 dia tsy afaka midina ambanin'ny min (0)
        val q = Learn.propose(listOf(Pair(tr, -1)), pp, emptyMap(), emptySet(), 1.0)
        assertTrue(q.isEmpty())
    }
}
